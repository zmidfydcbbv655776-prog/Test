package dev.nexus.client;

import com.google.gson.JsonNull;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;
import dev.nexus.client.config.ConfigManager;
import dev.nexus.client.module.Category;
import dev.nexus.client.module.Module;
import dev.nexus.client.module.ModuleManager;
import dev.nexus.client.module.impl.utility.AutoTextModule;
import dev.nexus.client.module.impl.world.AmethystBaseFinderModule;
import dev.nexus.client.module.impl.world.StashFinderModule;
import dev.nexus.client.module.impl.world.SusChunkFinderModule;
import dev.nexus.client.module.setting.ActionSetting;
import dev.nexus.client.module.setting.KeybindSetting;
import dev.nexus.client.module.setting.ModeSetting;
import dev.nexus.client.module.setting.NumberSetting;
import dev.nexus.client.module.setting.TextSetting;
import dev.nexus.client.render.HudLayoutHelper;
import dev.nexus.client.render.NexusTheme;
import dev.nexus.client.util.KeyUtil;
import dev.nexus.client.util.RotationUtil;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.atomic.AtomicInteger;
import net.minecraft.util.math.Vec3d;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import static org.junit.jupiter.api.Assertions.*;

class NexusCoreTest {

    @Test
    void testAllNineModulesRegisterToggleAndCleanup(@TempDir Path tempDir) throws Exception {
        ModuleManager manager = new ModuleManager();
        manager.init();

        // Exactly 9 requested modules registered out of 15 target capacity
        assertEquals(9, manager.getModules().size());
        assertEquals(15, ModuleManager.TARGET_MODULE_CAPACITY);

        assertEquals(2, manager.getByCategory(Category.COMBAT).size());
        assertEquals(3, manager.getByCategory(Category.RENDER).size());
        assertEquals(3, manager.getByCategory(Category.WORLD).size());
        assertEquals(1, manager.getByCategory(Category.UTILITY).size());

        assertNotNull(manager.getModule(AmethystBaseFinderModule.class));
        assertNotNull(manager.getModule(SusChunkFinderModule.class));
        assertNotNull(manager.getModule(StashFinderModule.class));

        // Toggle every module ON, run world cleanup, toggle OFF
        for (Module m : manager.getModules()) {
            assertNotNull(m.getId());
            assertNotNull(m.getName());
            assertFalse(m.getSettings().isEmpty());
            m.setEnabled(true);
            assertTrue(m.isEnabled(), "Module should enable cleanly: " + m.getId());
        }

        manager.onWorldCleanupAll();

        for (Module m : manager.getModules()) {
            m.setEnabled(false);
            assertFalse(m.isEnabled(), "Module should disable cleanly: " + m.getId());
        }

        // Test ConfigManager save + reload + corrupted JSON recovery across all 9 modules
        ConfigManager cfg = new ConfigManager(manager, tempDir);
        AutoTextModule autoText = manager.getModule(AutoTextModule.class);
        StashFinderModule stashFinder = manager.getModule(StashFinderModule.class);
        SusChunkFinderModule susChunk = manager.getModule(SusChunkFinderModule.class);
        assertNotNull(autoText);
        assertNotNull(stashFinder);
        assertNotNull(susChunk);

        autoText.setEnabled(true);
        autoText.getTriggerKey().setValue(71); // G
        stashFinder.setEnabled(true);
        susChunk.setEnabled(true);
        cfg.save();
        assertTrue(Files.exists(cfg.getConfigFile()));

        ModuleManager reloadedManager = new ModuleManager();
        reloadedManager.init();
        ConfigManager cfgReload = new ConfigManager(reloadedManager, tempDir);
        cfgReload.load();
        AutoTextModule reloadedAutoText = reloadedManager.getModule(AutoTextModule.class);
        StashFinderModule reloadedStash = reloadedManager.getModule(StashFinderModule.class);
        SusChunkFinderModule reloadedSus = reloadedManager.getModule(SusChunkFinderModule.class);
        assertTrue(reloadedAutoText.isEnabled());
        assertEquals(71, reloadedAutoText.getTriggerKey().getValue());
        assertTrue(reloadedStash.isEnabled());
        assertTrue(reloadedSus.isEnabled());

        // Write corrupted JSON and ensure load() recovers safely without throwing
        Files.writeString(cfg.getConfigFile(), "{broken_json:::[[[", StandardCharsets.UTF_8);
        assertDoesNotThrow(cfgReload::load);
        assertFalse(reloadedAutoText.isEnabled());
        assertFalse(reloadedStash.isEnabled());
    }

    @Test
    void testWorldModulesRescanAndSignals() {
        assertEquals(10, SusChunkFinderModule.Sig.values().length);

        SusChunkFinderModule sus = new SusChunkFinderModule();
        assertDoesNotThrow(sus::rescanAllChunks);

        StashFinderModule stash = new StashFinderModule();
        assertDoesNotThrow(stash::clearAndRescan);

        AmethystBaseFinderModule amethyst = new AmethystBaseFinderModule();
        assertDoesNotThrow(amethyst::triggerFullRescan);
    }

    @Test
    void testActionSettingAndHudStacking() {
        AtomicInteger clicks = new AtomicInteger(0);
        ActionSetting btn = new ActionSetting("rescan", "Rescan", "desc", clicks::incrementAndGet);
        assertEquals(JsonNull.INSTANCE, btn.toJson());
        assertDoesNotThrow(() -> btn.fromJson(new JsonPrimitive(true)));

        btn.trigger();
        assertEquals(1, clicks.get());
        assertTrue(btn.isRecentlyTriggered());

        HudLayoutHelper.beginHudPass();
        int firstY = HudLayoutHelper.claimTopLeftY(21, 5);
        int secondY = HudLayoutHelper.claimTopLeftY(28, 5);
        assertEquals(8, firstY);
        assertEquals(34, secondY);
    }

    @Test
    void testNumberSettingClampingAndJsonSafety() {
        NumberSetting slider = new NumberSetting("range", "Range", "desc", 4.5, 2.0, 8.0, 0.5);
        assertEquals(4.5, slider.getValue(), 1e-6);

        slider.setValue(99.0);
        assertEquals(8.0, slider.getValue(), 1e-6);

        slider.setValue(-10.0);
        assertEquals(2.0, slider.getValue(), 1e-6);

        slider.setValue(Double.NaN);
        assertEquals(2.0, slider.getValue(), 1e-6);

        slider.fromJson(JsonParser.parseString("\"not_a_number\""));
        assertEquals(4.5, slider.getValue(), 1e-6);
    }

    @Test
    void testModeTextAndKeybindSettingsValidation() {
        ModeSetting mode = new ModeSetting("style", "Style", "desc", "Chest", "Chest", "Eyes", "Adaptive");
        mode.setValue("invalid_option");
        assertEquals("Chest", mode.getValue());
        mode.cycleNext();
        assertEquals("Eyes", mode.getValue());

        TextSetting text = new TextSetting("msg", "Message", "desc", "hello", 10);
        text.setValue("1234567890ABCDEF\nnewline");
        assertEquals(10, text.getValue().length());
        assertFalse(text.getValue().contains("\n"));

        KeybindSetting kb = new KeybindSetting("key", "Key", "desc", KeyUtil.UNBOUND);
        assertFalse(kb.isBound());
        int mouseCode = KeyUtil.encodeMouseButton(2);
        kb.setValue(mouseCode);
        assertTrue(kb.isBound());
        assertTrue(KeyUtil.isMouseCode(kb.getValue()));
        assertEquals(2, KeyUtil.decodeMouseButton(kb.getValue()));
        kb.fromJson(new JsonPrimitive(999999));
        assertFalse(kb.isBound());
    }

    @Test
    void testModuleLifecycleAndIsolatedErrorProtection() {
        final int[] cleanupCount = {0};
        Module dummy = new Module("test_mod", "Test Mod", "desc", Category.UTILITY) {
            @Override
            public void onWorldCleanup() {
                cleanupCount[0]++;
            }
        };

        assertFalse(dummy.isEnabled());
        dummy.toggle();
        assertTrue(dummy.isEnabled());
        dummy.onWorldCleanup();
        assertEquals(1, cleanupCount[0]);

        for (int i = 0; i < 12; i++) {
            dummy.handleModuleError("onTick", new RuntimeException("Simulated fault"));
        }
        assertFalse(dummy.isEnabled(), "Module should auto-disable after repeated consecutive errors");
    }

    @Test
    void testModuleManagerCapacityAndKeybindConflictDetection() {
        ModuleManager manager = new ModuleManager();
        assertEquals(15, ModuleManager.TARGET_MODULE_CAPACITY);

        Module m1 = new Module("m1", "Alpha", "desc", Category.COMBAT) {};
        Module m2 = new Module("m2", "Beta", "desc", Category.RENDER) {};
        manager.register(m1);
        manager.register(m2);

        m1.getToggleKeybind().setValue(82);
        assertFalse(manager.hasKeybindConflict(m1.getToggleKeybind()));

        m2.getToggleKeybind().setValue(82);
        assertTrue(manager.hasKeybindConflict(m1.getToggleKeybind()));
        assertTrue(manager.hasKeybindConflict(m2.getToggleKeybind()));
    }

    @Test
    void testRotationShortestArcAndNoSnapMath() {
        float smoothed = RotationUtil.smoothAngle(179.0f, -179.0f, 0.5f);
        assertEquals(180.0f, smoothed, 0.01f);

        float[] rots = RotationUtil.getRotationsTo(new Vec3d(0, 64, 0), new Vec3d(0, 64, 10));
        assertEquals(0.0f, rots[0], 0.01f);
        assertEquals(0.0f, rots[1], 0.01f);
    }

    @Test
    void testThemeColorLerp() {
        int mid = NexusTheme.lerpColor(0xFF000000, 0xFFFFFFFF, 0.5f);
        assertEquals(0xFF808080, mid);
    }
}
