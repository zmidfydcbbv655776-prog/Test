package dev.nexus.client.mixin;

import dev.nexus.client.module.impl.render.FreecamModule;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(WorldRenderer.class)
public abstract class WorldRendererMixin {
    @ModifyVariable(method = "updateCamera", at = @At("HEAD"), argsOnly = true, ordinal = 0, require = 0)
    private boolean nexus$bypassChunkCullingInFreecam(boolean spectator) {
        return spectator || FreecamModule.isFreecamActive();
    }

    @Inject(method = "isRenderingReady", at = @At("HEAD"), cancellable = true, require = 0)
    private void nexus$freecamChunksReady(BlockPos pos, CallbackInfoReturnable<Boolean> cir) {
        if (FreecamModule.isFreecamActive()) {
            cir.setReturnValue(true);
        }
    }
}
