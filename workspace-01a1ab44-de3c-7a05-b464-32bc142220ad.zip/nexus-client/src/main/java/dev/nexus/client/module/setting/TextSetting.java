package dev.nexus.client.module.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public final class TextSetting extends Setting<String> {
    private final int maxLength;

    public TextSetting(String key, String name, String description, String defaultValue, int maxLength) {
        super(key, name, description, defaultValue == null ? "" : defaultValue);
        this.maxLength = Math.max(1, maxLength);
        this.value = validate(defaultValue);
    }

    public int getMaxLength() {
        return maxLength;
    }

    @Override
    protected String validate(String candidate) {
        if (candidate == null) {
            return getDefaultValue();
        }
        String sanitized = candidate.replace("\r", "").replace("\n", "");
        int limit = maxLength > 0 ? maxLength : 256;
        if (sanitized.length() > limit) {
            sanitized = sanitized.substring(0, limit);
        }
        return sanitized;
    }

    @Override
    public JsonElement toJson() {
        return new JsonPrimitive(getValue());
    }

    @Override
    public void fromJson(JsonElement element) {
        if (element != null && element.isJsonPrimitive() && element.getAsJsonPrimitive().isString()) {
            setValue(element.getAsString());
        } else {
            reset();
        }
    }
}
