package dev.nexus.client.module.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import java.util.Locale;

public final class NumberSetting extends Setting<Double> {
    private final double min;
    private final double max;
    private final double step;
    private final int decimals;

    public NumberSetting(String key, String name, String description, double defaultValue, double min, double max, double step) {
        super(key, name, description, clampAndSnap(defaultValue, min, max, step));
        this.min = min;
        this.max = max;
        this.step = step <= 0.0 ? 0.01 : step;
        this.decimals = computeDecimals(this.step);
        this.value = validate(defaultValue);
    }

    private static int computeDecimals(double step) {
        if (Math.abs(step - Math.rint(step)) < 1e-6) {
            return 0;
        }
        if (Math.abs(step * 10.0 - Math.rint(step * 10.0)) < 1e-6) {
            return 1;
        }
        return 2;
    }

    private static double clampAndSnap(double v, double min, double max, double step) {
        if (Double.isNaN(v) || Double.isInfinite(v)) {
            return min;
        }
        double clamped = Math.max(min, Math.min(max, v));
        if (step > 0.0) {
            clamped = min + Math.round((clamped - min) / step) * step;
            clamped = Math.max(min, Math.min(max, clamped));
        }
        return clamped;
    }

    public double getMin() {
        return min;
    }

    public double getMax() {
        return max;
    }

    public double getStep() {
        return step;
    }

    public int getIntValue() {
        return (int) Math.round(getValue());
    }

    public float getFloatValue() {
        return getValue().floatValue();
    }

    public double getNormalized() {
        if (max <= min) {
            return 0.0;
        }
        return Math.max(0.0, Math.min(1.0, (getValue() - min) / (max - min)));
    }

    public void setFromNormalized(double normalized) {
        double clampedNorm = Math.max(0.0, Math.min(1.0, normalized));
        setValue(min + clampedNorm * (max - min));
    }

    public String formatValue() {
        if (decimals == 0) {
            return Integer.toString(getIntValue());
        }
        return String.format(Locale.ROOT, "%." + decimals + "f", getValue());
    }

    @Override
    protected Double validate(Double candidate) {
        if (candidate == null) {
            return getDefaultValue();
        }
        return clampAndSnap(candidate, min, max, step > 0.0 ? step : 0.01);
    }

    @Override
    public JsonElement toJson() {
        return new JsonPrimitive(getValue());
    }

    @Override
    public void fromJson(JsonElement element) {
        if (element != null && element.isJsonPrimitive() && element.getAsJsonPrimitive().isNumber()) {
            setValue(element.getAsDouble());
        } else {
            reset();
        }
    }
}
