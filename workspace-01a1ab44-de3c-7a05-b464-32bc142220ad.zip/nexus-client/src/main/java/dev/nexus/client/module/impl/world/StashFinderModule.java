package dev.nexus.client.module.impl.world;

import dev.nexus.client.event.WorldChunkTracker;
import dev.nexus.client.module.Category;
import dev.nexus.client.module.Module;
import dev.nexus.client.module.setting.ActionSetting;
import dev.nexus.client.module.setting.BooleanSetting;
import dev.nexus.client.module.setting.ModeSetting;
import dev.nexus.client.module.setting.NumberSetting;
import dev.nexus.client.render.NexusTheme;
import dev.nexus.client.render.WorldProjector;
import dev.nexus.client.render.WorldRenderHelper;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.block.BlockState;
import net.minecraft.block.ChestBlock;
import net.minecraft.block.entity.BarrelBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.EnderChestBlockEntity;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.block.entity.TrappedChestBlockEntity;
import net.minecraft.block.entity.TrialSpawnerBlockEntity;
import net.minecraft.block.entity.VaultBlockEntity;
import net.minecraft.block.enums.ChestType;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.WorldChunk;

/**
 * Module I: Stash Finder
 * Modeled after StashFinder.java (https://github.com/zmidfydcbbv655776-prog/New) and adapted cleanly
 * to Minecraft 1.21.11:
 *  - Scans loaded chunks within Range (chunks) for dense clusters of storage containers (>= Min chests within Radius)
 *  - Counts double chests once; optionally includes Barrels / Shulker Boxes & Ender Chests
 *  - Ignores natural Dungeons / Trial Chambers (groups near MobSpawner, TrialSpawner, or Vault block entities)
 *  - Announces new stashes in client chat with container coordinates
 *  - Renders single-batch 3D ESP boxes (whole-stash merged box or individual containers) + 2D HUD labels & tracers.
 */
public final class StashFinderModule extends Module {

    public record StoreNode(BlockPos pos, Box renderBox) {
    }

    public record StashGroup(
        long key,
        BlockPos center,
        int x1, int y1, int z1,
        int x2, int y2, int z2,
        List<StoreNode> boxes
    ) {
    }

    // ---------------- Detection Settings ----------------
    private final NumberSetting minChests = addSetting(
        new NumberSetting("min_chests", "Min chests", "Minimum containers within Radius to count as a stash", 3, 2, 20, 1)
    );
    private final NumberSetting radius = addSetting(
        new NumberSetting("radius", "Radius", "Max clustering distance in blocks between containers", 12, 4, 32, 1)
    );
    private final NumberSetting rangeChunks = addSetting(
        new NumberSetting("range_chunks", "Range (chunks)", "Chunk radius around player to scan for stashes", 6, 2, 32, 1)
    );
    private final BooleanSetting includeExtra = addSetting(
        new BooleanSetting("barrels_shulkers", "Barrels / shulkers", "Include Barrels and Shulker Boxes in stash counts", true)
    );
    private final BooleanSetting includeEnder = addSetting(
        new BooleanSetting("ender_chests", "Ender chests", "Include Ender Chests in stash counts", false)
    );
    private final BooleanSetting ignoreDungeons = addSetting(
        new BooleanSetting("ignore_dungeons", "Ignore dungeons", "Skip container clusters next to Mob/Trial Spawners or Vaults", true)
    );

    // ---------------- Alerts ----------------
    private final BooleanSetting chatAlert = addSetting(
        new BooleanSetting("chat_alert", "Chat alert", "Print newly discovered stashes and coordinates in client chat", true)
    );
    private final BooleanSetting soundAlert = addSetting(
        new BooleanSetting("sound_alert", "Sound alert", "Play notification chime when a new stash is discovered", false)
    );

    // ---------------- Highlight & HUD Settings ----------------
    private final BooleanSetting highlight = addSetting(
        new BooleanSetting("highlight", "Highlight", "Render 3D ESP boxes on discovered stashes", true)
    );
    private final NumberSetting highlightRange = (NumberSetting) addSetting(
        new NumberSetting("highlight_range", "Highlight range", "Max distance in blocks to render stash highlights", 200, 50, 1000, 50)
    ).visibleWhen(highlight::getValue);
    private final NumberSetting maxBoxes = (NumberSetting) addSetting(
        new NumberSetting("max_boxes", "Max boxes", "Maximum 3D boxes drawn per frame (sorted nearest-first)", 300, 25, 1500, 25)
    ).visibleWhen(highlight::getValue);
    private final BooleanSetting mergeOneBox = (BooleanSetting) addSetting(
        new BooleanSetting("one_box_per_stash", "One box per stash", "Draw one bounding box wrapping each stash instead of per-container boxes", false)
    ).visibleWhen(highlight::getValue);
    private final NumberSetting thickness = (NumberSetting) addSetting(
        new NumberSetting("thickness", "Thickness", "3D outline stroke width", 1.8, 1.0, 4.0, 0.2)
    ).visibleWhen(highlight::getValue);
    private final BooleanSetting glow = (BooleanSetting) addSetting(
        new BooleanSetting("glow", "Glow", "Soft glow halo around stash boxes", true)
    ).visibleWhen(highlight::getValue);
    private final BooleanSetting fill = (BooleanSetting) addSetting(
        new BooleanSetting("fill", "Fill", "Draw translucent fill inside stash boxes", true)
    ).visibleWhen(highlight::getValue);
    private final NumberSetting fillOpacity = (NumberSetting) addSetting(
        new NumberSetting("fill_opacity", "Fill opacity", "Translucent fill alpha (10-200)", 40, 10, 200, 10)
    ).visibleWhen(() -> highlight.getValue() && fill.getValue());
    private final ModeSetting colorPreset = addSetting(
        new ModeSetting("color_preset", "Color", "Stash highlight & label color", "Amber Gold",
            "Amber Gold", "Nexus Gold", "Crimson", "Emerald", "Cyan", "Amethyst")
    );
    private final BooleanSetting labels = addSetting(
        new BooleanSetting("labels", "Labels", "Project 2D STASH xN distance tags on screen", true)
    );
    private final BooleanSetting tracers = addSetting(
        new BooleanSetting("tracers", "Tracers", "Draw 2D HUD tracer lines toward discovered stashes", false)
    );
    @SuppressWarnings("unused")
    private final ActionSetting clearRescanBtn = addSetting(
        new ActionSetting("clear_rescan", "Clear & rescan stashes", "Clear remembered stashes and immediately rescan loaded chunks", this::clearAndRescan)
    );

    // ---------------- Runtime State ----------------
    private final Set<Long> reportedKeys = ConcurrentHashMap.newKeySet();
    private final List<StashGroup> groups = new ArrayList<>();
    private volatile List<StashGroup> renderSnapshot = List.of();
    private ClientWorld lastWorld = null;
    private int scanTicks = 0;
    private final double[] projTmp = new double[2];

    public StashFinderModule() {
        super("stash_finder", "Stash Finder", "Detects player storage stashes while filtering out natural dungeons.", Category.WORLD);
    }

    @Override
    protected void onEnable() {
        resetAll();
        lastWorld = mc != null ? mc.world : null;
        if (mc != null && mc.world != null && mc.player != null) {
            runStashScan(mc);
            publishSortedSnapshot(mc);
        }
    }

    @Override
    protected void onDisable() {
        resetAll();
    }

    @Override
    public void onWorldCleanup() {
        resetAll();
    }

    private void resetAll() {
        reportedKeys.clear();
        groups.clear();
        renderSnapshot = List.of();
        lastWorld = null;
        scanTicks = 0;
    }

    public void clearAndRescan() {
        reportedKeys.clear();
        groups.clear();
        renderSnapshot = List.of();
        scanTicks = 40;
        if (mc != null && mc.world != null && mc.player != null) {
            runStashScan(mc);
            publishSortedSnapshot(mc);
        }
    }

    private int resolveBaseColor() {
        return switch (colorPreset.getValue()) {
            case "Nexus Gold" -> NexusTheme.GOLD_BRIGHT;
            case "Crimson"    -> 0xFFE74C3C;
            case "Emerald"    -> 0xFF2ECC71;
            case "Cyan"       -> 0xFF38D9FF;
            case "Amethyst"   -> 0xFFC056F5;
            default           -> 0xFFFF8C1A; // Warm Amber/Orange matching StashFinder.java (hue 0.08f)
        };
    }

    @Override
    public void onTick(MinecraftClient client) {
        if (client.world == null || client.player == null) {
            resetAll();
            return;
        }
        if (client.world != lastWorld) {
            resetAll();
            lastWorld = client.world;
        }

        scanTicks++;
        if (scanTicks % 10 == 0 && groups.size() > 1) {
            publishSortedSnapshot(client);
        }
        if (scanTicks < 40) {
            return;
        }
        scanTicks = 0;
        runStashScan(client);
        publishSortedSnapshot(client);
    }

    private void publishSortedSnapshot(MinecraftClient client) {
        if (groups.isEmpty() || client.player == null) {
            renderSnapshot = List.of();
            return;
        }
        BlockPos playerPos = client.player.getBlockPos();
        groups.sort(Comparator.comparingDouble(g -> g.center().getSquaredDistance(playerPos)));
        renderSnapshot = List.copyOf(groups);
    }

    private void runStashScan(MinecraftClient client) {
        ClientWorld world = client.world;
        int chunkRad = rangeChunks.getIntValue();
        int pcx = client.player.getChunkPos().x;
        int pcz = client.player.getChunkPos().z;
        boolean extras = includeExtra.getValue();
        boolean enders = includeEnder.getValue();
        boolean skipStruct = ignoreDungeons.getValue();

        List<StoreNode> stores = new ArrayList<>();
        List<BlockPos> spawners = new ArrayList<>();

        outer:
        for (int dx = -chunkRad; dx <= chunkRad; dx++) {
            for (int dz = -chunkRad; dz <= chunkRad; dz++) {
                int cx = pcx + dx;
                int cz = pcz + dz;
                if (!WorldChunkTracker.isChunkCurrentlyLoaded(world, cx, cz)) {
                    continue;
                }
                WorldChunk chunk = world.getChunkManager().getWorldChunk(cx, cz);
                if (chunk == null || chunk.isEmpty()) {
                    continue;
                }

                for (BlockEntity be : chunk.getBlockEntities().values()) {
                    BlockPos pos = be.getPos();
                    if (be instanceof ChestBlockEntity || be instanceof TrappedChestBlockEntity) {
                        BlockState state = be.getCachedState();
                        if (state != null && state.contains(ChestBlock.CHEST_TYPE)) {
                            ChestType ct = state.get(ChestBlock.CHEST_TYPE);
                            if (ct == ChestType.RIGHT) {
                                continue; // Count double chests once
                            }
                            if (ct == ChestType.LEFT) {
                                Direction otherDir = ChestBlock.getFacing(state);
                                BlockPos other = pos.offset(otherDir);
                                Box merged = new Box(
                                    Math.min(pos.getX(), other.getX()),
                                    pos.getY(),
                                    Math.min(pos.getZ(), other.getZ()),
                                    Math.max(pos.getX(), other.getX()) + 1.0,
                                    pos.getY() + 1.0,
                                    Math.max(pos.getZ(), other.getZ()) + 1.0
                                );
                                stores.add(new StoreNode(pos.toImmutable(), merged));
                            } else {
                                stores.add(new StoreNode(pos.toImmutable(), fullBlockBox(pos)));
                            }
                        } else {
                            stores.add(new StoreNode(pos.toImmutable(), fullBlockBox(pos)));
                        }
                        if (stores.size() >= 3000) {
                            break outer;
                        }
                    } else if (extras && (be instanceof BarrelBlockEntity || be instanceof ShulkerBoxBlockEntity)) {
                        stores.add(new StoreNode(pos.toImmutable(), fullBlockBox(pos)));
                        if (stores.size() >= 3000) {
                            break outer;
                        }
                    } else if (enders && be instanceof EnderChestBlockEntity) {
                        stores.add(new StoreNode(pos.toImmutable(), fullBlockBox(pos)));
                        if (stores.size() >= 3000) {
                            break outer;
                        }
                    } else if (skipStruct && (be instanceof MobSpawnerBlockEntity
                        || be instanceof TrialSpawnerBlockEntity
                        || be instanceof VaultBlockEntity)) {
                        spawners.add(pos.toImmutable());
                    }
                }
            }
        }

        int total = stores.size();
        int need = minChests.getIntValue();
        if (total < need) {
            return;
        }

        double r = radius.getValue();
        double rSq = r * r;
        double spawnerGuard = r * 0.5 + 6.0;
        double spawnerGuardSq = spawnerGuard * spawnerGuard;
        boolean[] used = new boolean[total];

        for (int i = 0; i < total; i++) {
            if (used[i]) continue;
            StoreNode seed = stores.get(i);
            List<StoreNode> cluster = new ArrayList<>();
            cluster.add(seed);
            used[i] = true;

            // Transitive single-linkage BFS within Radius so contiguous stash rooms merge cleanly
            for (int q = 0; q < cluster.size(); q++) {
                BlockPos pivot = cluster.get(q).pos();
                for (int j = i + 1; j < total; j++) {
                    if (!used[j] && pivot.getSquaredDistance(stores.get(j).pos()) <= rSq) {
                        used[j] = true;
                        cluster.add(stores.get(j));
                    }
                }
            }

            if (cluster.size() < need) {
                continue;
            }

            long sx = 0L, sy = 0L, sz = 0L;
            int x1 = Integer.MAX_VALUE, y1 = Integer.MAX_VALUE, z1 = Integer.MAX_VALUE;
            int x2 = Integer.MIN_VALUE, y2 = Integer.MIN_VALUE, z2 = Integer.MIN_VALUE;

            for (StoreNode node : cluster) {
                Box b = node.renderBox();
                int minBx = (int) Math.floor(b.minX);
                int minBy = (int) Math.floor(b.minY);
                int minBz = (int) Math.floor(b.minZ);
                int maxBx = (int) Math.ceil(b.maxX) - 1;
                int maxBy = (int) Math.ceil(b.maxY) - 1;
                int maxBz = (int) Math.ceil(b.maxZ) - 1;

                sx += node.pos().getX();
                sy += node.pos().getY();
                sz += node.pos().getZ();

                if (minBx < x1) x1 = minBx;
                if (minBy < y1) y1 = minBy;
                if (minBz < z1) z1 = minBz;
                if (maxBx > x2) x2 = maxBx;
                if (maxBy > y2) y2 = maxBy;
                if (maxBz > z2) z2 = maxBz;
            }

            BlockPos center = new BlockPos(
                (int) (sx / cluster.size()),
                (int) (sy / cluster.size()),
                (int) (sz / cluster.size())
            );

            if (skipStruct && isNearSpawner(center, spawners, spawnerGuardSq)) {
                continue;
            }

            // Spatial grid key (~16-block bucket) prevents duplicate chat spam as neighbor containers load
            long key = BlockPos.asLong(center.getX() >> 4, center.getY() >> 4, center.getZ() >> 4);
            StashGroup group = new StashGroup(key, center, x1, y1, z1, x2, y2, z2, List.copyOf(cluster));

            if (!reportedKeys.add(key)) {
                // Update existing group if more containers loaded in the same stash
                for (int gi = 0; gi < groups.size(); gi++) {
                    if (groups.get(gi).key() == key && group.boxes().size() > groups.get(gi).boxes().size()) {
                        groups.set(gi, group);
                        break;
                    }
                }
                continue;
            }

            groups.add(group);
            announceStash(client, group, (int) r);
        }
    }

    private void announceStash(MinecraftClient client, StashGroup stash, int rad) {
        if (soundAlert.getValue() && client.player != null) {
            client.player.playSound(SoundEvents.BLOCK_NOTE_BLOCK_PLING.value(), 0.85f, 1.25f);
        }
        if (!chatAlert.getValue() || client.player == null) {
            return;
        }
        List<StoreNode> list = stash.boxes();
        client.player.sendMessage(
            Text.literal("[Stash Finder] ").formatted(Formatting.GOLD)
                .append(Text.literal(list.size() + " containers within " + rad + "m:").formatted(Formatting.WHITE)),
            false
        );
        int limit = Math.min(list.size(), 10);
        for (int k = 0; k < limit; k++) {
            BlockPos p = list.get(k).pos();
            client.player.sendMessage(
                Text.literal(String.format(Locale.ROOT, "  #%d  %d, %d, %d", k + 1, p.getX(), p.getY(), p.getZ()))
                    .formatted(Formatting.GRAY),
                false
            );
        }
        if (list.size() > limit) {
            client.player.sendMessage(
                Text.literal("  ... and " + (list.size() - limit) + " more").formatted(Formatting.DARK_GRAY),
                false
            );
        }
    }

    private static Box fullBlockBox(BlockPos pos) {
        return new Box(pos.getX(), pos.getY(), pos.getZ(), pos.getX() + 1.0, pos.getY() + 1.0, pos.getZ() + 1.0);
    }

    private static boolean isNearSpawner(BlockPos center, List<BlockPos> spawners, double maxSq) {
        for (BlockPos sp : spawners) {
            if (center.getSquaredDistance(sp) <= maxSq) {
                return true;
            }
        }
        return false;
    }

    // ---------------- 3D World Rendering ----------------

    @Override
    public void onRenderWorld(WorldRenderContext context) {
        if (!highlight.getValue()) {
            return;
        }
        List<StashGroup> snapshot = renderSnapshot;
        if (snapshot.isEmpty() || mc == null || mc.player == null) {
            return;
        }

        int baseRgb = resolveBaseColor();
        int strokeArgb = NexusTheme.withAlpha(baseRgb, 235);
        int fillArgb = fill.getValue() ? NexusTheme.withAlpha(baseRgb, fillOpacity.getIntValue()) : 0;
        float t = thickness.getFloatValue();
        boolean glowOn = glow.getValue();
        boolean mergedBox = mergeOneBox.getValue();

        double maxDist = highlightRange.getValue();
        double maxDistSq = maxDist * maxDist;
        int cap = maxBoxes.getIntValue();
        int drawn = 0;
        Vec3d camPos = WorldProjector.camPos;

        for (StashGroup st : snapshot) {
            if (drawn >= cap) break;
            BlockPos c = st.center();
            if (camPos.squaredDistanceTo(c.getX() + 0.5, c.getY() + 0.5, c.getZ() + 0.5) > maxDistSq) {
                continue;
            }

            if (mergedBox) {
                Box fullStashBox = new Box(
                    st.x1(), st.y1(), st.z1(),
                    st.x2() + 1.0, st.y2() + 1.0, st.z2() + 1.0
                );
                WorldRenderHelper.drawBoxGlow(fullStashBox, strokeArgb, t, fillArgb, glowOn, true);
                drawn++;
            } else {
                for (StoreNode node : st.boxes()) {
                    if (drawn >= cap) break;
                    Box inset = node.renderBox().contract(0.015);
                    WorldRenderHelper.drawBoxGlow(inset, strokeArgb, t, fillArgb, glowOn, true);
                    drawn++;
                }
            }
        }
    }

    // ---------------- 2D HUD Labels & Tracers ----------------

    @Override
    public void onRenderHud(DrawContext drawContext, RenderTickCounter tickCounter) {
        boolean drawLabels = labels.getValue();
        boolean drawTracers = tracers.getValue();
        if ((!drawLabels && !drawTracers) || !WorldProjector.isReady() || mc == null || mc.player == null) {
            return;
        }
        List<StashGroup> snapshot = renderSnapshot;
        if (snapshot.isEmpty()) {
            return;
        }

        int baseRgb = resolveBaseColor();
        double maxDist = highlightRange.getValue();
        double maxDistSq = maxDist * maxDist;
        double midX = drawContext.getScaledWindowWidth() * 0.5;
        double midY = drawContext.getScaledWindowHeight() * 0.5;
        Vec3d camPos = WorldProjector.camPos;

        int shownLabels = 0;
        for (StashGroup st : snapshot) {
            BlockPos c = st.center();
            double cx = c.getX() + 0.5;
            double cy = st.y2() + 1.4;
            double cz = c.getZ() + 0.5;
            double dSq = camPos.squaredDistanceTo(cx, c.getY() + 0.5, cz);
            if (dSq > maxDistSq) {
                continue;
            }

            if (drawTracers && WorldProjector.projectOrPoint(cx, c.getY() + 0.5, cz, projTmp)) {
                NexusTheme.drawLine2D(drawContext, midX, midY, projTmp[0], projTmp[1], NexusTheme.withAlpha(baseRgb, 165));
            }

            if (drawLabels && shownLabels < 12 && WorldProjector.project(cx, cy, cz, projTmp)) {
                int dist = (int) Math.round(Math.sqrt(dSq));
                String tag = String.format(Locale.ROOT, "STASH x%d  %dm", st.boxes().size(), dist);
                NexusTheme.drawFloatingTag(
                    drawContext,
                    mc.textRenderer,
                    tag,
                    (int) Math.round(projTmp[0]),
                    (int) Math.round(projTmp[1]),
                    baseRgb,
                    false
                );
                shownLabels++;
            }
        }
    }
}
