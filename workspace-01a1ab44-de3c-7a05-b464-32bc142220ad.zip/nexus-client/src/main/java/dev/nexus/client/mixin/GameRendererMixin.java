package dev.nexus.client.mixin;

import dev.nexus.client.NexusClientMod;
import dev.nexus.client.module.impl.render.FreecamModule;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.RenderTickCounter;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
    @Unique
    private long nexus$lastFrameNano = 0L;

    @Inject(method = "renderWorld", at = @At("HEAD"))
    private void nexus$onBeforeRenderWorld(RenderTickCounter tickCounter, CallbackInfo ci) {
        long now = System.nanoTime();
        float deltaSec = nexus$lastFrameNano == 0L ? (1.0f / 60.0f) : ((now - nexus$lastFrameNano) * 1.0e-9f);
        nexus$lastFrameNano = now;

        NexusClientMod mod = NexusClientMod.getInstance();
        if (mod != null && mod.getEventBus() != null) {
            mod.getEventBus().dispatchRenderFrame(deltaSec);
        }
    }

    @Inject(method = "renderHand", at = @At("HEAD"), cancellable = true)
    private void nexus$hideHandInFreecam(float tickProgress, boolean sleeping, Matrix4f positionMatrix, CallbackInfo ci) {
        if (FreecamModule.isFreecamActive()) {
            ci.cancel();
        }
    }
}
