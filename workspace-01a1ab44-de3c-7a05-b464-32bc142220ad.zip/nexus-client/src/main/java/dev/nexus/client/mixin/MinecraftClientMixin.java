package dev.nexus.client.mixin;

import dev.nexus.client.module.impl.render.FreecamModule;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(MinecraftClient.class)
public abstract class MinecraftClientMixin {
    @Inject(method = "doAttack", at = @At("HEAD"), cancellable = true)
    private void nexus$guardAttackInFreecam(CallbackInfoReturnable<Boolean> cir) {
        FreecamModule freecam = FreecamModule.getInstance();
        if (freecam != null && freecam.shouldBlockPlayerActions()) {
            cir.setReturnValue(false);
        }
    }

    @Inject(method = "doItemUse", at = @At("HEAD"), cancellable = true)
    private void nexus$guardItemUseInFreecam(CallbackInfo ci) {
        FreecamModule freecam = FreecamModule.getInstance();
        if (freecam != null && freecam.shouldBlockPlayerActions()) {
            ci.cancel();
        }
    }

    @Inject(method = "handleBlockBreaking", at = @At("HEAD"), cancellable = true)
    private void nexus$guardBlockBreakInFreecam(boolean breaking, CallbackInfo ci) {
        FreecamModule freecam = FreecamModule.getInstance();
        if (freecam != null && freecam.shouldBlockPlayerActions()) {
            ci.cancel();
        }
    }
}
