package dev.nexus.client.render;

/**
 * Coordinates top-left HUD vertical stacking across multiple active modules so panels never overlap.
 */
public final class HudLayoutHelper {
    private static int topLeftCursorY = 8;

    private HudLayoutHelper() {
    }

    public static void beginHudPass() {
        topLeftCursorY = 8;
    }

    public static int claimTopLeftY(int panelHeight, int spacing) {
        int y = topLeftCursorY;
        topLeftCursorY += Math.max(0, panelHeight) + Math.max(0, spacing);
        return y;
    }
}
