package dev.nexus.client.module.impl.render;

import dev.nexus.client.module.Category;
import dev.nexus.client.module.Module;
import dev.nexus.client.module.setting.BooleanSetting;
import dev.nexus.client.module.setting.ModeSetting;
import dev.nexus.client.module.setting.NumberSetting;
import dev.nexus.client.render.NexusTheme;
import dev.nexus.client.render.WorldProjector;
import dev.nexus.client.render.WorldRenderHelper;
import java.util.Locale;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/**
 * Module D: Player ESP
 * Displays client-loaded players with configurable bounding box, glow, tracers, nametag, color, and range.
 * Uses single-batch QUADS 3D rendering and 2D screen projection — zero GizmoDrawing crashes.
 */
public final class PlayerEspModule extends Module {
    private final ModeSetting boxStyle = addSetting(
        new ModeSetting("box_style", "Box Style", "Bounding box appearance", "Box + Fill", "Box + Fill", "Outline Only")
    );
    private final ModeSetting colorPreset = addSetting(
        new ModeSetting("color_preset", "Color Theme", "ESP color preset or Custom RGB", "Nexus Gold",
            "Nexus Gold", "Crimson", "Cyan", "Emerald", "White", "Custom RGB")
    );
    private final NumberSetting customRed = (NumberSetting) addSetting(
        new NumberSetting("custom_r", "Custom Red", "Red channel (0-255)", 212, 0, 255, 1)
    ).visibleWhen(() -> colorPreset.isMode("Custom RGB"));
    private final NumberSetting customGreen = (NumberSetting) addSetting(
        new NumberSetting("custom_g", "Custom Green", "Green channel (0-255)", 175, 0, 255, 1)
    ).visibleWhen(() -> colorPreset.isMode("Custom RGB"));
    private final NumberSetting customBlue = (NumberSetting) addSetting(
        new NumberSetting("custom_b", "Custom Blue", "Blue channel (0-255)", 55, 0, 255, 1)
    ).visibleWhen(() -> colorPreset.isMode("Custom RGB"));

    private final NumberSetting lineWidth = addSetting(
        new NumberSetting("line_width", "Line Thickness", "Bounding box stroke width", 2.0, 1.0, 4.5, 0.2)
    );
    private final BooleanSetting glow = addSetting(
        new BooleanSetting("glow", "Outline Glow", "Soft glow halo around player boxes", true)
    );
    private final NumberSetting maxDistance = addSetting(
        new NumberSetting("max_distance", "Max Distance", "Maximum display distance in blocks", 160, 16, 256, 8)
    );
    private final BooleanSetting showNametags = addSetting(
        new BooleanSetting("show_names", "Show Player Name", "Display projected player name, health & distance tag", true)
    );
    private final BooleanSetting tracers = addSetting(
        new BooleanSetting("tracers", "Tracers", "Draw tracer line toward loaded players", false)
    );
    private final BooleanSetting ignoreInvisible = addSetting(
        new BooleanSetting("ignore_invisible", "Ignore Invisible", "Skip invisible players", false)
    );

    private final double[] projTmp = new double[2];

    public PlayerEspModule() {
        super("player_esp", "Player ESP", "Highlights players in loaded range with configurable box & label.", Category.RENDER);
    }

    private int resolveBaseColor() {
        return switch (colorPreset.getValue()) {
            case "Crimson" -> 0xFFE74C3C;
            case "Cyan" -> 0xFF00D2FF;
            case "Emerald" -> 0xFF2ECC71;
            case "White" -> 0xFFF5F5F7;
            case "Custom RGB" -> (0xFF << 24)
                | ((customRed.getIntValue() & 0xFF) << 16)
                | ((customGreen.getIntValue() & 0xFF) << 8)
                | (customBlue.getIntValue() & 0xFF);
            default -> NexusTheme.GOLD_BRIGHT;
        };
    }

    @Override
    public void onRenderWorld(WorldRenderContext context) {
        if (mc == null || mc.world == null || mc.player == null || mc.gameRenderer == null) {
            return;
        }
        float tickProgress = WorldProjector.tickProgress;
        Vec3d camPos = WorldProjector.camPos;
        double maxDist = maxDistance.getValue();
        double maxDistSq = maxDist * maxDist;

        int baseColor = resolveBaseColor();
        int strokeArgb = NexusTheme.withAlpha(baseColor, 240);
        int fillArgb = boxStyle.isMode("Box + Fill") ? NexusTheme.withAlpha(baseColor, 42) : 0;
        float width = lineWidth.getFloatValue();
        boolean glowOn = glow.getValue();

        for (AbstractClientPlayerEntity target : mc.world.getPlayers()) {
            if (target == mc.player || target.isRemoved() || !target.isAlive() || target.isSpectator()) {
                continue;
            }
            if (ignoreInvisible.getValue() && target.isInvisible()) {
                continue;
            }

            double interpX = MathHelper.lerp(tickProgress, target.lastRenderX, target.getX());
            double interpY = MathHelper.lerp(tickProgress, target.lastRenderY, target.getY());
            double interpZ = MathHelper.lerp(tickProgress, target.lastRenderZ, target.getZ());

            double dSq = camPos.squaredDistanceTo(interpX, interpY + target.getHeight() * 0.5, interpZ);
            if (dSq > maxDistSq) {
                continue;
            }

            double halfW = target.getWidth() * 0.5 + 0.04;
            double height = target.getHeight() + 0.06;
            Box renderBox = new Box(
                interpX - halfW, interpY, interpZ - halfW,
                interpX + halfW, interpY + height, interpZ + halfW
            );

            WorldRenderHelper.drawBoxGlow(renderBox, strokeArgb, width, fillArgb, glowOn, true);
        }
    }

    @Override
    public void onRenderHud(DrawContext drawContext, RenderTickCounter tickCounter) {
        if (mc == null || mc.world == null || mc.player == null || !WorldProjector.isReady()) {
            return;
        }
        boolean drawNames = showNametags.getValue();
        boolean drawTracer = tracers.getValue();
        if (!drawNames && !drawTracer) {
            return;
        }

        float tickProgress = tickCounter.getTickProgress(false);
        Vec3d camPos = WorldProjector.camPos;
        double maxDist = maxDistance.getValue();
        double maxDistSq = maxDist * maxDist;
        int baseColor = resolveBaseColor();
        double cx = drawContext.getScaledWindowWidth() * 0.5;
        double cy = drawContext.getScaledWindowHeight() * 0.5;

        for (AbstractClientPlayerEntity target : mc.world.getPlayers()) {
            if (target == mc.player || target.isRemoved() || !target.isAlive() || target.isSpectator()) {
                continue;
            }
            if (ignoreInvisible.getValue() && target.isInvisible()) {
                continue;
            }

            double interpX = MathHelper.lerp(tickProgress, target.lastRenderX, target.getX());
            double interpY = MathHelper.lerp(tickProgress, target.lastRenderY, target.getY());
            double interpZ = MathHelper.lerp(tickProgress, target.lastRenderZ, target.getZ());
            double centerY = interpY + target.getHeight() * 0.5;

            double dSq = camPos.squaredDistanceTo(interpX, centerY, interpZ);
            if (dSq > maxDistSq) {
                continue;
            }

            if (drawTracer && WorldProjector.projectOrPoint(interpX, centerY, interpZ, projTmp)) {
                NexusTheme.drawLine2D(drawContext, cx, cy, projTmp[0], projTmp[1], NexusTheme.withAlpha(baseColor, 170));
            }

            if (drawNames && WorldProjector.project(interpX, interpY + target.getHeight() + 0.35, interpZ, projTmp)) {
                int dist = (int) Math.round(Math.sqrt(dSq));
                int hp = Math.max(0, Math.round(target.getHealth() + target.getAbsorptionAmount()));
                String tag = String.format(Locale.ROOT, "%s  %dHP  %dm", target.getName().getString(), hp, dist);
                NexusTheme.drawFloatingTag(
                    drawContext,
                    mc.textRenderer,
                    tag,
                    (int) Math.round(projTmp[0]),
                    (int) Math.round(projTmp[1]),
                    baseColor,
                    false
                );
            }
        }
    }
}
