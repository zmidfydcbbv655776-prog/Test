package dev.nexus.client.module.setting;

import com.google.gson.JsonElement;
import java.util.Objects;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

public abstract class Setting<T> {
    private final String key;
    private final String name;
    private final String description;
    private final T defaultValue;
    protected T value;
    private BooleanSupplier visibility = () -> true;
    private Consumer<T> changeListener;

    protected Setting(String key, String name, String description, T defaultValue) {
        this.key = Objects.requireNonNull(key, "key");
        this.name = Objects.requireNonNull(name, "name");
        this.description = description == null ? "" : description;
        this.defaultValue = Objects.requireNonNull(defaultValue, "defaultValue");
        this.value = defaultValue;
    }

    public String getKey() {
        return key;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public T getDefaultValue() {
        return defaultValue;
    }

    public T getValue() {
        return value;
    }

    public void setValue(T newValue) {
        T validated = validate(newValue);
        if (!Objects.equals(this.value, validated)) {
            this.value = validated;
            if (changeListener != null) {
                try {
                    changeListener.accept(this.value);
                } catch (Throwable ignored) {
                }
            }
        }
    }

    public void reset() {
        setValue(defaultValue);
    }

    public Setting<T> visibleWhen(BooleanSupplier condition) {
        this.visibility = condition == null ? () -> true : condition;
        return this;
    }

    public Setting<T> onChange(Consumer<T> listener) {
        this.changeListener = listener;
        return this;
    }

    public boolean isVisible() {
        try {
            return visibility.getAsBoolean();
        } catch (Throwable ignored) {
            return true;
        }
    }

    protected abstract T validate(T candidate);

    public abstract JsonElement toJson();

    public abstract void fromJson(JsonElement element);
}
