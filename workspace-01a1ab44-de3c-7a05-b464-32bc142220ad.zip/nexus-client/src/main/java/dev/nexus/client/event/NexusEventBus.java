package dev.nexus.client.event;

import dev.nexus.client.NexusClientMod;
import dev.nexus.client.config.ConfigManager;
import dev.nexus.client.gui.NexusClickGuiScreen;
import dev.nexus.client.module.Module;
import dev.nexus.client.module.ModuleManager;
import dev.nexus.client.render.HudLayoutHelper;
import dev.nexus.client.render.WorldProjector;
import dev.nexus.client.render.WorldRenderHelper;
import dev.nexus.client.util.KeyUtil;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientChunkEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public final class NexusEventBus {
    private final ModuleManager moduleManager;
    private final ConfigManager configManager;
    private final KeyBinding openGuiKeyBinding;

    private boolean prevRightShiftDown = false;
    private int suppressGuiOpenTicks = 0;
    private int autosaveCounter = 0;

    public NexusEventBus(ModuleManager moduleManager, ConfigManager configManager, KeyBinding openGuiKeyBinding) {
        this.moduleManager = moduleManager;
        this.configManager = configManager;
        this.openGuiKeyBinding = openGuiKeyBinding;
    }

    /**
     * Prevents closing NexusClickGuiScreen with Right Shift from immediately re-opening it on the next client tick.
     */
    public void suppressGuiOpen() {
        this.suppressGuiOpenTicks = 3;
        this.prevRightShiftDown = true;
        while (openGuiKeyBinding != null && openGuiKeyBinding.wasPressed()) {
            // Drain buffered presses
        }
    }

    public void registerAll() {
        ClientTickEvents.END_CLIENT_TICK.register(this::onClientEndTick);

        ClientChunkEvents.CHUNK_LOAD.register((world, chunk) -> {
            WorldChunkTracker.onChunkLoad(world, chunk);
            for (Module module : moduleManager.getModules()) {
                if (module.isEnabled()) {
                    try {
                        module.onChunkLoad(world, chunk);
                    } catch (Throwable t) {
                        module.handleModuleError("onChunkLoad", t);
                    }
                }
            }
        });

        ClientChunkEvents.CHUNK_UNLOAD.register((world, chunk) -> {
            WorldChunkTracker.onChunkUnload(world, chunk);
            for (Module module : moduleManager.getModules()) {
                if (module.isEnabled()) {
                    try {
                        module.onChunkUnload(world, chunk);
                    } catch (Throwable t) {
                        module.handleModuleError("onChunkUnload", t);
                    }
                }
            }
        });

        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            WorldChunkTracker.clear();
            moduleManager.onWorldCleanupAll();
        });

        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            WorldChunkTracker.clear();
            moduleManager.onWorldCleanupAll();
            configManager.save();
        });

        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
            WorldChunkTracker.clear();
            configManager.save();
        });

        // Crash-safe 3D World ESP render pass right after translucent world & outline passes finish
        WorldRenderEvents.END_MAIN.register(this::onWorldEndMain);

        HudElementRegistry.attachElementBefore(
            VanillaHudElements.CHAT,
            Identifier.of(NexusClientMod.MOD_ID, "hud_overlay"),
            this::onRenderHud
        );
    }

    private void onClientEndTick(MinecraftClient client) {
        if (client == null) {
            return;
        }

        boolean rightShiftDown = KeyUtil.isPressed(client, GLFW.GLFW_KEY_RIGHT_SHIFT);

        if (suppressGuiOpenTicks > 0) {
            suppressGuiOpenTicks--;
            while (openGuiKeyBinding != null && openGuiKeyBinding.wasPressed()) {
                // Drain queued key events during suppression window
            }
        } else {
            boolean openRequested = false;
            while (openGuiKeyBinding != null && openGuiKeyBinding.wasPressed()) {
                openRequested = true;
            }
            if (client.currentScreen == null && rightShiftDown && !prevRightShiftDown) {
                openRequested = true;
            }
            if (openRequested) {
                if (client.currentScreen instanceof NexusClickGuiScreen guiScreen) {
                    guiScreen.close();
                } else if (client.currentScreen == null) {
                    client.setScreen(new NexusClickGuiScreen());
                }
            }
        }
        prevRightShiftDown = rightShiftDown;

        // Poll module toggle keybinds cleanly via ModuleManager
        moduleManager.pollModuleToggleKeybinds(client);

        // Tick active modules safely with isolated error recovery
        for (Module module : moduleManager.getModules()) {
            if (module.isEnabled()) {
                try {
                    module.onTick(client);
                    module.resetErrorCounter();
                } catch (Throwable t) {
                    module.handleModuleError("onTick", t);
                }
            }
        }

        // Periodic background autosave every ~60 seconds (1200 ticks) when in game
        if (++autosaveCounter >= 1200) {
            autosaveCounter = 0;
            configManager.save();
        }
    }

    private void onWorldEndMain(WorldRenderContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.world == null || client.gameRenderer == null) {
            return;
        }
        Camera cam = client.gameRenderer.getCamera();
        if (cam == null || !cam.isReady()) {
            return;
        }

        WorldProjector.begin(client);
        var renderCamPos = (context.worldState() != null
            && context.worldState().cameraRenderState != null
            && context.worldState().cameraRenderState.pos != null)
            ? context.worldState().cameraRenderState.pos
            : cam.getCameraPos();
        boolean batchReady = WorldRenderHelper.beginFrame(client, context.matrices(), renderCamPos);
        if (!batchReady) {
            return;
        }
        try {
            for (Module module : moduleManager.getModules()) {
                if (module.isEnabled()) {
                    try {
                        module.onRenderWorld(context);
                    } catch (Throwable t) {
                        module.handleModuleError("onRenderWorld", t);
                    }
                }
            }
        } finally {
            WorldRenderHelper.endFrame(client);
        }
    }

    private void onRenderHud(DrawContext drawContext, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.world == null || client.options.hudHidden) {
            return;
        }
        WorldProjector.begin(client);
        HudLayoutHelper.beginHudPass();

        for (Module module : moduleManager.getModules()) {
            if (module.isEnabled()) {
                try {
                    module.onRenderHud(drawContext, tickCounter);
                } catch (Throwable t) {
                    module.handleModuleError("onRenderHud", t);
                }
            }
        }
    }

    public void dispatchRenderFrame(float frameDeltaSeconds) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.world == null) {
            return;
        }
        for (Module module : moduleManager.getModules()) {
            if (module.isEnabled()) {
                try {
                    module.onRenderFrame(client, frameDeltaSeconds);
                } catch (Throwable t) {
                    module.handleModuleError("onRenderFrame", t);
                }
            }
        }
    }
}
