package dev.nexus.client.util;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class RotationUtil {
    private RotationUtil() {
    }

    public static float[] getRotationsTo(Vec3d eyePos, Vec3d targetPos) {
        double dx = targetPos.x - eyePos.x;
        double dy = targetPos.y - eyePos.y;
        double dz = targetPos.z - eyePos.z;
        double horizontalDist = Math.sqrt(dx * dx + dz * dz);

        float yaw = (float) (MathHelper.atan2(dz, dx) * (180.0 / Math.PI)) - 90.0f;
        float pitch = (float) (-(MathHelper.atan2(dy, horizontalDist) * (180.0 / Math.PI)));
        return new float[]{MathHelper.wrapDegrees(yaw), MathHelper.clamp(pitch, -90.0f, 90.0f)};
    }

    public static Vec3d getAimPoint(PlayerEntity player, Entity target, String mode) {
        Box box = target.getBoundingBox();
        Vec3d eye = player.getEyePos();
        double centerX = (box.minX + box.maxX) * 0.5;
        double centerZ = (box.minZ + box.maxZ) * 0.5;
        double height = box.maxY - box.minY;

        double aimY = switch (mode) {
            case "Eyes" -> target.getEyeY();
            case "Adaptive" -> MathHelper.clamp(eye.y, box.minY + height * 0.2, box.maxY - height * 0.1);
            default -> box.minY + height * 0.62; // Chest
        };
        return new Vec3d(centerX, aimY, centerZ);
    }

    public static double getAngleDifference(float currentYaw, float currentPitch, float targetYaw, float targetPitch) {
        float dYaw = MathHelper.wrapDegrees(targetYaw - currentYaw);
        float dPitch = targetPitch - currentPitch;
        return Math.sqrt(dYaw * dYaw + dPitch * dPitch);
    }

    public static float smoothAngle(float current, float target, float factor) {
        float delta = MathHelper.wrapDegrees(target - current);
        if (Math.abs(delta) < 0.05f) {
            return current;
        }
        return current + delta * MathHelper.clamp(factor, 0.0f, 1.0f);
    }
}
