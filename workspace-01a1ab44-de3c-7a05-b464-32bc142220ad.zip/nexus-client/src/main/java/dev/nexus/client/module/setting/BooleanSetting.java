package dev.nexus.client.module.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public final class BooleanSetting extends Setting<Boolean> {
    public BooleanSetting(String key, String name, String description, boolean defaultValue) {
        super(key, name, description, defaultValue);
    }

    public void toggle() {
        setValue(!getValue());
    }

    @Override
    protected Boolean validate(Boolean candidate) {
        return candidate == null ? getDefaultValue() : candidate;
    }

    @Override
    public JsonElement toJson() {
        return new JsonPrimitive(getValue());
    }

    @Override
    public void fromJson(JsonElement element) {
        if (element != null && element.isJsonPrimitive() && element.getAsJsonPrimitive().isBoolean()) {
            setValue(element.getAsBoolean());
        } else {
            reset();
        }
    }
}
