package dev.nexus.client.render;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.Window;
import net.minecraft.util.math.Vec3d;

/**
 * Projects 3D world coordinates onto GUI-scaled 2D screen coordinates using the live Camera.
 * Zero allocations in hot paths; guards against behind-camera points, NaN, and minimized windows.
 */
public final class WorldProjector {
    private static final double NEAR_CLIP = 0.06;

    public static Vec3d camPos = Vec3d.ZERO;
    public static float tickProgress = 0.0f;
    public static float guiScale = 1.0f;

    private static double fx, fy, fz;
    private static double rx, rz;
    private static double ux, uy, uz;
    private static double tanHalf = 1.0;
    private static double aspect = 1.0;
    private static double sw = 1.0;
    private static double sh = 1.0;
    private static boolean ready = false;

    private static final double[] TMP = new double[2];

    private WorldProjector() {
    }

    public static int width() {
        return (int) sw;
    }

    public static int height() {
        return (int) sh;
    }

    public static boolean isReady() {
        return ready;
    }

    public static boolean begin(MinecraftClient mc) {
        if (mc == null || mc.gameRenderer == null || mc.world == null) {
            ready = false;
            return false;
        }
        Window win = mc.getWindow();
        if (win == null || win.hasZeroWidthOrHeight() || win.getScaledWidth() <= 0 || win.getScaledHeight() <= 0) {
            ready = false;
            return false;
        }
        Camera cam = mc.gameRenderer.getCamera();
        if (cam == null || !cam.isReady()) {
            ready = false;
            return false;
        }

        camPos = cam.getCameraPos();
        tickProgress = mc.getRenderTickCounter().getTickProgress(false);

        double yawRad = Math.toRadians(cam.getYaw());
        double pitchRad = Math.toRadians(cam.getPitch());
        double sy = Math.sin(yawRad);
        double cy = Math.cos(yawRad);
        double sp = Math.sin(pitchRad);
        double cp = Math.cos(pitchRad);

        // Forward, Right, and Up basis vectors in Minecraft world space (+Z south, -Z north)
        fx = -sy * cp;
        fy = -sp;
        fz = cy * cp;

        rx = -cy;
        rz = -sy;

        ux = -sy * sp;
        uy = cp;
        uz = cy * sp;

        double fovDeg = 70.0;
        if (mc.options != null && mc.options.getFov() != null) {
            fovDeg = Math.max(10.0, Math.min(170.0, mc.options.getFov().getValue()));
        }
        tanHalf = Math.max(1e-4, Math.tan(Math.toRadians(fovDeg) * 0.5));
        sw = win.getScaledWidth();
        sh = win.getScaledHeight();
        aspect = sw / Math.max(1.0, sh);
        guiScale = Math.max(1.0f, (float) win.getScaleFactor());
        ready = true;
        return true;
    }

    public static double depth(double x, double y, double z) {
        return (x - camPos.x) * fx + (y - camPos.y) * fy + (z - camPos.z) * fz;
    }

    /**
     * Projects (x, y, z) to GUI screen coordinates out[0], out[1].
     * Returns false if behind near plane or invalid.
     */
    public static boolean project(double x, double y, double z, double[] out) {
        if (!ready) {
            return false;
        }
        double dx = x - camPos.x;
        double dy = y - camPos.y;
        double dz = z - camPos.z;
        double zc = dx * fx + dy * fy + dz * fz;
        if (zc < 0.05) {
            return false;
        }
        double xc = dx * rx + dz * rz;
        double yc = dx * ux + dy * uy + dz * uz;
        double sx = (xc / (zc * tanHalf * aspect) * 0.5 + 0.5) * sw;
        double sy = (0.5 - yc / (zc * tanHalf) * 0.5) * sh;
        if (!Double.isFinite(sx) || !Double.isFinite(sy)) {
            return false;
        }
        out[0] = sx;
        out[1] = sy;
        return true;
    }

    /**
     * Projects (x, y, z) onto screen, or pushes behind-camera points toward the edge in the proper direction
     * so HUD tracers and off-screen indicators always point the right way.
     */
    public static boolean projectOrPoint(double x, double y, double z, double[] out) {
        if (!ready) {
            return false;
        }
        if (project(x, y, z, out)) {
            return true;
        }
        double dx = x - camPos.x;
        double dy = y - camPos.y;
        double dz = z - camPos.z;
        double xc = dx * rx + dz * rz;
        double yc = dx * ux + dy * uy + dz * uz;
        double len = Math.hypot(xc, yc);
        if (len < 1e-6) {
            xc = 0.0;
            yc = -1.0;
            len = 1.0;
        }
        double far = (sw + sh) * 1.5;
        out[0] = sw * 0.5 + (xc / len) * far;
        out[1] = sh * 0.5 - (yc / len) * far;
        return true;
    }

    /**
     * Clips a 3D line segment against the camera near plane and projects both endpoints to {x1, y1, x2, y2}.
     */
    public static boolean segment(double ax, double ay, double az, double bx, double by, double bz, double[] out) {
        if (!ready) {
            return false;
        }
        double da = depth(ax, ay, az);
        double db = depth(bx, by, bz);
        if (da < NEAR_CLIP && db < NEAR_CLIP) {
            return false;
        }
        if (da < NEAR_CLIP) {
            double t = (NEAR_CLIP - da) / (db - da);
            ax += (bx - ax) * t;
            ay += (by - ay) * t;
            az += (bz - az) * t;
        } else if (db < NEAR_CLIP) {
            double t = (NEAR_CLIP - db) / (da - db);
            bx += (ax - bx) * t;
            by += (ay - by) * t;
            bz += (az - bz) * t;
        }
        if (!project(ax, ay, az, TMP)) {
            return false;
        }
        out[0] = TMP[0];
        out[1] = TMP[1];
        if (!project(bx, by, bz, TMP)) {
            return false;
        }
        out[2] = TMP[0];
        out[3] = TMP[1];
        return true;
    }
}
