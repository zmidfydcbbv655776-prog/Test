package dev.nexus.client.render;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.vertex.VertexFormat;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BuiltBuffer;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Single-Batch 3D World ESP Renderer for Minecraft 1.21.11.
 *
 * Replaces vanilla GizmoDrawing completely to avoid two fatal 1.21.11 Gizmo bugs:
 *  1) WorldRenderer.renderLateDebug calling CommandEncoder.clearDepthTexture(...) on mobile/GL4ES/FBOs,
 *  2) GizmoDrawerImpl sorting translucent DEBUG_QUADS into the same shared BufferAllocator holding the vertex buffer.
 *
 * All boxes, edges, flat cluster outlines, glow dots, tracers, and arrows are emitted as camera-relative
 * POSITION_COLOR QUADS into dedicated BufferAllocators and flushed in ONE GPU drawIndexed pass wrapped in try/catch.
 */
public final class WorldRenderHelper {
    private static final Logger LOGGER = LoggerFactory.getLogger("NexusClient");

    private static final Vector4f COLOR_MODULATOR = new Vector4f(1.0f, 1.0f, 1.0f, 1.0f);
    private static final Vector3f MODEL_OFFSET = new Vector3f();
    private static final Matrix4f TEXTURE_MATRIX = new Matrix4f();
    private static final Matrix4f VIEW_MAT = new Matrix4f();
    private static final Vector3f TMP_VEC = new Vector3f();
    private static final Vector3f CAM_RIGHT = new Vector3f(1.0f, 0.0f, 0.0f);
    private static final Vector3f CAM_UP = new Vector3f(0.0f, 1.0f, 0.0f);

    private static RenderPipeline seeThroughPipeline;
    private static RenderPipeline depthTestedPipeline;
    private static BufferAllocator seeThroughAllocator;
    private static BufferAllocator depthAllocator;
    private static boolean pipelineInitFailed = false;
    private static boolean flushErrorLogged = false;

    private static BufferBuilder seeThroughBuf;
    private static BufferBuilder depthBuf;
    private static double camX, camY, camZ;
    private static double pxPerUnit = 0.002;
    private static float guiScale = 1.0f;

    private WorldRenderHelper() {
    }

    private static boolean ensureInitialized() {
        if (pipelineInitFailed) {
            return false;
        }
        if (seeThroughPipeline != null && depthTestedPipeline != null) {
            return true;
        }
        try {
            seeThroughPipeline = RenderPipelines.register(
                RenderPipeline.builder()
                    .withLocation(Identifier.of("nexusclient", "pipeline/esp_quads_through"))
                    .withVertexShader("core/position_color")
                    .withFragmentShader("core/position_color")
                    .withUniform("DynamicTransforms", UniformType.UNIFORM_BUFFER)
                    .withUniform("Projection", UniformType.UNIFORM_BUFFER)
                    .withVertexFormat(VertexFormats.POSITION_COLOR, VertexFormat.DrawMode.QUADS)
                    .withBlend(BlendFunction.TRANSLUCENT)
                    .withCull(false)
                    .withDepthWrite(false)
                    .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                    .build()
            );
            depthTestedPipeline = RenderPipelines.register(
                RenderPipeline.builder()
                    .withLocation(Identifier.of("nexusclient", "pipeline/esp_quads_depth"))
                    .withVertexShader("core/position_color")
                    .withFragmentShader("core/position_color")
                    .withUniform("DynamicTransforms", UniformType.UNIFORM_BUFFER)
                    .withUniform("Projection", UniformType.UNIFORM_BUFFER)
                    .withVertexFormat(VertexFormats.POSITION_COLOR, VertexFormat.DrawMode.QUADS)
                    .withBlend(BlendFunction.TRANSLUCENT)
                    .withCull(false)
                    .withDepthWrite(false)
                    .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
                    .build()
            );
            seeThroughAllocator = new BufferAllocator(1 << 19); // 512 KB dedicated native buffer
            depthAllocator = new BufferAllocator(1 << 17);      // 128 KB dedicated native buffer
            return true;
        } catch (Throwable t) {
            pipelineInitFailed = true;
            LOGGER.error("[NEXUS] Failed to initialize 3D ESP RenderPipeline: {}", t.toString());
            return false;
        }
    }

    public static boolean beginFrame(MinecraftClient mc, MatrixStack matrices, Vec3d cameraPos) {
        if (mc == null || cameraPos == null || !ensureInitialized()) {
            seeThroughBuf = null;
            depthBuf = null;
            return false;
        }
        try {
            Matrix4f modelView = RenderSystem.getModelViewMatrix();
            modelView.getRow(0, CAM_RIGHT);
            modelView.getRow(1, CAM_UP);
            if (CAM_RIGHT.lengthSquared() < 1e-4f) CAM_RIGHT.set(1.0f, 0.0f, 0.0f);
            else CAM_RIGHT.normalize();
            if (CAM_UP.lengthSquared() < 1e-4f) CAM_UP.set(0.0f, 1.0f, 0.0f);
            else CAM_UP.normalize();

            if (matrices != null) {
                VIEW_MAT.set(matrices.peek().getPositionMatrix());
            } else {
                VIEW_MAT.identity();
            }

            camX = cameraPos.x;
            camY = cameraPos.y;
            camZ = cameraPos.z;

            double fbH = Math.max(1, mc.getWindow().getFramebufferHeight());
            double fovDeg = (mc.options != null && mc.options.getFov() != null)
                ? Math.max(10.0, Math.min(170.0, mc.options.getFov().getValue()))
                : 70.0;
            pxPerUnit = 2.0 * Math.tan(Math.toRadians(fovDeg) * 0.5) / fbH;
            guiScale = Math.max(1.0f, (float) mc.getWindow().getScaleFactor());

            seeThroughAllocator.reset();
            depthAllocator.reset();
            seeThroughBuf = new BufferBuilder(seeThroughAllocator, VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
            depthBuf = new BufferBuilder(depthAllocator, VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
            return true;
        } catch (Throwable t) {
            seeThroughBuf = null;
            depthBuf = null;
            return false;
        }
    }

    public static void endFrame(MinecraftClient mc) {
        BufferBuilder d = depthBuf;
        BufferBuilder s = seeThroughBuf;
        depthBuf = null;
        seeThroughBuf = null;

        flushBatch(mc, d, depthTestedPipeline, "nexus_esp_depth");
        flushBatch(mc, s, seeThroughPipeline, "nexus_esp_through");
    }

    private static void flushBatch(MinecraftClient mc, BufferBuilder builder, RenderPipeline pipeline, String passLabel) {
        if (builder == null || pipeline == null || mc == null) {
            return;
        }
        BuiltBuffer built = null;
        try {
            built = builder.endNullable();
            if (built == null) {
                return;
            }
            BuiltBuffer.DrawParameters dp = built.getDrawParameters();
            int indexCount = dp.indexCount();
            if (indexCount <= 0) {
                return;
            }

            Framebuffer fb = mc.getFramebuffer();
            if (fb == null) {
                return;
            }
            GpuTextureView colorView = RenderSystem.outputColorTextureOverride != null
                ? RenderSystem.outputColorTextureOverride
                : fb.getColorAttachmentView();
            if (colorView == null) {
                return;
            }
            GpuTextureView depthView = fb.useDepthAttachment
                ? (RenderSystem.outputDepthTextureOverride != null ? RenderSystem.outputDepthTextureOverride : fb.getDepthAttachmentView())
                : null;

            GpuBuffer vertexGpu = dp.format().uploadImmediateVertexBuffer(built.getBuffer());
            GpuBufferSlice transforms = RenderSystem.getDynamicUniforms()
                .write(RenderSystem.getModelViewMatrix(), COLOR_MODULATOR, MODEL_OFFSET, TEXTURE_MATRIX);
            RenderSystem.ShapeIndexBuffer seq = RenderSystem.getSequentialBuffer(VertexFormat.DrawMode.QUADS);
            GpuBuffer indexGpu = seq.getIndexBuffer(indexCount);

            try (RenderPass pass = RenderSystem.getDevice().createCommandEncoder().createRenderPass(
                () -> passLabel, colorView, OptionalInt.empty(), depthView, OptionalDouble.empty()
            )) {
                pass.setPipeline(pipeline);
                RenderSystem.bindDefaultUniforms(pass);
                pass.setUniform("DynamicTransforms", transforms);
                pass.setVertexBuffer(0, vertexGpu);
                pass.setIndexBuffer(indexGpu, seq.getIndexType());
                pass.drawIndexed(0, 0, indexCount, 1);
            }
        } catch (Throwable t) {
            if (!flushErrorLogged) {
                flushErrorLogged = true;
                LOGGER.error("[NEXUS] 3D ESP batch flush failed safely ({}): {}", passLabel, t.toString());
            }
        } finally {
            if (built != null) {
                try {
                    built.close();
                } catch (Throwable ignored) {
                }
            }
        }
    }

    public static boolean isActive() {
        return seeThroughBuf != null;
    }

    private static BufferBuilder targetBuffer(boolean seeThrough) {
        return seeThrough ? seeThroughBuf : depthBuf;
    }

    private static double computeWorldStrokeWidth(double midX, double midY, double midZ, float thickness) {
        double dx = midX - camX;
        double dy = midY - camY;
        double dz = midZ - camZ;
        double dist = Math.max(0.8, Math.sqrt(dx * dx + dy * dy + dz * dz));
        return dist * pxPerUnit * Math.max(1.2, thickness * guiScale * 0.72);
    }

    public static void drawBox(Box box, int strokeArgb, float lineWidth, int fillArgb, boolean seeThrough) {
        drawBoxGlow(box, strokeArgb, lineWidth, fillArgb, false, seeThrough);
    }

    public static void drawBoxGlow(Box box, int strokeArgb, float lineWidth, int fillArgb, boolean glow, boolean seeThrough) {
        BufferBuilder b = targetBuffer(seeThrough);
        if (b == null || box == null) {
            return;
        }
        double x1 = box.minX, y1 = box.minY, z1 = box.minZ;
        double x2 = box.maxX, y2 = box.maxY, z2 = box.maxZ;

        if (((fillArgb >>> 24) & 0xFF) > 0) {
            fillBoxFaces(b, x1, y1, z1, x2, y2, z2, fillArgb);
        }
        if (((strokeArgb >>> 24) & 0xFF) > 0 && lineWidth > 0.0f) {
            double w = computeWorldStrokeWidth((x1 + x2) * 0.5, (y1 + y2) * 0.5, (z1 + z2) * 0.5, lineWidth);
            if (glow) {
                int glowAlpha = Math.max(18, (((strokeArgb >>> 24) & 0xFF) * 22) / 100);
                int glowColor = (glowAlpha << 24) | (strokeArgb & 0x00FFFFFF);
                boxEdges(b, x1, y1, z1, x2, y2, z2, w * 3.0, glowColor);
            }
            boxEdges(b, x1, y1, z1, x2, y2, z2, w, strokeArgb);
        }
    }

    public static void drawBlockBox(BlockPos pos, int strokeArgb, float lineWidth, int fillArgb, boolean seeThrough) {
        drawBlockBoxGlow(pos, strokeArgb, lineWidth, fillArgb, false, seeThrough);
    }

    public static void drawBlockBoxGlow(BlockPos pos, int strokeArgb, float lineWidth, int fillArgb, boolean glow, boolean seeThrough) {
        if (pos == null) {
            return;
        }
        Box box = new Box(
            pos.getX() + 0.015, pos.getY() + 0.015, pos.getZ() + 0.015,
            pos.getX() + 0.985, pos.getY() + 0.985, pos.getZ() + 0.985
        );
        drawBoxGlow(box, strokeArgb, lineWidth, fillArgb, glow, seeThrough);
    }

    public static void drawLine(Vec3d start, Vec3d end, int argb, float width, boolean seeThrough) {
        BufferBuilder b = targetBuffer(seeThrough);
        if (b == null || start == null || end == null || ((argb >>> 24) & 0xFF) == 0 || width <= 0.0f) {
            return;
        }
        segment3D(b, start.x, start.y, start.z, end.x, end.y, end.z, width, argb);
    }

    /**
     * Draws a flat horizontal line segment at height y (used for merged chunk outlines and glow halos).
     */
    public static void drawFlatLine(double ax, double az, double bx, double bz, double y, int argb, float width, boolean seeThrough) {
        BufferBuilder b = targetBuffer(seeThrough);
        if (b == null || ((argb >>> 24) & 0xFF) == 0 || width <= 0.0f) {
            return;
        }
        segment3D(b, ax, y, az, bx, y, bz, width, argb);
    }

    /**
     * Draws a crisp camera-facing glowing diamond/dot marker at (x, y, z).
     */
    public static void drawGlowDot(double x, double y, double z, int argb, boolean seeThrough) {
        BufferBuilder b = targetBuffer(seeThrough);
        if (b == null || ((argb >>> 24) & 0xFF) == 0) {
            return;
        }
        double rCore = computeWorldStrokeWidth(x, y, z, 2.8f);
        double rHalo = rCore * 2.4;
        int alpha = (argb >>> 24) & 0xFF;
        int haloArgb = (Math.max(20, alpha / 3) << 24) | (argb & 0x00FFFFFF);

        billboardDiamond(b, x, y, z, rHalo, haloArgb);
        billboardDiamond(b, x, y, z, rCore, argb);
    }

    public static void drawArrow(Vec3d start, Vec3d end, int argb, float width, boolean seeThrough) {
        BufferBuilder b = targetBuffer(seeThrough);
        if (b == null || start == null || end == null || ((argb >>> 24) & 0xFF) == 0) {
            return;
        }
        double dist = start.distanceTo(end);
        if (dist < 1e-4 || !Double.isFinite(dist)) {
            return;
        }
        segment3D(b, start.x, start.y, start.z, end.x, end.y, end.z, width, argb);

        Vector3f dir = end.subtract(start).toVector3f();
        if (dir.lengthSquared() < 1e-6f) {
            return;
        }
        dir.normalize();
        Quaternionf rot = new Quaternionf().rotationTo(new Vector3f(1.0f, 0.0f, 0.0f), dir);
        float headLen = (float) MathHelper.clamp(dist * 0.16, 0.14, 0.85);

        Vector3f[] fins = new Vector3f[]{
            rot.transform(-headLen,  headLen * 0.65f, 0.0f, new Vector3f()),
            rot.transform(-headLen, -headLen * 0.65f, 0.0f, new Vector3f()),
            rot.transform(-headLen, 0.0f,  headLen * 0.65f, new Vector3f()),
            rot.transform(-headLen, 0.0f, -headLen * 0.65f, new Vector3f())
        };
        for (Vector3f fin : fins) {
            segment3D(b, end.x + fin.x, end.y + fin.y, end.z + fin.z, end.x, end.y, end.z, width, argb);
        }
    }

    public static void drawChunkBorderFrame(int chunkX, int chunkZ, double yLevel, double heightSpan, int argb, float lineWidth, boolean seeThrough) {
        double minX = chunkX << 4;
        double minZ = chunkZ << 4;
        double maxX = minX + 16.0;
        double maxZ = minZ + 16.0;

        drawFlatLine(minX, minZ, maxX, minZ, yLevel, argb, lineWidth, seeThrough);
        drawFlatLine(maxX, minZ, maxX, maxZ, yLevel, argb, lineWidth, seeThrough);
        drawFlatLine(maxX, maxZ, minX, maxZ, yLevel, argb, lineWidth, seeThrough);
        drawFlatLine(minX, maxZ, minX, minZ, yLevel, argb, lineWidth, seeThrough);

        if (heightSpan > 0.2) {
            double topY = yLevel + heightSpan;
            int pillarColor = NexusTheme.withAlpha(argb, Math.max(60, ((argb >>> 24) & 0xFF) * 2 / 3));
            float pw = Math.max(1.0f, lineWidth * 0.8f);
            drawLine(new Vec3d(minX, yLevel, minZ), new Vec3d(minX, topY, minZ), pillarColor, pw, seeThrough);
            drawLine(new Vec3d(maxX, yLevel, minZ), new Vec3d(maxX, topY, minZ), pillarColor, pw, seeThrough);
            drawLine(new Vec3d(maxX, yLevel, maxZ), new Vec3d(maxX, topY, maxZ), pillarColor, pw, seeThrough);
            drawLine(new Vec3d(minX, yLevel, maxZ), new Vec3d(minX, topY, maxZ), pillarColor, pw, seeThrough);
        }
    }

    // ---------------- Internal Geometry Builders ----------------

    private static void billboardDiamond(BufferBuilder b, double x, double y, double z, double r, int argb) {
        double rx = CAM_RIGHT.x * r, ry = CAM_RIGHT.y * r, rz = CAM_RIGHT.z * r;
        double ux = CAM_UP.x * r, uy = CAM_UP.y * r, uz = CAM_UP.z * r;
        quad(b,
            x, y + uy, z + uz,
            x - rx, y, z - rz,
            x, y - uy, z - uz,
            x + rx, y, z + rz,
            argb
        );
    }

    private static void segment3D(BufferBuilder b, double ax, double ay, double az, double bx, double by, double bz, float thickness, int argb) {
        double dx = bx - ax;
        double dy = by - ay;
        double dz = bz - az;
        double lenSq = dx * dx + dy * dy + dz * dz;
        if (lenSq < 1e-8) {
            return;
        }
        double invLen = 1.0 / Math.sqrt(lenSq);
        double ux = dx * invLen;
        double uy = dy * invLen;
        double uz = dz * invLen;

        double w = computeWorldStrokeWidth((ax + bx) * 0.5, (ay + by) * 0.5, (az + bz) * 0.5, thickness) * 0.5;

        // Pick an up reference not collinear with u, then construct two orthogonal ribbon normals n1, n2
        double refX = Math.abs(uy) < 0.9 ? 0.0 : 1.0;
        double refY = Math.abs(uy) < 0.9 ? 1.0 : 0.0;
        double refZ = 0.0;

        double n1x = uy * refZ - uz * refY;
        double n1y = uz * refX - ux * refZ;
        double n1z = ux * refY - uy * refX;
        double n1Len = Math.sqrt(n1x * n1x + n1y * n1y + n1z * n1z);
        if (n1Len < 1e-6) {
            return;
        }
        n1x = (n1x / n1Len) * w;
        n1y = (n1y / n1Len) * w;
        n1z = (n1z / n1Len) * w;

        double n2x = (uy * (n1z / w) - uz * (n1y / w)) * w;
        double n2y = (uz * (n1x / w) - ux * (n1z / w)) * w;
        double n2z = (ux * (n1y / w) - uy * (n1x / w)) * w;

        quad(b,
            ax - n1x, ay - n1y, az - n1z,
            bx - n1x, by - n1y, bz - n1z,
            bx + n1x, by + n1y, bz + n1z,
            ax + n1x, ay + n1y, az + n1z,
            argb
        );
        quad(b,
            ax - n2x, ay - n2y, az - n2z,
            bx - n2x, by - n2y, bz - n2z,
            bx + n2x, by + n2y, bz + n2z,
            ax + n2x, ay + n2y, az + n2z,
            argb
        );
    }

    private static void boxEdges(BufferBuilder b, double x1, double y1, double z1, double x2, double y2, double z2, double w, int c) {
        double[] xs = {x1, x2};
        double[] ys = {y1, y2};
        double[] zs = {z1, z2};
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                axisRibbon(b, x1, ys[i], zs[j], x2, ys[i], zs[j], 0, w, c);
                axisRibbon(b, xs[i], y1, zs[j], xs[i], y2, zs[j], 1, w, c);
                axisRibbon(b, xs[i], ys[j], z1, xs[i], ys[j], z2, 2, w, c);
            }
        }
    }

    private static void axisRibbon(BufferBuilder b, double ax, double ay, double az, double bx, double by, double bz, int axis, double w, int c) {
        double h = w * 0.5;
        if (axis == 0) {
            ax -= h;
            bx += h;
        } else if (axis == 1) {
            ay -= h;
            by += h;
        } else {
            az -= h;
            bz += h;
        }
        for (int k = 0; k < 2; k++) {
            int perp = (axis + 1 + k) % 3;
            double ox = perp == 0 ? h : 0.0;
            double oy = perp == 1 ? h : 0.0;
            double oz = perp == 2 ? h : 0.0;
            quad(b,
                ax - ox, ay - oy, az - oz,
                bx - ox, by - oy, bz - oz,
                bx + ox, by + oy, bz + oz,
                ax + ox, ay + oy, az + oz,
                c
            );
        }
    }

    private static void fillBoxFaces(BufferBuilder b, double x1, double y1, double z1, double x2, double y2, double z2, int c) {
        quad(b, x1, y1, z1, x2, y1, z1, x2, y1, z2, x1, y1, z2, c); // bottom
        quad(b, x1, y2, z1, x1, y2, z2, x2, y2, z2, x2, y2, z1, c); // top
        quad(b, x1, y1, z1, x1, y2, z1, x2, y2, z1, x2, y1, z1, c); // north
        quad(b, x1, y1, z2, x2, y1, z2, x2, y2, z2, x1, y2, z2, c); // south
        quad(b, x1, y1, z1, x1, y1, z2, x1, y2, z2, x1, y2, z1, c); // west
        quad(b, x2, y1, z1, x2, y2, z1, x2, y2, z2, x2, y1, z2, c); // east
    }

    private static void quad(
        BufferBuilder b,
        double ax, double ay, double az,
        double bx, double by, double bz,
        double cx2, double cy2, double cz2,
        double dx, double dy, double dz,
        int argb
    ) {
        emitVertex(b, ax, ay, az, argb);
        emitVertex(b, bx, by, bz, argb);
        emitVertex(b, cx2, cy2, cz2, argb);
        emitVertex(b, dx, dy, dz, argb);
    }

    private static void emitVertex(BufferBuilder b, double wx, double wy, double wz, int argb) {
        TMP_VEC.set((float) (wx - camX), (float) (wy - camY), (float) (wz - camZ));
        VIEW_MAT.transformPosition(TMP_VEC);
        b.vertex(TMP_VEC.x, TMP_VEC.y, TMP_VEC.z).color(argb);
    }
}
