package dev.nexus.client.module;

public enum Category {
    COMBAT("Combat", "Precision & tactical assistance"),
    RENDER("Render", "Visual awareness & camera tools"),
    WORLD("World", "Local loaded-chunk pattern analysis"),
    UTILITY("Utility", "Streamlined client helpers");

    private final String displayName;
    private final String subtitle;

    Category(String displayName, String subtitle) {
        this.displayName = displayName;
        this.subtitle = subtitle;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getSubtitle() {
        return subtitle;
    }
}
