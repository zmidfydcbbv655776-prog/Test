package dev.nexus.client.mixin;

import dev.nexus.client.module.impl.render.FreecamModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Entity.class)
public abstract class EntityMixin {
    @Inject(method = "changeLookDirection", at = @At("HEAD"), cancellable = true)
    private void nexus$redirectFreecamLook(double cursorDeltaX, double cursorDeltaY, CallbackInfo ci) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc != null && (Object) this == mc.player && FreecamModule.isFreecamActive()) {
            FreecamModule freecam = FreecamModule.getInstance();
            if (freecam != null) {
                freecam.onLookDelta(cursorDeltaX, cursorDeltaY);
                ci.cancel();
            }
        }
    }
}
