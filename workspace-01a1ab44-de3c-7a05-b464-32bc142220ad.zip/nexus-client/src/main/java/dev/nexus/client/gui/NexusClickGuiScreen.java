package dev.nexus.client.gui;

import dev.nexus.client.NexusClientMod;
import dev.nexus.client.module.Category;
import dev.nexus.client.module.Module;
import dev.nexus.client.module.ModuleManager;
import dev.nexus.client.module.setting.ActionSetting;
import dev.nexus.client.module.setting.BooleanSetting;
import dev.nexus.client.module.setting.KeybindSetting;
import dev.nexus.client.module.setting.ModeSetting;
import dev.nexus.client.module.setting.NumberSetting;
import dev.nexus.client.module.setting.Setting;
import dev.nexus.client.module.setting.TextSetting;
import dev.nexus.client.render.NexusTheme;
import dev.nexus.client.util.KeyUtil;
import java.util.List;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

/**
 * Stage 3: Custom Black & Gold ClickGUI for NEXUS CLIENT.
 * - Minimal, premium obsidian & gold aesthetic without heavy blur shaders.
 * - Responsive layout for low resolutions and Android/PojavLauncher touchscreens.
 * - Sidebar categories (Combat, Render, World, Utility), global search, module toggles,
 *   and full per-module settings (Toggle, Slider, Dropdown, Keybind, Text Field).
 */
public final class NexusClickGuiScreen extends Screen {
    private static Category persistedCategory = Category.COMBAT;
    private static String persistedModuleId = "aim_assist";

    private final ModuleManager moduleManager;

    private Category selectedCategory;
    private Module selectedModule;

    // Search & input state
    private String searchQuery = "";
    private boolean searchFocused = false;
    private KeybindSetting listeningKeybind = null;
    private TextSetting focusedTextSetting = null;
    private NumberSetting draggingSlider = null;
    private ModeSetting expandedDropdown = null;

    // Scroll & touch-drag state
    private double moduleScroll = 0.0;
    private double settingsScroll = 0.0;
    private int maxModuleScroll = 0;
    private int maxSettingsScroll = 0;
    private boolean touchDraggingModules = false;
    private boolean touchDraggingSettings = false;
    private double touchDragStartY = 0.0;
    private boolean touchDragMoved = false;

    // Computed responsive geometry
    private int winX, winY, winW, winH;
    private int headerH;
    private int sidebarW;
    private int modListX, modListW;
    private int settingsX, settingsW;
    private int bodyY, bodyH;

    // Lightweight open animation (0 -> 1 in ~120ms)
    private float openProgress = 0.0f;
    private float categoryHighlightY = -1.0f;

    public NexusClickGuiScreen() {
        super(Text.literal("NEXUS CLIENT"));
        this.moduleManager = NexusClientMod.getInstance().getModuleManager();
        this.selectedCategory = persistedCategory;
        this.selectedModule = moduleManager.getById(persistedModuleId);
        if (this.selectedModule == null) {
            List<Module> inCat = moduleManager.getByCategory(selectedCategory);
            if (!inCat.isEmpty()) {
                this.selectedModule = inCat.getFirst();
            } else if (!moduleManager.getModules().isEmpty()) {
                this.selectedModule = moduleManager.getModules().getFirst();
            }
        }
    }

    @Override
    protected void init() {
        super.init();
        computeResponsiveBounds();
    }

    private void computeResponsiveBounds() {
        int marginX = this.width < 400 ? 6 : 14;
        int marginY = this.height < 250 ? 6 : 12;

        this.winW = MathHelper.clamp(this.width - marginX * 2, 290, 560);
        this.winH = MathHelper.clamp(this.height - marginY * 2, 174, 340);
        this.winX = (this.width - this.winW) / 2;
        this.winY = (this.height - this.winH) / 2;

        this.headerH = this.winH < 210 ? 24 : 28;
        this.sidebarW = this.winW < 380 ? 68 : (this.winW < 460 ? 84 : 102);

        this.bodyY = this.winY + this.headerH + 4;
        this.bodyH = this.winH - this.headerH - 8;

        int innerContentW = this.winW - this.sidebarW - 14;
        this.modListX = this.winX + this.sidebarW + 6;
        this.modListW = Math.max(105, (int) (innerContentW * 0.44f));

        this.settingsX = this.modListX + this.modListW + 5;
        this.settingsW = Math.max(110, (this.winX + this.winW - 5) - this.settingsX);
    }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
        // Deliberately avoid Mojang's heavy multi-pass Gaussian blur for mobile/Pojav FPS & clean minimal look
        context.fill(0, 0, this.width, this.height, NexusTheme.BG_BACKDROP);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
        computeResponsiveBounds();
        this.renderBackground(context, mouseX, mouseY, deltaTicks);

        float animStep = MathHelper.clamp(deltaTicks * 0.35f, 0.05f, 1.0f);
        this.openProgress = NexusTheme.approach(this.openProgress, 1.0f, animStep);

        // Update module toggle switch animations smoothly
        for (Module mod : moduleManager.getModules()) {
            float target = mod.isEnabled() ? 1.0f : 0.0f;
            mod.setToggleAnimProgress(NexusTheme.approach(mod.getToggleAnimProgress(), target, animStep));
        }

        // Main Window Shell
        NexusTheme.drawRoundedPanel(context, winX, winY, winW, winH, NexusTheme.BG_WINDOW, NexusTheme.BORDER_GOLD);

        renderHeader(context, mouseX, mouseY);
        renderSidebar(context, mouseX, mouseY, animStep);
        renderModuleList(context, mouseX, mouseY);
        renderSettingsPanel(context, mouseX, mouseY);
    }

    private void renderHeader(DrawContext ctx, int mouseX, int mouseY) {
        NexusTheme.drawRoundedPanel(ctx, winX + 2, winY + 2, winW - 4, headerH, NexusTheme.BG_HEADER, 0);
        ctx.fill(winX + 2, winY + headerH + 1, winX + winW - 2, winY + headerH + 2, NexusTheme.BORDER_SUBTLE);

        // Brand emblem + title
        int brandY = winY + (headerH - 8) / 2 + 1;
        ctx.fill(winX + 8, brandY + 1, winX + 12, brandY + 7, NexusTheme.GOLD_BRIGHT);
        String brand = winW < 360 ? "NEXUS" : "NEXUS CLIENT";
        ctx.drawTextWithShadow(this.textRenderer, brand, winX + 16, brandY, NexusTheme.GOLD_BRIGHT);

        if (winW >= 440) {
            int brandW = this.textRenderer.getWidth(brand);
            ctx.drawTextWithShadow(this.textRenderer, "1.21.11", winX + 20 + brandW, brandY, NexusTheme.TEXT_MUTED);
        }

        // Close button (top-right, touch friendly)
        int closeSize = headerH - 6;
        int closeX = winX + winW - closeSize - 5;
        int closeY = winY + 4;
        boolean hoverClose = isInside(mouseX, mouseY, closeX, closeY, closeSize, closeSize);
        NexusTheme.drawRoundedPanel(ctx, closeX, closeY, closeSize, closeSize,
            hoverClose ? 0xFF3A1E22 : NexusTheme.BG_CARD,
            hoverClose ? NexusTheme.STATUS_DANGER : NexusTheme.BORDER_SUBTLE);
        int xGlyphW = this.textRenderer.getWidth("X");
        ctx.drawTextWithShadow(this.textRenderer, "X",
            closeX + (closeSize - xGlyphW) / 2,
            closeY + (closeSize - 8) / 2,
            hoverClose ? NexusTheme.TEXT_PRIMARY : NexusTheme.TEXT_SECONDARY);

        // Global Search Bar
        int searchW = MathHelper.clamp(winW / 3, 96, 175);
        int searchH = headerH - 6;
        int searchX = closeX - searchW - 6;
        int searchY = winY + 4;
        int searchBorder = searchFocused ? NexusTheme.GOLD_BRIGHT : NexusTheme.BORDER_SUBTLE;
        NexusTheme.drawRoundedPanel(ctx, searchX, searchY, searchW, searchH, NexusTheme.BG_INPUT, searchBorder);

        String cursor = (searchFocused && (System.currentTimeMillis() / 500L) % 2L == 0L) ? "|" : "";
        String displaySearch;
        int searchColor;
        if (searchQuery.isEmpty() && !searchFocused) {
            displaySearch = "Search modules...";
            searchColor = NexusTheme.TEXT_MUTED;
        } else {
            displaySearch = trimToWidthFromEnd(searchQuery + cursor, searchW - 22);
            searchColor = NexusTheme.TEXT_PRIMARY;
        }
        ctx.drawTextWithShadow(this.textRenderer, displaySearch, searchX + 6, searchY + (searchH - 8) / 2, searchColor);

        if (!searchQuery.isEmpty()) {
            int clrX = searchX + searchW - 13;
            ctx.drawTextWithShadow(this.textRenderer, "x", clrX, searchY + (searchH - 8) / 2, NexusTheme.GOLD_SOFT);
        }
    }

    private void renderSidebar(DrawContext ctx, int mouseX, int mouseY, float animStep) {
        int sx = winX + 4;
        NexusTheme.drawRoundedPanel(ctx, sx, bodyY, sidebarW - 2, bodyH, NexusTheme.BG_SIDEBAR, NexusTheme.BORDER_SUBTLE);

        int catY = bodyY + 6;
        int catH = bodyH < 170 ? 22 : 26;
        Category[] categories = Category.values();

        for (Category cat : categories) {
            boolean active = searchQuery.isBlank() && (cat == selectedCategory);
            boolean hovered = isInside(mouseX, mouseY, sx + 3, catY, sidebarW - 8, catH);

            if (active) {
                if (categoryHighlightY < 0.0f) {
                    categoryHighlightY = catY;
                } else {
                    categoryHighlightY = NexusTheme.approach(categoryHighlightY, catY, animStep);
                }
            }

            int cardFill = active ? NexusTheme.BG_CARD_SELECTED : (hovered ? NexusTheme.BG_CARD_HOVER : 0x00000000);
            int cardBorder = active ? NexusTheme.BORDER_GOLD : 0x00000000;
            if (active || hovered) {
                NexusTheme.drawRoundedPanel(ctx, sx + 3, catY, sidebarW - 8, catH, cardFill, cardBorder);
            }

            int textColor = active ? NexusTheme.GOLD_BRIGHT : (hovered ? NexusTheme.TEXT_PRIMARY : NexusTheme.TEXT_SECONDARY);
            String label = trimToWidth(cat.getDisplayName(), sidebarW - 16);
            ctx.drawTextWithShadow(this.textRenderer, label, sx + 9, catY + (catH - 8) / 2, textColor);

            catY += catH + 3;
        }

        if (categoryHighlightY >= 0.0f && searchQuery.isBlank()) {
            int barY = Math.round(categoryHighlightY) + 4;
            ctx.fill(sx + 4, barY, sx + 6, barY + catH - 8, NexusTheme.GOLD_BRIGHT);
        }

        // Capacity footer
        if (bodyH >= 150) {
            String capLabel = moduleManager.getModules().size() + "/" + ModuleManager.TARGET_MODULE_CAPACITY + " Mods";
            ctx.drawTextWithShadow(this.textRenderer, trimToWidth(capLabel, sidebarW - 10),
                sx + 6, bodyY + bodyH - 13, NexusTheme.TEXT_MUTED);
        }
    }

    private void renderModuleList(DrawContext ctx, int mouseX, int mouseY) {
        NexusTheme.drawRoundedPanel(ctx, modListX, bodyY, modListW, bodyH, NexusTheme.BG_PANEL, NexusTheme.BORDER_SUBTLE);

        List<Module> modules = moduleManager.search(searchQuery, selectedCategory);
        int cardH = bodyH < 175 ? 26 : 30;
        int gap = 4;
        int totalH = modules.size() * (cardH + gap) + 6;
        this.maxModuleScroll = Math.max(0, totalH - (bodyH - 4));
        this.moduleScroll = MathHelper.clamp(this.moduleScroll, 0.0, this.maxModuleScroll);

        ctx.enableScissor(modListX + 1, bodyY + 2, modListX + modListW - 1, bodyY + bodyH - 2);

        if (modules.isEmpty()) {
            ctx.drawTextWithShadow(this.textRenderer, "No matching modules", modListX + 8, bodyY + 12, NexusTheme.TEXT_MUTED);
        } else {
            int curY = bodyY + 5 - (int) Math.round(moduleScroll);
            for (Module mod : modules) {
                if (curY + cardH >= bodyY && curY <= bodyY + bodyH) {
                    boolean isSel = (mod == selectedModule);
                    boolean hovered = isInside(mouseX, mouseY, modListX + 4, curY, modListW - 8, cardH)
                        && isInside(mouseX, mouseY, modListX, bodyY, modListW, bodyH);

                    int bg = isSel ? NexusTheme.BG_CARD_SELECTED : (hovered ? NexusTheme.BG_CARD_HOVER : NexusTheme.BG_CARD);
                    int border = isSel ? NexusTheme.BORDER_GOLD : (mod.isEnabled() ? NexusTheme.BORDER_SUBTLE : NexusTheme.BORDER_DARK);
                    NexusTheme.drawRoundedPanel(ctx, modListX + 4, curY, modListW - 8, cardH, bg, border);

                    // Toggle switch on right
                    int toggleW = 24;
                    int toggleH = 12;
                    int toggleX = modListX + modListW - toggleW - 9;
                    int toggleY = curY + (cardH - toggleH) / 2;
                    NexusTheme.drawToggleSwitch(ctx, toggleX, toggleY, toggleW, toggleH, mod.getToggleAnimProgress());

                    // Module title & subtitle
                    int availTextW = toggleX - (modListX + 10) - 4;
                    int titleColor = mod.isEnabled() ? NexusTheme.GOLD_BRIGHT : NexusTheme.TEXT_PRIMARY;
                    String title = trimToWidth(mod.getName(), availTextW);
                    if (cardH >= 28) {
                        ctx.drawTextWithShadow(this.textRenderer, title, modListX + 9, curY + 4, titleColor);
                        String sub = mod.getToggleKeybind().isBound()
                            ? "[" + mod.getToggleKeybind().getDisplayText() + "] " + mod.getDescription()
                            : mod.getDescription();
                        ctx.drawTextWithShadow(this.textRenderer, trimToWidth(sub, availTextW), modListX + 9, curY + 16, NexusTheme.TEXT_MUTED);
                    } else {
                        ctx.drawTextWithShadow(this.textRenderer, title, modListX + 9, curY + (cardH - 8) / 2, titleColor);
                    }
                }
                curY += cardH + gap;
            }
        }

        ctx.disableScissor();
    }

    private void renderSettingsPanel(DrawContext ctx, int mouseX, int mouseY) {
        NexusTheme.drawRoundedPanel(ctx, settingsX, bodyY, settingsW, bodyH, NexusTheme.BG_PANEL, NexusTheme.BORDER_SUBTLE);

        if (selectedModule == null) {
            ctx.drawTextWithShadow(this.textRenderer, "Select a module", settingsX + 8, bodyY + 12, NexusTheme.TEXT_MUTED);
            return;
        }

        // Fixed Module Inspector Header inside Settings Panel
        int infoHeaderH = 30;
        ctx.fill(settingsX + 2, bodyY + infoHeaderH, settingsX + settingsW - 2, bodyY + infoHeaderH + 1, NexusTheme.BORDER_SUBTLE);
        ctx.drawTextWithShadow(this.textRenderer,
            trimToWidth(selectedModule.getName(), settingsW - 14),
            settingsX + 7, bodyY + 5, NexusTheme.GOLD_BRIGHT);

        List<OrderedText> wrappedDesc = this.textRenderer.wrapLines(Text.literal(selectedModule.getDescription()), settingsW - 14);
        if (!wrappedDesc.isEmpty()) {
            ctx.drawTextWithShadow(this.textRenderer, wrappedDesc.getFirst(), settingsX + 7, bodyY + 16, NexusTheme.TEXT_SECONDARY);
        }

        int listTop = bodyY + infoHeaderH + 3;
        int listBottom = bodyY + bodyH - 3;
        int listViewH = Math.max(20, listBottom - listTop);

        // Compute scrollable height of visible settings
        int contentH = 4;
        for (Setting<?> setting : selectedModule.getSettings()) {
            if (!setting.isVisible()) {
                continue;
            }
            contentH += getSettingHeight(setting) + 4;
        }
        this.maxSettingsScroll = Math.max(0, contentH - listViewH);
        this.settingsScroll = MathHelper.clamp(this.settingsScroll, 0.0, this.maxSettingsScroll);

        ctx.enableScissor(settingsX + 1, listTop, settingsX + settingsW - 1, listBottom);

        int curY = listTop + 2 - (int) Math.round(settingsScroll);
        for (Setting<?> setting : selectedModule.getSettings()) {
            if (!setting.isVisible()) {
                continue;
            }
            int rowH = getSettingHeight(setting);
            if (curY + rowH >= listTop && curY <= listBottom) {
                renderSingleSetting(ctx, setting, settingsX + 5, curY, settingsW - 10, rowH, mouseX, mouseY);
            }
            curY += rowH + 4;
        }

        ctx.disableScissor();
    }

    private int getSettingHeight(Setting<?> setting) {
        if (setting instanceof ActionSetting) {
            return 22;
        }
        if (setting instanceof BooleanSetting) {
            return 22;
        }
        if (setting instanceof NumberSetting) {
            return 28;
        }
        if (setting instanceof ModeSetting modeSetting) {
            if (expandedDropdown == modeSetting) {
                return 22 + modeSetting.getModes().size() * 16 + 4;
            }
            return 22;
        }
        if (setting instanceof KeybindSetting) {
            return 22;
        }
        if (setting instanceof TextSetting) {
            return 34;
        }
        return 22;
    }

    private void renderSingleSetting(DrawContext ctx, Setting<?> setting, int x, int y, int w, int h, int mouseX, int mouseY) {
        if (setting instanceof ActionSetting actionSet) {
            boolean hovered = isInside(mouseX, mouseY, x, y, w, h);
            boolean flashed = actionSet.isRecentlyTriggered();
            int btnBg = flashed ? NexusTheme.BG_CARD_SELECTED : (hovered ? NexusTheme.BG_CARD_HOVER : NexusTheme.BG_CARD);
            int btnBorder = flashed ? NexusTheme.GOLD_BRIGHT : (hovered ? NexusTheme.BORDER_GOLD : NexusTheme.BORDER_SUBTLE);
            NexusTheme.drawRoundedPanel(ctx, x, y, w, h, btnBg, btnBorder);
            String label = trimToWidth((flashed ? "\u2713 " : "\u25B8 ") + actionSet.getName(), w - 12);
            int tw = this.textRenderer.getWidth(label);
            ctx.drawTextWithShadow(
                this.textRenderer,
                label,
                x + (w - tw) / 2,
                y + (h - 8) / 2,
                (flashed || hovered) ? NexusTheme.GOLD_BRIGHT : NexusTheme.TEXT_PRIMARY
            );
            return;
        }

        NexusTheme.drawRoundedPanel(ctx, x, y, w, h, NexusTheme.BG_CARD, NexusTheme.BORDER_DARK);

        if (setting instanceof BooleanSetting boolSet) {
            int toggleW = 22;
            int toggleH = 12;
            int toggleX = x + w - toggleW - 5;
            int toggleY = y + (h - toggleH) / 2;
            String label = trimToWidth(boolSet.getName(), toggleX - (x + 6) - 4);
            ctx.drawTextWithShadow(this.textRenderer, label, x + 6, y + (h - 8) / 2, NexusTheme.TEXT_PRIMARY);
            NexusTheme.drawToggleSwitch(ctx, toggleX, toggleY, toggleW, toggleH, boolSet.getValue() ? 1.0f : 0.0f);
            return;
        }

        if (setting instanceof NumberSetting numSet) {
            String valText = numSet.formatValue();
            int valW = this.textRenderer.getWidth(valText);
            String label = trimToWidth(numSet.getName(), w - valW - 14);
            ctx.drawTextWithShadow(this.textRenderer, label, x + 6, y + 4, NexusTheme.TEXT_PRIMARY);
            ctx.drawTextWithShadow(this.textRenderer, valText, x + w - valW - 6, y + 4, NexusTheme.GOLD_BRIGHT);

            int barX = x + 6;
            int barY = y + 18;
            int barW = w - 12;
            int barH = 4;
            ctx.fill(barX, barY, barX + barW, barY + barH, NexusTheme.BG_INPUT);

            int fillW = (int) Math.round(barW * numSet.getNormalized());
            if (fillW > 0) {
                ctx.fill(barX, barY, barX + fillW, barY + barH, NexusTheme.GOLD_PRIMARY);
            }
            int knobX = MathHelper.clamp(barX + fillW - 2, barX, barX + barW - 4);
            ctx.fill(knobX, barY - 2, knobX + 4, barY + barH + 2, NexusTheme.GOLD_BRIGHT);
            return;
        }

        if (setting instanceof ModeSetting modeSet) {
            boolean isOpen = (expandedDropdown == modeSet);
            String arrow = isOpen ? " ^" : " v";
            String modeText = modeSet.getValue() + arrow;
            int modeW = Math.min(w / 2 + 12, this.textRenderer.getWidth(modeText) + 10);
            int btnX = x + w - modeW - 4;
            int btnY = y + 3;
            int btnH = 16;

            String label = trimToWidth(modeSet.getName(), btnX - (x + 6) - 4);
            ctx.drawTextWithShadow(this.textRenderer, label, x + 6, y + 7, NexusTheme.TEXT_PRIMARY);

            NexusTheme.drawRoundedPanel(ctx, btnX, btnY, modeW, btnH, NexusTheme.BG_INPUT,
                isOpen ? NexusTheme.GOLD_BRIGHT : NexusTheme.BORDER_SUBTLE);
            ctx.drawTextWithShadow(this.textRenderer, trimToWidth(modeText, modeW - 6),
                btnX + 4, btnY + 4, NexusTheme.GOLD_SOFT);

            if (isOpen) {
                int optY = y + 22;
                for (String opt : modeSet.getModes()) {
                    boolean active = modeSet.isMode(opt);
                    boolean hoverOpt = isInside(mouseX, mouseY, x + 4, optY, w - 8, 15);
                    int optBg = active ? NexusTheme.BG_CARD_SELECTED : (hoverOpt ? NexusTheme.BG_CARD_HOVER : NexusTheme.BG_INPUT);
                    ctx.fill(x + 4, optY, x + w - 4, optY + 15, optBg);
                    ctx.drawTextWithShadow(this.textRenderer, trimToWidth(opt, w - 16),
                        x + 8, optY + 4, active ? NexusTheme.GOLD_BRIGHT : NexusTheme.TEXT_SECONDARY);
                    optY += 16;
                }
            }
            return;
        }

        if (setting instanceof KeybindSetting kbSet) {
            boolean listening = (listeningKeybind == kbSet);
            boolean conflict = moduleManager.hasKeybindConflict(kbSet);

            // Clear button for touch users when bound
            int clearW = kbSet.isBound() ? 14 : 0;
            String keyLabel = listening ? "Press key..." : kbSet.getDisplayText();
            if (conflict && !listening) {
                keyLabel = "! " + keyLabel;
            }
            int btnW = Math.max(42, this.textRenderer.getWidth(keyLabel) + 10);
            int clearX = x + w - clearW - 4;
            int btnX = (kbSet.isBound() ? clearX - 2 : x + w - 4) - btnW;
            int btnY = y + 3;
            int btnH = 16;

            String label = trimToWidth(kbSet.getName(), btnX - (x + 6) - 4);
            ctx.drawTextWithShadow(this.textRenderer, label, x + 6, y + 7, NexusTheme.TEXT_PRIMARY);

            int borderColor = listening ? NexusTheme.GOLD_BRIGHT
                : (conflict ? NexusTheme.STATUS_MED_ORANGE : NexusTheme.BORDER_SUBTLE);
            NexusTheme.drawRoundedPanel(ctx, btnX, btnY, btnW, btnH, NexusTheme.BG_INPUT, borderColor);
            int txtColor = listening ? NexusTheme.GOLD_BRIGHT
                : (conflict ? NexusTheme.STATUS_MED_ORANGE : NexusTheme.TEXT_SECONDARY);
            ctx.drawTextWithShadow(this.textRenderer, keyLabel, btnX + 5, btnY + 4, txtColor);

            if (kbSet.isBound()) {
                NexusTheme.drawRoundedPanel(ctx, clearX, btnY, clearW, btnH, NexusTheme.BG_INPUT, NexusTheme.BORDER_DARK);
                ctx.drawTextWithShadow(this.textRenderer, "x", clearX + 4, btnY + 4, NexusTheme.TEXT_MUTED);
            }
            return;
        }

        if (setting instanceof TextSetting txtSet) {
            boolean focused = (focusedTextSetting == txtSet);
            ctx.drawTextWithShadow(this.textRenderer, trimToWidth(txtSet.getName(), w - 26), x + 6, y + 4, NexusTheme.TEXT_PRIMARY);

            int boxX = x + 5;
            int boxY = y + 15;
            int boxW = w - 10;
            int boxH = 15;
            NexusTheme.drawRoundedPanel(ctx, boxX, boxY, boxW, boxH, NexusTheme.BG_INPUT,
                focused ? NexusTheme.GOLD_BRIGHT : NexusTheme.BORDER_SUBTLE);

            String cursor = (focused && (System.currentTimeMillis() / 500L) % 2L == 0L) ? "|" : "";
            String content = txtSet.getValue() + cursor;
            String visible = content.isEmpty() && !focused ? "(empty)" : trimToWidthFromEnd(content, boxW - 20);
            int color = (txtSet.getValue().isEmpty() && !focused) ? NexusTheme.TEXT_MUTED : NexusTheme.TEXT_PRIMARY;
            ctx.drawTextWithShadow(this.textRenderer, visible, boxX + 4, boxY + 4, color);

            if (!txtSet.getValue().isEmpty()) {
                ctx.drawTextWithShadow(this.textRenderer, "x", boxX + boxW - 10, boxY + 4, NexusTheme.GOLD_SOFT);
            }
        }
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x();
        double my = click.y();
        int button = click.button();

        // If waiting for a keybind and user clicks a mouse side/middle button, allow binding mouse buttons (M3/M4/M5)
        if (listeningKeybind != null && button >= 2) {
            listeningKeybind.setValue(KeyUtil.encodeMouseButton(button));
            listeningKeybind = null;
            saveConfigQuietly();
            return true;
        }

        // Clear focus flags first (re-established below if clicked inside input)
        searchFocused = false;
        focusedTextSetting = null;

        // 1. Header Close Button
        int closeSize = headerH - 6;
        int closeX = winX + winW - closeSize - 5;
        int closeY = winY + 4;
        if (isInside(mx, my, closeX, closeY, closeSize, closeSize)) {
            this.close();
            return true;
        }

        // 2. Global Search Bar
        int searchW = MathHelper.clamp(winW / 3, 96, 175);
        int searchH = headerH - 6;
        int searchX = closeX - searchW - 6;
        int searchY = winY + 4;
        if (isInside(mx, my, searchX, searchY, searchW, searchH)) {
            if (!searchQuery.isEmpty() && mx >= searchX + searchW - 15) {
                searchQuery = "";
                moduleScroll = 0.0;
            }
            searchFocused = true;
            listeningKeybind = null;
            return true;
        }

        // 3. Sidebar Categories
        int sx = winX + 4;
        int catY = bodyY + 6;
        int catH = bodyH < 170 ? 22 : 26;
        for (Category cat : Category.values()) {
            if (isInside(mx, my, sx + 3, catY, sidebarW - 8, catH)) {
                selectedCategory = cat;
                persistedCategory = cat;
                searchQuery = "";
                moduleScroll = 0.0;
                expandedDropdown = null;
                listeningKeybind = null;
                List<Module> mods = moduleManager.getByCategory(cat);
                if (!mods.isEmpty() && (selectedModule == null || selectedModule.getCategory() != cat)) {
                    selectModule(mods.getFirst());
                }
                return true;
            }
            catY += catH + 3;
        }

        // 4. Module List
        if (isInside(mx, my, modListX, bodyY, modListW, bodyH)) {
            touchDraggingModules = true;
            touchDragStartY = my;
            touchDragMoved = false;

            List<Module> modules = moduleManager.search(searchQuery, selectedCategory);
            int cardH = bodyH < 175 ? 26 : 30;
            int gap = 4;
            int curY = bodyY + 5 - (int) Math.round(moduleScroll);
            for (Module mod : modules) {
                if (isInside(mx, my, modListX + 4, curY, modListW - 8, cardH)) {
                    int toggleW = 24;
                    int toggleX = modListX + modListW - toggleW - 9;
                    if (button == 1) {
                        selectModule(mod);
                    } else if (mx >= toggleX - 4) {
                        mod.toggle();
                        saveConfigQuietly();
                    } else {
                        selectModule(mod);
                    }
                    listeningKeybind = null;
                    return true;
                }
                curY += cardH + gap;
            }
            return true;
        }

        // 5. Settings Panel
        int listTop = bodyY + 33;
        int listBottom = bodyY + bodyH - 3;
        if (selectedModule != null && isInside(mx, my, settingsX, listTop, settingsW, listBottom - listTop)) {
            touchDraggingSettings = true;
            touchDragStartY = my;
            touchDragMoved = false;

            int curY = listTop + 2 - (int) Math.round(settingsScroll);
            int rowX = settingsX + 5;
            int rowW = settingsW - 10;

            for (Setting<?> setting : selectedModule.getSettings()) {
                if (!setting.isVisible()) {
                    continue;
                }
                int rowH = getSettingHeight(setting);
                if (isInside(mx, my, rowX, curY, rowW, rowH)) {
                    handleSettingClick(setting, rowX, curY, rowW, rowH, mx, my, button);
                    return true;
                }
                curY += rowH + 4;
            }
            return true;
        }

        listeningKeybind = null;
        return super.mouseClicked(click, doubled);
    }

    private void handleSettingClick(Setting<?> setting, int x, int y, int w, int h, double mx, double my, int button) {
        if (setting instanceof ActionSetting actionSet) {
            actionSet.trigger();
            listeningKeybind = null;
            return;
        }

        if (setting instanceof BooleanSetting boolSet) {
            boolSet.toggle();
            listeningKeybind = null;
            saveConfigQuietly();
            return;
        }

        if (setting instanceof NumberSetting numSet) {
            int barX = x + 6;
            int barW = w - 12;
            updateSliderFromMouse(numSet, barX, barW, mx);
            draggingSlider = numSet;
            touchDraggingSettings = false; // Slider drag takes priority over touch panel scroll
            listeningKeybind = null;
            return;
        }

        if (setting instanceof ModeSetting modeSet) {
            if (expandedDropdown == modeSet && my >= y + 22) {
                int idx = (int) ((my - (y + 22)) / 16.0);
                List<String> modes = modeSet.getModes();
                if (idx >= 0 && idx < modes.size()) {
                    modeSet.setValue(modes.get(idx));
                    expandedDropdown = null;
                    saveConfigQuietly();
                }
            } else if (button == 1) {
                modeSet.cycleNext();
                saveConfigQuietly();
            } else {
                expandedDropdown = (expandedDropdown == modeSet) ? null : modeSet;
            }
            listeningKeybind = null;
            return;
        }

        if (setting instanceof KeybindSetting kbSet) {
            if (kbSet.isBound() && mx >= x + w - 18) {
                kbSet.unbind();
                listeningKeybind = null;
                saveConfigQuietly();
            } else if (button == 1) {
                kbSet.unbind();
                listeningKeybind = null;
                saveConfigQuietly();
            } else {
                listeningKeybind = (listeningKeybind == kbSet) ? null : kbSet;
            }
            return;
        }

        if (setting instanceof TextSetting txtSet) {
            int boxX = x + 5;
            int boxW = w - 10;
            if (!txtSet.getValue().isEmpty() && mx >= boxX + boxW - 13) {
                txtSet.setValue("");
                saveConfigQuietly();
            }
            focusedTextSetting = txtSet;
            listeningKeybind = null;
        }
    }

    @Override
    public boolean mouseDragged(Click click, double offsetX, double offsetY) {
        double mx = click.x();
        double my = click.y();

        if (draggingSlider != null) {
            int barX = settingsX + 11;
            int barW = settingsW - 22;
            updateSliderFromMouse(draggingSlider, barX, barW, mx);
            return true;
        }

        if (touchDraggingModules) {
            if (Math.abs(my - touchDragStartY) > 2.5) {
                touchDragMoved = true;
            }
            if (touchDragMoved) {
                moduleScroll = MathHelper.clamp(moduleScroll - offsetY, 0.0, maxModuleScroll);
                return true;
            }
        }

        if (touchDraggingSettings) {
            if (Math.abs(my - touchDragStartY) > 2.5) {
                touchDragMoved = true;
            }
            if (touchDragMoved) {
                settingsScroll = MathHelper.clamp(settingsScroll - offsetY, 0.0, maxSettingsScroll);
                return true;
            }
        }

        return super.mouseDragged(click, offsetX, offsetY);
    }

    @Override
    public boolean mouseReleased(Click click) {
        if (draggingSlider != null) {
            draggingSlider = null;
            saveConfigQuietly();
        }
        touchDraggingModules = false;
        touchDraggingSettings = false;
        touchDragMoved = false;
        return super.mouseReleased(click);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        double step = verticalAmount * 18.0;
        if (isInside(mouseX, mouseY, modListX, bodyY, modListW, bodyH)) {
            moduleScroll = MathHelper.clamp(moduleScroll - step, 0.0, maxModuleScroll);
            return true;
        }
        if (isInside(mouseX, mouseY, settingsX, bodyY, settingsW, bodyH)) {
            settingsScroll = MathHelper.clamp(settingsScroll - step, 0.0, maxSettingsScroll);
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        int key = input.key();
        int modifiers = input.modifiers();

        // 1. Keybind capture mode
        if (listeningKeybind != null) {
            if (key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_DELETE || key == GLFW.GLFW_KEY_BACKSPACE) {
                listeningKeybind.unbind();
            } else {
                listeningKeybind.setValue(key);
            }
            listeningKeybind = null;
            saveConfigQuietly();
            return true;
        }

        // 2. Search input editing
        if (searchFocused) {
            if (key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) {
                searchFocused = false;
                return true;
            }
            if (key == GLFW.GLFW_KEY_BACKSPACE && !searchQuery.isEmpty()) {
                searchQuery = searchQuery.substring(0, searchQuery.length() - 1);
                moduleScroll = 0.0;
                return true;
            }
            if (isPasteCombo(key, modifiers) && this.client != null) {
                String clip = this.client.keyboard.getClipboard();
                if (clip != null && !clip.isEmpty()) {
                    appendToSearch(clip);
                }
                return true;
            }
            return true;
        }

        // 3. TextSetting input editing
        if (focusedTextSetting != null) {
            if (key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) {
                focusedTextSetting = null;
                saveConfigQuietly();
                return true;
            }
            if (key == GLFW.GLFW_KEY_BACKSPACE) {
                String cur = focusedTextSetting.getValue();
                if (!cur.isEmpty()) {
                    focusedTextSetting.setValue(cur.substring(0, cur.length() - 1));
                    saveConfigQuietly();
                }
                return true;
            }
            if (isPasteCombo(key, modifiers) && this.client != null) {
                String clip = this.client.keyboard.getClipboard();
                if (clip != null && !clip.isEmpty()) {
                    focusedTextSetting.setValue(focusedTextSetting.getValue() + clip);
                    saveConfigQuietly();
                }
                return true;
            }
            return true;
        }

        // Close GUI on ESC or the Open GUI keybind
        if (key == GLFW.GLFW_KEY_ESCAPE || NexusClientMod.getInstance().getOpenGuiKeyBinding().matchesKey(input)) {
            this.close();
            return true;
        }

        return super.keyPressed(input);
    }

    @Override
    public boolean charTyped(CharInput input) {
        if (!input.isValidChar()) {
            return false;
        }
        String typed = input.asString();
        if (typed == null || typed.isEmpty()) {
            return false;
        }

        if (searchFocused) {
            appendToSearch(typed);
            return true;
        }

        if (focusedTextSetting != null) {
            String current = focusedTextSetting.getValue();
            if (current.length() < focusedTextSetting.getMaxLength()) {
                focusedTextSetting.setValue(current + typed);
                saveConfigQuietly();
            }
            return true;
        }

        return super.charTyped(input);
    }

    private void appendToSearch(String addition) {
        String clean = addition.replace("\r", "").replace("\n", "");
        if (searchQuery.length() + clean.length() > 36) {
            clean = clean.substring(0, Math.max(0, 36 - searchQuery.length()));
        }
        searchQuery += clean;
        moduleScroll = 0.0;
    }

    private void selectModule(Module mod) {
        this.selectedModule = mod;
        if (mod != null) {
            persistedModuleId = mod.getId();
        }
        this.settingsScroll = 0.0;
        this.expandedDropdown = null;
        this.listeningKeybind = null;
        this.focusedTextSetting = null;
    }

    private static void updateSliderFromMouse(NumberSetting slider, int barX, int barW, double mouseX) {
        if (barW <= 1) {
            return;
        }
        double norm = (mouseX - barX) / (double) barW;
        slider.setFromNormalized(norm);
    }

    private static boolean isPasteCombo(int key, int modifiers) {
        return key == GLFW.GLFW_KEY_V && (modifiers & (GLFW.GLFW_MOD_CONTROL | GLFW.GLFW_MOD_SUPER)) != 0;
    }

    private static boolean isInside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx <= x + w && my >= y && my <= y + h;
    }

    private String trimToWidth(String text, int maxWidth) {
        if (text == null || maxWidth <= 8) {
            return "";
        }
        if (this.textRenderer.getWidth(text) <= maxWidth) {
            return text;
        }
        String ellipsis = "..";
        int targetW = Math.max(4, maxWidth - this.textRenderer.getWidth(ellipsis));
        return this.textRenderer.trimToWidth(text, targetW) + ellipsis;
    }

    private String trimToWidthFromEnd(String text, int maxWidth) {
        if (text == null || maxWidth <= 6) {
            return "";
        }
        if (this.textRenderer.getWidth(text) <= maxWidth) {
            return text;
        }
        for (int i = 1; i < text.length(); i++) {
            String sub = text.substring(i);
            if (this.textRenderer.getWidth(sub) <= maxWidth) {
                return sub;
            }
        }
        return "";
    }

    private void saveConfigQuietly() {
        NexusClientMod.getInstance().getConfigManager().save();
    }

    @Override
    public void close() {
        listeningKeybind = null;
        focusedTextSetting = null;
        searchFocused = false;
        draggingSlider = null;
        if (NexusClientMod.getInstance() != null && NexusClientMod.getInstance().getEventBus() != null) {
            NexusClientMod.getInstance().getEventBus().suppressGuiOpen();
        }
        saveConfigQuietly();
        super.close();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
