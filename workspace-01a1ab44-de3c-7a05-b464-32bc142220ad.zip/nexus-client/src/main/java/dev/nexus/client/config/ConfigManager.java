package dev.nexus.client.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.nexus.client.module.Module;
import dev.nexus.client.module.ModuleManager;
import dev.nexus.client.module.impl.render.FreecamModule;
import dev.nexus.client.module.setting.Setting;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Stage 5: Persistent JSON Configuration Manager.
 * - Uses FabricLoader.getConfigDir() for 100% Desktop & Android/PojavLauncher compatibility.
 * - Atomic temporary file writes prevent partial/corrupted files on mobile force-closes.
 * - Gracefully recovers with safe clamped defaults if JSON is malformed or missing.
 * - Never persists transient chunk/entity runtime data.
 */
public final class ConfigManager {
    private static final Logger LOGGER = LoggerFactory.getLogger("NexusClient");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    private static final int CONFIG_SCHEMA_VERSION = 1;

    private final ModuleManager moduleManager;
    private final Path configDir;
    private final Path configFile;

    public ConfigManager(ModuleManager moduleManager) {
        this(moduleManager, FabricLoader.getInstance().getConfigDir().resolve("nexus-client"));
    }

    public ConfigManager(ModuleManager moduleManager, Path customConfigDir) {
        this.moduleManager = moduleManager;
        this.configDir = customConfigDir;
        this.configFile = this.configDir.resolve("nexus_config.json");
    }

    public Path getConfigFile() {
        return configFile;
    }

    public synchronized void load() {
        if (!Files.exists(configFile)) {
            save();
            return;
        }

        try (Reader reader = Files.newBufferedReader(configFile, StandardCharsets.UTF_8)) {
            JsonElement parsed = JsonParser.parseReader(reader);
            if (parsed == null || !parsed.isJsonObject()) {
                LOGGER.warn("[NEXUS] Config file is not a valid JSON object; falling back to defaults.");
                resetAllToDefaults();
                save();
                return;
            }

            JsonObject root = parsed.getAsJsonObject();
            JsonObject modulesJson = root.has("modules") && root.get("modules").isJsonObject()
                ? root.getAsJsonObject("modules")
                : new JsonObject();

            for (Module module : moduleManager.getModules()) {
                if (!modulesJson.has(module.getId()) || !modulesJson.get(module.getId()).isJsonObject()) {
                    continue;
                }
                JsonObject modObj = modulesJson.getAsJsonObject(module.getId());

                if (modObj.has("settings") && modObj.get("settings").isJsonObject()) {
                    JsonObject settingsObj = modObj.getAsJsonObject("settings");
                    for (Setting<?> setting : module.getSettings()) {
                        if (settingsObj.has(setting.getKey())) {
                            try {
                                setting.fromJson(settingsObj.get(setting.getKey()));
                            } catch (Throwable t) {
                                LOGGER.warn("[NEXUS] Invalid setting '{}' in '{}', resetting to default.",
                                    setting.getKey(), module.getId());
                                setting.reset();
                            }
                        }
                    }
                }

                // Do not auto-enable Freecam on boot before joining a world
                if (!(module instanceof FreecamModule)
                    && modObj.has("enabled")
                    && modObj.get("enabled").isJsonPrimitive()
                    && modObj.get("enabled").getAsJsonPrimitive().isBoolean()) {
                    boolean shouldEnable = modObj.get("enabled").getAsBoolean();
                    module.setEnabled(shouldEnable);
                    module.setToggleAnimProgress(shouldEnable ? 1.0f : 0.0f);
                }
            }
            LOGGER.info("[NEXUS] Loaded configuration from {}", configFile);
        } catch (Throwable t) {
            LOGGER.error("[NEXUS] Failed to read config file ({}); backing up and restoring safe defaults.", t.toString());
            backupCorruptedConfig();
            resetAllToDefaults();
            save();
        }
    }

    public synchronized void save() {
        try {
            Files.createDirectories(configDir);
            JsonObject root = new JsonObject();
            root.addProperty("client", "NEXUS CLIENT");
            root.addProperty("minecraft", "1.21.11");
            root.addProperty("schemaVersion", CONFIG_SCHEMA_VERSION);

            JsonObject modulesJson = new JsonObject();
            for (Module module : moduleManager.getModules()) {
                JsonObject modObj = new JsonObject();
                // Freecam is session-scoped so players never spawn disoriented
                boolean persistedEnabled = !(module instanceof FreecamModule) && module.isEnabled();
                modObj.addProperty("enabled", persistedEnabled);

                JsonObject settingsObj = new JsonObject();
                for (Setting<?> setting : module.getSettings()) {
                    settingsObj.add(setting.getKey(), setting.toJson());
                }
                modObj.add("settings", settingsObj);
                modulesJson.add(module.getId(), modObj);
            }
            root.add("modules", modulesJson);

            Path tempFile = configDir.resolve("nexus_config.json.tmp");
            try (Writer writer = Files.newBufferedWriter(tempFile, StandardCharsets.UTF_8)) {
                GSON.toJson(root, writer);
            }
            try {
                Files.move(tempFile, configFile, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException atomicUnsupported) {
                Files.move(tempFile, configFile, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (Throwable t) {
            LOGGER.error("[NEXUS] Failed to save configuration: {}", t.toString());
        }
    }

    private void resetAllToDefaults() {
        for (Module module : moduleManager.getModules()) {
            module.setEnabled(false);
            for (Setting<?> setting : module.getSettings()) {
                setting.reset();
            }
        }
    }

    private void backupCorruptedConfig() {
        try {
            if (Files.exists(configFile)) {
                Path backup = configDir.resolve("nexus_config.corrupt.bak");
                Files.copy(configFile, backup, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (Throwable ignored) {
        }
    }
}
