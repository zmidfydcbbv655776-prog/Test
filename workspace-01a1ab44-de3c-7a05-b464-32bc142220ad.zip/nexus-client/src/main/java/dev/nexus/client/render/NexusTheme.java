package dev.nexus.client.render;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;

/**
 * NEXUS CLIENT Black & Gold UI Theme & Lightweight 2D Primitives.
 * Designed for crisp rendering on both desktop and low-res mobile/PojavLauncher screens
 * with zero heavy blur or multi-pass shaders.
 */
public final class NexusTheme {
    // Core Obsidian / Charcoal Surfaces
    public static final int BG_BACKDROP       = 0xAA060608;
    public static final int BG_WINDOW         = 0xF40C0C10;
    public static final int BG_SIDEBAR        = 0xFA101016;
    public static final int BG_HEADER         = 0xFA121218;
    public static final int BG_PANEL          = 0xF215151D;
    public static final int BG_CARD           = 0xFF191923;
    public static final int BG_CARD_HOVER     = 0xFF21212E;
    public static final int BG_CARD_SELECTED  = 0xFF25221B;
    public static final int BG_INPUT          = 0xFF0F0F15;
    public static final int BG_HUD            = 0xDC0D0D12;

    // Gold Accents & Borders
    public static final int GOLD_PRIMARY      = 0xFFD4AF37;
    public static final int GOLD_BRIGHT       = 0xFFF2C94C;
    public static final int GOLD_SOFT         = 0xFFE6C35C;
    public static final int GOLD_MUTED        = 0xFF8C7223;
    public static final int BORDER_GOLD       = 0xB8D4AF37;
    public static final int BORDER_SUBTLE     = 0x44D4AF37;
    public static final int BORDER_DARK       = 0xFF2A2A36;

    // Text Colors
    public static final int TEXT_PRIMARY      = 0xFFF5F5F7;
    public static final int TEXT_SECONDARY    = 0xFFA6A6B2;
    public static final int TEXT_MUTED        = 0xFF6E6E7A;
    public static final int TEXT_DARK_ON_GOLD = 0xFF111115;

    // Status & Pattern Colors
    public static final int STATUS_LOW_YELLOW = 0xFFF1C40F;
    public static final int STATUS_MED_ORANGE = 0xFFE67E22;
    public static final int STATUS_HIGH_GREEN = 0xFF2ECC71;
    public static final int STATUS_DANGER     = 0xFFE74C3C;
    public static final int STATUS_AQUA       = 0xFF38D9FF;

    private NexusTheme() {
    }

    public static int withAlpha(int rgbOrArgb, int alpha) {
        int a = MathHelper.clamp(alpha, 0, 255);
        return (a << 24) | (rgbOrArgb & 0x00FFFFFF);
    }

    public static int lerpColor(int c1, int c2, float t) {
        float clamped = MathHelper.clamp(t, 0.0f, 1.0f);
        int a1 = (c1 >>> 24) & 0xFF;
        int r1 = (c1 >>> 16) & 0xFF;
        int g1 = (c1 >>> 8) & 0xFF;
        int b1 = c1 & 0xFF;

        int a2 = (c2 >>> 24) & 0xFF;
        int r2 = (c2 >>> 16) & 0xFF;
        int g2 = (c2 >>> 8) & 0xFF;
        int b2 = c2 & 0xFF;

        int a = Math.round(a1 + (a2 - a1) * clamped);
        int r = Math.round(r1 + (r2 - r1) * clamped);
        int g = Math.round(g1 + (g2 - g1) * clamped);
        int b = Math.round(b1 + (b2 - b1) * clamped);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    public static float approach(float current, float target, float speed) {
        float diff = target - current;
        if (Math.abs(diff) < 0.004f) {
            return target;
        }
        return current + diff * MathHelper.clamp(speed, 0.01f, 1.0f);
    }

    /**
     * Draws a clean, lightweight beveled-corner panel with a subtle border (1px corner cut).
     * Zero shader overhead — uses 3 DrawContext.fill calls + crisp border lines.
     */
    public static void drawRoundedPanel(DrawContext ctx, int x, int y, int width, int height, int fillColor, int borderColor) {
        if (width <= 2 || height <= 2) {
            return;
        }
        int x2 = x + width;
        int y2 = y + height;

        // Inner fill with 1px softened corners
        ctx.fill(x + 1, y, x2 - 1, y2, fillColor);
        ctx.fill(x, y + 1, x + 1, y2 - 1, fillColor);
        ctx.fill(x2 - 1, y + 1, x2, y2 - 1, fillColor);

        if ((borderColor >>> 24) > 0) {
            // Top & bottom edges
            ctx.fill(x + 1, y, x2 - 1, y + 1, borderColor);
            ctx.fill(x + 1, y2 - 1, x2 - 1, y2, borderColor);
            // Left & right edges
            ctx.fill(x, y + 1, x + 1, y2 - 1, borderColor);
            ctx.fill(x2 - 1, y + 1, x2, y2 - 1, borderColor);
        }
    }

    /**
     * Draws a pill toggle switch (used for module toggles and boolean settings).
     */
    public static void drawToggleSwitch(DrawContext ctx, int x, int y, int width, int height, float progress) {
        float p = MathHelper.clamp(progress, 0.0f, 1.0f);
        int trackColor = lerpColor(0xFF282834, 0xFF5A4918, p);
        int borderColor = lerpColor(BORDER_DARK, GOLD_BRIGHT, p);
        drawRoundedPanel(ctx, x, y, width, height, trackColor, borderColor);

        int knobSize = Math.max(4, height - 4);
        int minKnobX = x + 2;
        int maxKnobX = x + width - knobSize - 2;
        int knobX = Math.round(minKnobX + (maxKnobX - minKnobX) * p);
        int knobY = y + 2;
        int knobColor = lerpColor(0xFF8E8E9A, GOLD_BRIGHT, p);
        ctx.fill(knobX, knobY, knobX + knobSize, knobY + knobSize, knobColor);
    }

    /**
     * Draws a centered, screen-clamped floating HUD tag with Black & Gold / accent border.
     */
    public static void drawFloatingTag(DrawContext ctx, TextRenderer tr, String text, int centerX, int centerY, int accentColor, boolean clampToScreen) {
        if (text == null || text.isEmpty() || tr == null) {
            return;
        }
        int tw = tr.getWidth(text);
        int w = tw + 10;
        int h = 14;
        int x = centerX - w / 2;
        int y = centerY - h / 2;
        if (clampToScreen) {
            int sw = ctx.getScaledWindowWidth();
            int sh = ctx.getScaledWindowHeight();
            x = MathHelper.clamp(x, 3, Math.max(3, sw - w - 3));
            y = MathHelper.clamp(y, 3, Math.max(3, sh - h - 3));
        }
        drawRoundedPanel(ctx, x, y, w, h, BG_HUD, withAlpha(accentColor, 200));
        ctx.fill(x + 2, y + 3, x + 3, y + h - 3, withAlpha(accentColor, 240));
        ctx.drawTextWithShadow(tr, text, x + 6, y + 3, TEXT_PRIMARY);
    }

    /**
     * Draws a clipped, bounded 2D line on the HUD (used for tracers & tooltip stems).
     * Clips to screen rectangle first so step count is strictly bounded on all resolutions.
     */
    public static void drawLine2D(DrawContext ctx, double x1, double y1, double x2, double y2, int argb) {
        if (((argb >>> 24) & 0xFF) == 0 || !Double.isFinite(x1) || !Double.isFinite(y1) || !Double.isFinite(x2) || !Double.isFinite(y2)) {
            return;
        }
        double sw = ctx.getScaledWindowWidth();
        double sh = ctx.getScaledWindowHeight();
        double[] clipped = clipLineToRect(x1, y1, x2, y2, -4.0, -4.0, sw + 4.0, sh + 4.0);
        if (clipped == null) {
            return;
        }
        double ax = clipped[0];
        double ay = clipped[1];
        double bx = clipped[2];
        double by = clipped[3];

        double dx = bx - ax;
        double dy = by - ay;
        double dist = Math.hypot(dx, dy);
        if (dist < 0.5) {
            return;
        }
        int steps = Math.min(320, Math.max(1, (int) Math.ceil(dist / 1.5)));
        double sx = dx / steps;
        double sy = dy / steps;
        double px = ax;
        double py = ay;
        for (int i = 0; i <= steps; i++) {
            int ix = (int) Math.round(px);
            int iy = (int) Math.round(py);
            ctx.fill(ix, iy, ix + 1, iy + 1, argb);
            px += sx;
            py += sy;
        }
    }

    private static double[] clipLineToRect(double x0, double y0, double x1, double y1, double xmin, double ymin, double xmax, double ymax) {
        double t0 = 0.0;
        double t1 = 1.0;
        double dx = x1 - x0;
        double dy = y1 - y0;

        double[] p = {-dx, dx, -dy, dy};
        double[] q = {x0 - xmin, xmax - x0, y0 - ymin, ymax - y0};

        for (int i = 0; i < 4; i++) {
            if (Math.abs(p[i]) < 1e-9) {
                if (q[i] < 0.0) {
                    return null;
                }
            } else {
                double r = q[i] / p[i];
                if (p[i] < 0.0) {
                    if (r > t1) return null;
                    if (r > t0) t0 = r;
                } else {
                    if (r < t0) return null;
                    if (r < t1) t1 = r;
                }
            }
        }
        return new double[]{x0 + t0 * dx, y0 + t0 * dy, x0 + t1 * dx, y0 + t1 * dy};
    }

    /**
     * Draws a small crisp pixel-art ring/circle centered at (cx, cy) for HUD crosshairs & indicators.
     */
    public static void drawSmallCircleOutline(DrawContext ctx, int cx, int cy, int radius, int color) {
        if (radius <= 1) {
            ctx.fill(cx - 1, cy - 1, cx + 2, cy + 2, color);
            return;
        }
        int x = radius;
        int y = 0;
        int err = 1 - x;
        while (x >= y) {
            plotOctants(ctx, cx, cy, x, y, color);
            y++;
            if (err < 0) {
                err += 2 * y + 1;
            } else {
                x--;
                err += 2 * (y - x) + 1;
            }
        }
    }

    private static void plotOctants(DrawContext ctx, int cx, int cy, int x, int y, int color) {
        ctx.fill(cx + x, cy + y, cx + x + 1, cy + y + 1, color);
        ctx.fill(cx + y, cy + x, cx + y + 1, cy + x + 1, color);
        ctx.fill(cx - y, cy + x, cx - y + 1, cy + x + 1, color);
        ctx.fill(cx - x, cy + y, cx - x + 1, cy + y + 1, color);
        ctx.fill(cx - x, cy - y, cx - x + 1, cy - y + 1, color);
        ctx.fill(cx - y, cy - x, cx - y + 1, cy - x + 1, color);
        ctx.fill(cx + y, cy - x, cx + y + 1, cy - x + 1, color);
        ctx.fill(cx + x, cy - y, cx + x + 1, cy - y + 1, color);
    }
}
