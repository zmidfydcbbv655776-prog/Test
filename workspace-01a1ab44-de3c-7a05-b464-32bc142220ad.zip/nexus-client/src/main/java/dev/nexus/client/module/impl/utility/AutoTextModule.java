package dev.nexus.client.module.impl.utility;

import dev.nexus.client.module.Category;
import dev.nexus.client.module.Module;
import dev.nexus.client.module.setting.BooleanSetting;
import dev.nexus.client.module.setting.KeybindSetting;
import dev.nexus.client.module.setting.NumberSetting;
import dev.nexus.client.module.setting.TextSetting;
import dev.nexus.client.util.KeyUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.util.StringHelper;

/**
 * Module H: Auto Text
 * Sends or inserts a saved custom message/command when the configured Trigger Key is pressed.
 * Respects Minecraft 1.21.11 chat rules, length limits, and GUI/typing focus guards.
 */
public final class AutoTextModule extends Module {
    private final TextSetting messageText = addSetting(
        new TextSetting("message", "Message Text", "Custom chat message or /command (max 256 chars)", "gg", 256)
    );
    private final KeybindSetting triggerKey = addSetting(
        new KeybindSetting("trigger_key", "Send Keybind", "Key to trigger sending/inserting the saved text", KeyUtil.UNBOUND)
    );
    private final BooleanSetting instantSend = addSetting(
        new BooleanSetting("instant_send", "Instant Send", "ON: send immediately | OFF: open chat box with text pre-filled", true)
    );
    private final NumberSetting cooldownMs = addSetting(
        new NumberSetting("cooldown_ms", "Cooldown (ms)", "Minimum delay between triggers to prevent chat spam", 750, 100, 5000, 50)
    );

    private boolean wasTriggerDown = false;
    private long lastFireTimeMs = 0L;

    public AutoTextModule() {
        super("auto_text", "Auto Text", "Enters or sends a custom text message on a configurable keybind.", Category.UTILITY);
    }

    public KeybindSetting getTriggerKey() {
        return triggerKey;
    }

    @Override
    protected void onDisable() {
        wasTriggerDown = false;
    }

    @Override
    public void onWorldCleanup() {
        wasTriggerDown = false;
    }

    @Override
    public void onTick(MinecraftClient client) {
        if (client.player == null || client.world == null) {
            wasTriggerDown = false;
            return;
        }
        // Never fire while any screen (ClickGUI, ChatScreen, Inventory, Sign, Anvil) is open
        if (client.currentScreen != null) {
            wasTriggerDown = KeyUtil.isPressed(client, triggerKey.getValue());
            return;
        }
        if (!triggerKey.isBound()) {
            wasTriggerDown = false;
            return;
        }

        boolean isDown = KeyUtil.isPressed(client, triggerKey.getValue());
        if (isDown && !wasTriggerDown) {
            executeAutoText(client);
        }
        wasTriggerDown = isDown;
    }

    public void executeAutoText(MinecraftClient client) {
        if (client.player == null || client.currentScreen != null) {
            return;
        }
        long now = System.currentTimeMillis();
        if (now - lastFireTimeMs < cooldownMs.getIntValue()) {
            return;
        }

        String raw = messageText.getValue();
        if (raw == null) {
            return;
        }
        String sanitized = StringHelper.truncateChat(StringHelper.stripInvalidChars(raw.trim()));
        if (sanitized.isEmpty()) {
            return;
        }

        lastFireTimeMs = now;

        if (!instantSend.getValue()) {
            // Place text into the chat input box without sending immediately
            client.setScreen(new ChatScreen(sanitized, false));
            return;
        }

        ClientPlayNetworkHandler networkHandler = client.getNetworkHandler();
        if (networkHandler == null) {
            return;
        }

        if (sanitized.startsWith("/")) {
            String command = sanitized.substring(1).trim();
            if (!command.isEmpty()) {
                networkHandler.sendChatCommand(command);
            }
        } else {
            networkHandler.sendChatMessage(sanitized);
        }
    }
}
