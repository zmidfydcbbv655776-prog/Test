package dev.nexus.client;

import dev.nexus.client.config.ConfigManager;
import dev.nexus.client.event.NexusEventBus;
import dev.nexus.client.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * NEXUS CLIENT — Minecraft Java Edition 1.21.11 (Fabric / Desktop & PojavLauncher)
 */
public final class NexusClientMod implements ClientModInitializer {
    public static final String MOD_ID = "nexusclient";
    public static final String MOD_NAME = "NEXUS CLIENT";
    public static final String MOD_VERSION = "1.0.0+mc1.21.11";
    private static final Logger LOGGER = LoggerFactory.getLogger("NexusClient");

    private static NexusClientMod instance;

    private ModuleManager moduleManager;
    private ConfigManager configManager;
    private NexusEventBus eventBus;
    private KeyBinding openGuiKeyBinding;

    @Override
    public void onInitializeClient() {
        instance = this;
        LOGGER.info("[NEXUS] Initializing {} ({})", MOD_NAME, MOD_VERSION);

        KeyBinding.Category nexusKeyCategory = KeyBinding.Category.create(Identifier.of(MOD_ID, "main"));
        this.openGuiKeyBinding = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.nexusclient.open_gui",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_RIGHT_SHIFT,
            nexusKeyCategory
        ));

        this.moduleManager = new ModuleManager();
        this.moduleManager.init();

        this.configManager = new ConfigManager(this.moduleManager);
        this.configManager.load();

        this.eventBus = new NexusEventBus(this.moduleManager, this.configManager, this.openGuiKeyBinding);
        this.eventBus.registerAll();

        LOGGER.info("[NEXUS] Ready. Press Right Shift (or bind 'Open NEXUS ClickGUI' in Controls / PojavLauncher) to open GUI.");
    }

    public static NexusClientMod getInstance() {
        return instance;
    }

    public ModuleManager getModuleManager() {
        return moduleManager;
    }

    public ConfigManager getConfigManager() {
        return configManager;
    }

    public NexusEventBus getEventBus() {
        return eventBus;
    }

    public KeyBinding getOpenGuiKeyBinding() {
        return openGuiKeyBinding;
    }
}
