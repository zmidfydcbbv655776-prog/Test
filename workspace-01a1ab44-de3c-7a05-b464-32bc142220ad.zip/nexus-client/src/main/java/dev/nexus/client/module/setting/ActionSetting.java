package dev.nexus.client.module.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonNull;

/**
 * Stateless clickable action button setting rendered inside the ClickGUI settings inspector.
 */
public final class ActionSetting extends Setting<Boolean> {
    private final Runnable action;
    private long lastTriggerTimeMs = 0L;

    public ActionSetting(String key, String name, String description, Runnable action) {
        super(key, name, description, Boolean.FALSE);
        this.action = action;
    }

    public void trigger() {
        this.lastTriggerTimeMs = System.currentTimeMillis();
        if (action != null) {
            action.run();
        }
    }

    public boolean isRecentlyTriggered() {
        return (System.currentTimeMillis() - lastTriggerTimeMs) < 250L;
    }

    @Override
    protected Boolean validate(Boolean candidate) {
        return Boolean.FALSE;
    }

    @Override
    public JsonElement toJson() {
        return JsonNull.INSTANCE;
    }

    @Override
    public void fromJson(JsonElement element) {
        // Action buttons are stateless triggers; nothing to restore from disk.
    }
}
