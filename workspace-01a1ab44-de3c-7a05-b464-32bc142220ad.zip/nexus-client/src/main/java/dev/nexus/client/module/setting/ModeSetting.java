package dev.nexus.client.module.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import java.util.List;

public final class ModeSetting extends Setting<String> {
    private final List<String> modes;

    public ModeSetting(String key, String name, String description, String defaultMode, String... availableModes) {
        super(key, name, description, defaultMode);
        this.modes = List.of(availableModes);
        if (this.modes.isEmpty()) {
            throw new IllegalArgumentException("ModeSetting requires at least one mode");
        }
        this.value = validate(defaultMode);
    }

    public List<String> getModes() {
        return modes;
    }

    public boolean isMode(String candidate) {
        return getValue().equalsIgnoreCase(candidate);
    }

    public void cycleNext() {
        int idx = modes.indexOf(getValue());
        int next = (idx + 1) % modes.size();
        setValue(modes.get(next));
    }

    @Override
    protected String validate(String candidate) {
        if (modes == null || modes.isEmpty()) {
            return candidate == null ? getDefaultValue() : candidate;
        }
        if (candidate != null) {
            for (String mode : modes) {
                if (mode.equalsIgnoreCase(candidate)) {
                    return mode;
                }
            }
        }
        return modes.contains(getDefaultValue()) ? getDefaultValue() : modes.getFirst();
    }

    @Override
    public JsonElement toJson() {
        return new JsonPrimitive(getValue());
    }

    @Override
    public void fromJson(JsonElement element) {
        if (element != null && element.isJsonPrimitive() && element.getAsJsonPrimitive().isString()) {
            setValue(element.getAsString());
        } else {
            reset();
        }
    }
}
