package dev.nexus.client.module;

import dev.nexus.client.module.impl.combat.AimAssistModule;
import dev.nexus.client.module.impl.combat.AutoMaceModule;
import dev.nexus.client.module.impl.render.FreecamModule;
import dev.nexus.client.module.impl.render.PlayerEspModule;
import dev.nexus.client.module.impl.render.StorageEspModule;
import dev.nexus.client.module.impl.utility.AutoTextModule;
import dev.nexus.client.module.impl.world.AmethystBaseFinderModule;
import dev.nexus.client.module.impl.world.StashFinderModule;
import dev.nexus.client.module.impl.world.SusChunkFinderModule;
import dev.nexus.client.module.setting.KeybindSetting;
import dev.nexus.client.module.setting.Setting;
import dev.nexus.client.util.KeyUtil;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.HashSet;
import net.minecraft.client.MinecraftClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Central NEXUS Module Registry & Lifecycle Manager.
 * Architected for 15+ modules without core modification; registers the 8 specified modules cleanly.
 */
public final class ModuleManager {
    public static final int TARGET_MODULE_CAPACITY = 15;
    private static final Logger LOGGER = LoggerFactory.getLogger("NexusClient");

    private final Map<String, Module> modulesById = new LinkedHashMap<>(TARGET_MODULE_CAPACITY);
    private final List<Module> moduleList = new ArrayList<>(TARGET_MODULE_CAPACITY);
    private final Map<Integer, Boolean> previousKeyStates = new HashMap<>();

    public void init() {
        modulesById.clear();
        moduleList.clear();

        // Combat (2)
        register(new AimAssistModule());
        register(new AutoMaceModule());

        // Render (3)
        register(new StorageEspModule());
        register(new PlayerEspModule());
        register(new FreecamModule());

        // World (3)
        register(new AmethystBaseFinderModule());
        register(new SusChunkFinderModule());
        register(new StashFinderModule());

        // Utility (1)
        register(new AutoTextModule());

        LOGGER.info("[NEXUS] Registered {}/{} target modules.", moduleList.size(), TARGET_MODULE_CAPACITY);
    }

    public synchronized void register(Module module) {
        if (module == null) {
            throw new IllegalArgumentException("Cannot register null module");
        }
        if (modulesById.containsKey(module.getId())) {
            throw new IllegalStateException("Duplicate module id: " + module.getId());
        }
        modulesById.put(module.getId(), module);
        moduleList.add(module);
    }

    public List<Module> getModules() {
        return Collections.unmodifiableList(moduleList);
    }

    public Module getById(String id) {
        return modulesById.get(id);
    }

    public <T extends Module> T getModule(Class<T> type) {
        for (Module m : moduleList) {
            if (type.isInstance(m)) {
                return type.cast(m);
            }
        }
        return null;
    }

    public List<Module> getByCategory(Category category) {
        List<Module> filtered = new ArrayList<>();
        for (Module m : moduleList) {
            if (m.getCategory() == category) {
                filtered.add(m);
            }
        }
        return filtered;
    }

    public List<Module> search(String query, Category fallbackCategory) {
        if (query == null || query.isBlank()) {
            return fallbackCategory == null ? getModules() : getByCategory(fallbackCategory);
        }
        String needle = query.trim().toLowerCase(Locale.ROOT);
        List<Module> matches = new ArrayList<>();
        for (Module m : moduleList) {
            if (m.getName().toLowerCase(Locale.ROOT).contains(needle)
                || m.getDescription().toLowerCase(Locale.ROOT).contains(needle)
                || m.getCategory().getDisplayName().toLowerCase(Locale.ROOT).contains(needle)) {
                matches.add(m);
            }
        }
        return matches;
    }

    /**
     * Checks whether more than one keybind setting across modules shares the given keyCode.
     */
    public boolean hasKeybindConflict(KeybindSetting target) {
        if (target == null || !target.isBound()) {
            return false;
        }
        int code = target.getValue();
        int count = 0;
        for (Module m : moduleList) {
            for (Setting<?> s : m.getSettings()) {
                if (s instanceof KeybindSetting kb && kb.isBound() && kb.getValue() == code) {
                    count++;
                    if (count > 1) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**
     * Polls module toggle keybinds on client tick when no GUI/Screen is open.
     * Prevents duplicate firing within the same tick and updates key edge state cleanly.
     */
    public void pollModuleToggleKeybinds(MinecraftClient client) {
        if (client == null || client.player == null || client.world == null) {
            previousKeyStates.clear();
            return;
        }
        boolean screenOpen = client.currentScreen != null;
        Set<Integer> checkedThisTick = new HashSet<>();

        for (Module m : moduleList) {
            int code = m.getToggleKeybind().getValue();
            if (!KeyUtil.isBound(code)) {
                continue;
            }
            boolean isDown = KeyUtil.isPressed(client, code);
            boolean wasDown = previousKeyStates.getOrDefault(code, false);

            if (!screenOpen && isDown && !wasDown && checkedThisTick.add(code)) {
                // Toggle all modules bound to this toggle key once on rising edge
                for (Module candidate : moduleList) {
                    if (candidate.getToggleKeybind().getValue() == code) {
                        try {
                            candidate.toggle();
                        } catch (Throwable t) {
                            candidate.handleModuleError("toggleKeybind", t);
                        }
                    }
                }
            }
        }

        // Update edge states after processing rising edges
        for (Module m : moduleList) {
            int code = m.getToggleKeybind().getValue();
            if (KeyUtil.isBound(code)) {
                previousKeyStates.put(code, KeyUtil.isPressed(client, code));
            }
        }
    }

    public void onWorldCleanupAll() {
        previousKeyStates.clear();
        for (Module m : moduleList) {
            try {
                m.onWorldCleanup();
            } catch (Throwable t) {
                m.handleModuleError("onWorldCleanup", t);
            }
        }
    }
}
