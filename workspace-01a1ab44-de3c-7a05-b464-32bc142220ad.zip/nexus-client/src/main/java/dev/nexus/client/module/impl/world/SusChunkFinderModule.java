package dev.nexus.client.module.impl.world;

import dev.nexus.client.event.WorldChunkTracker;
import dev.nexus.client.module.Category;
import dev.nexus.client.module.Module;
import dev.nexus.client.module.setting.ActionSetting;
import dev.nexus.client.module.setting.BooleanSetting;
import dev.nexus.client.module.setting.NumberSetting;
import dev.nexus.client.module.setting.TextSetting;
import dev.nexus.client.render.HudLayoutHelper;
import dev.nexus.client.render.NexusTheme;
import dev.nexus.client.render.WorldProjector;
import dev.nexus.client.render.WorldRenderHelper;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.block.AbstractBannerBlock;
import net.minecraft.block.AbstractPressurePlateBlock;
import net.minecraft.block.AbstractSignBlock;
import net.minecraft.block.AbstractSkullBlock;
import net.minecraft.block.BedBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.ButtonBlock;
import net.minecraft.block.CandleBlock;
import net.minecraft.block.CarpetBlock;
import net.minecraft.block.ChestBlock;
import net.minecraft.block.DoorBlock;
import net.minecraft.block.FenceBlock;
import net.minecraft.block.FenceGateBlock;
import net.minecraft.block.GlazedTerracottaBlock;
import net.minecraft.block.ShulkerBoxBlock;
import net.minecraft.block.StainedGlassBlock;
import net.minecraft.block.StainedGlassPaneBlock;
import net.minecraft.block.TrapdoorBlock;
import net.minecraft.block.entity.BarrelBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.EnderChestBlockEntity;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.block.entity.TrappedChestBlockEntity;
import net.minecraft.block.enums.ChestType;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.Leashable;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.decoration.ItemFrameEntity;
import net.minecraft.entity.decoration.painting.PaintingEntity;
import net.minecraft.entity.passive.AbstractHorseEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.passive.TameableEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.BiomeTags;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.property.Properties;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.Heightmap;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;

/**
 * Module G: SusChunkFinder
 * Adapted to Minecraft 1.21.11 following the heuristic architecture of SusChunkFinder.java
 * (https://github.com/zmidfydcbbv655776-prog/New):
 *  - 10 independent base-activity signal channels combined via Noisy-OR with per-signal toggles & weights
 *  - Mineshaft, Trial Chamber, Shipwreck, and natural Dungeon structure discounting with ±2 chunk propagation
 *  - Neighboring chunk suspicion spillover (0.35 * adjacent own score)
 *  - Live non-spectator player chunk flagging
 *  - Incremental time-budgeted chunk scanner with chunk-identity skip cache
 *  - Union-Find cluster merging, non-overlapping far-distance outline growth, crosshair hover inspector card,
 *    top-down region minimap, corner indicator cards, chat/sound alerts, and optional async Discord webhook alerts.
 */
public final class SusChunkFinderModule extends Module {
    private static final int COL_LOW  = NexusTheme.STATUS_LOW_YELLOW;
    private static final int COL_MID  = NexusTheme.STATUS_MED_ORANGE;
    private static final int COL_HIGH = NexusTheme.STATUS_DANGER;
    private static final int COL_LIVE = NexusTheme.STATUS_AQUA;

    private static final double LIVE_RELIABILITY = 0.60;
    private static final long TICK_SCAN_BUDGET_NS = 10_000_000L; // 10 ms max per client tick

    public enum Sig {
        MACHINE ("Machines",       0.85,  3.0, 0.4),
        STORAGE ("Storage",        0.70,  4.0, 0.3),
        FARM    ("Crops",          0.55,  8.0, 0.3),
        PLACED  ("Player blocks",  0.55, 14.0, 0.2),
        LIGHT   ("Deep light",     0.50,  8.0, 0.2),
        ENTITY  ("Base entities",  0.55,  5.0, 0.5),
        GROWTH  ("Old growth",     0.20, 12.0, 1.0),
        REDSTONE("Redstone",       0.75,  6.0, 0.4),
        PORTAL  ("Portal",         0.55,  6.0, 0.3),
        DECOR   ("Decor / stations", 0.50, 10.0, 0.3);

        public final String label;
        public final double reliability;
        public final double scale;
        public final double structDiscount;

        Sig(String label, double reliability, double scale, double structDiscount) {
            this.label = label;
            this.reliability = reliability;
            this.scale = scale;
            this.structDiscount = structDiscount;
        }
    }

    private static final Sig[] SIGS = Sig.values();

    // Marker classification constants for structure & shipwreck filtering
    private static final int M_STRUCT    = 1;
    private static final int M_WEB       = 2;
    private static final int M_RAIL      = 3;
    private static final int M_WOOD      = 4;
    private static final int M_PLAYER    = 5;
    private static final int M_TRIAL_DEF = 6;
    private static final int M_TUFF_BRK  = 7;
    private static final int M_COPPER    = 8;

    private static volatile boolean tablesReady = false;
    private static final Map<Block, Sig> BLOCK_SIG = new IdentityHashMap<>(512);
    private static final Map<Block, Integer> BLOCK_MARK = new IdentityHashMap<>(256);

    // ---------------- Core Settings ----------------
    private final NumberSetting rangeChunks = addSetting(
        new NumberSetting("range_chunks", "Range (chunks)", "Radius around player to scan for base activity", 8, 3, 24, 1)
    );
    private final NumberSetting minPercent = addSetting(
        new NumberSetting("min_pct", "Min %", "Minimum combined suspicion score to highlight a chunk", 35, 10, 90, 5)
    );
    private final NumberSetting scanSpeed = addSetting(
        new NumberSetting("scan_speed", "Scan speed", "Chunks scanned per tick (time-capped at 10ms)", 4, 1, 32, 1)
    );
    private final NumberSetting rescanDelay = addSetting(
        new NumberSetting("rescan_delay", "Rescan delay", "Ticks to wait before starting the next sweep", 80, 0, 300, 10)
    );
    private final BooleanSetting skipScanned = addSetting(
        new BooleanSetting("skip_scanned", "Skip scanned chunks", "Only scan newly loaded or reloaded chunk instances", true)
    );
    @SuppressWarnings("unused")
    private final ActionSetting rescanAllBtn = addSetting(
        new ActionSetting("rescan_all", "Rescan all chunks", "Clear scan cache and re-evaluate all loaded chunks", this::rescanAllChunks)
    );

    // ---------------- Structure & Player Heuristics ----------------
    private final BooleanSetting ignoreStructures = addSetting(
        new BooleanSetting("ignore_structures", "Ignore structures", "Discount mineshafts, trial chambers, dungeons & ruins", true)
    );
    private final BooleanSetting findInWater = addSetting(
        new BooleanSetting("find_in_water", "Find in water", "OFF suppresses natural ocean/beach shipwrecks", false)
    );
    private final BooleanSetting flagLivePlayers = addSetting(
        new BooleanSetting("flag_players", "Flag live players", "Mark chunks where other non-spectator players are seen", true)
    );
    private final NumberSetting playerFlagSeconds = (NumberSetting) addSetting(
        new NumberSetting("player_flag_sec", "Player flag time (s)", "How long a chunk stays flagged after a player leaves", 120, 15, 600, 15)
    ).visibleWhen(flagLivePlayers::getValue);

    // ---------------- 3D & HUD Visual Settings ----------------
    private final BooleanSetting mergeChunks = addSetting(
        new BooleanSetting("merge_chunks", "Merge nearby chunks", "Combine touching suspect chunks into unified cluster outlines", true)
    );
    private final NumberSetting farGrowPct = addSetting(
        new NumberSetting("far_grow", "Bigger when far %", "Scale distant cluster outlines for visibility without overlap", 150, 0, 400, 25)
    );
    private final BooleanSetting hoverInfo = addSetting(
        new BooleanSetting("hover_info", "Hover info", "Expand clue breakdown card when aiming at a cluster", true)
    );
    private final BooleanSetting glow = addSetting(
        new BooleanSetting("glow", "Glow", "Soft halo around 3D chunk cluster outlines", true)
    );
    private final NumberSetting thickness = addSetting(
        new NumberSetting("thickness", "Thickness", "3D cluster outline stroke thickness", 2.0, 1.0, 4.0, 0.5)
    );
    private final BooleanSetting labels = addSetting(
        new BooleanSetting("labels", "Labels", "Draw projected % chips on suspicious clusters", true)
    );
    private final BooleanSetting tracerToBest = addSetting(
        new BooleanSetting("tracer_best", "Tracer to best", "Draw 2D HUD tracer line to the strongest cluster", false)
    );
    private final BooleanSetting showProgress = addSetting(
        new BooleanSetting("scan_progress", "Scan progress", "Display top-left scan progress bar", true)
    );
    private final BooleanSetting regionMap = addSetting(
        new BooleanSetting("region_map", "Region map", "Display top-down chunk radar on the right side of HUD", false)
    );
    private final NumberSetting mapSize = (NumberSetting) addSetting(
        new NumberSetting("map_size", "Map size", "Region map width/height in GUI pixels", 96, 64, 180, 8)
    ).visibleWhen(regionMap::getValue);
    private final BooleanSetting cornerIndicator = addSetting(
        new BooleanSetting("corner_indicator", "Corner indicator", "Show bottom-right nearest player & strongest base cards", true)
    );

    // ---------------- Alerts & Discord Webhook ----------------
    private final BooleanSetting chatAlert = addSetting(
        new BooleanSetting("chat_alert", "Chat alert", "Send client-side chat notification on high-score chunks", true)
    );
    private final BooleanSetting soundAlert = addSetting(
        new BooleanSetting("sound_alert", "Sound alert", "Play chime when a high-score base or player is detected", true)
    );
    private final NumberSetting alertAtPct = addSetting(
        new NumberSetting("alert_pct", "Alert at %", "Suspicion % threshold required for chat/sound/Discord alerts", 65, 30, 95, 5)
    );
    private final BooleanSetting discordAlert = addSetting(
        new BooleanSetting("discord_alert", "Discord alert", "POST base alerts to the configured Discord Webhook URL", false)
    );
    private final TextSetting discordWebhookUrl = (TextSetting) addSetting(
        new TextSetting("discord_webhook", "Webhook URL", "https://discord.com/api/webhooks/...", "", 320)
    ).visibleWhen(discordAlert::getValue);
    @SuppressWarnings("unused")
    private final ActionSetting discordTestBtn = (ActionSetting) addSetting(
        new ActionSetting("discord_test", "Send Discord test", "Send a test message to verify your Discord Webhook", this::sendDiscordTest)
    ).visibleWhen(discordAlert::getValue);

    // ---------------- Per-Signal Toggles & Weights ----------------
    private final Map<Sig, BooleanSetting> sigEnabled = new IdentityHashMap<>();
    private final Map<Sig, NumberSetting> sigWeight = new IdentityHashMap<>();

    // ---------------- Runtime State ----------------
    private final Map<Long, ChunkInfo> chunks = new ConcurrentHashMap<>();
    private final Map<Long, Integer> scannedChunkIdentity = new HashMap<>();
    private final Set<Long> alertedChunks = ConcurrentHashMap.newKeySet();
    private final List<long[]> scanBatch = new ArrayList<>();

    private ClientWorld lastWorld = null;
    private int scanCursor = 0;
    private int waitTicks = 0;
    private long passStartMs = 0L;
    private long lastPassDurationMs = -1L;
    private int settingsStamp = 0;

    // Smoothed hover tooltip animation state
    private long tipKey = Long.MIN_VALUE;
    private float tipOpen = 0.0f;
    private long tipLastNs = 0L;

    private volatile List<Cluster> latestClusters = List.of();
    private HttpClient httpClient;
    private final double[] projA = new double[2];
    private final double[] projB = new double[2];
    private ItemStack iconPlayerHead;
    private ItemStack iconChest;

    private static final class ChunkInfo {
        final int cx, cz;
        final double[] raw = new double[SIGS.length];
        double own;
        double score;
        boolean structRaw, isMine, isTrial, shipRaw;
        int topY = 64;
        long liveUntilMs;
        String liveName;

        ChunkInfo(int cx, int cz) {
            this.cx = cx;
            this.cz = cz;
        }
    }

    private static final class Cluster {
        final List<ChunkInfo> members = new ArrayList<>();
        double cx, cz, y;
        double bestScore;
        ChunkInfo bestChunk;
        boolean anyLive;
        String liveName;
        double scale = 1.0;

        long key() {
            return ChunkPos.toLong(bestChunk.cx, bestChunk.cz);
        }
    }

    private record ClueRow(String label, double contribution, double count) {
    }

    public SusChunkFinderModule() {
        super("sus_chunk_finder", "SusChunkFinder", "Multi-signal heuristic base & player activity scanner.", Category.WORLD);
        for (Sig s : SIGS) {
            String slug = s.name().toLowerCase(Locale.ROOT);
            BooleanSetting toggle = addSetting(
                new BooleanSetting("sig_" + slug, "Sig: " + s.label, "Include " + s.label + " in base scoring", s != Sig.GROWTH)
            );
            NumberSetting weight = (NumberSetting) addSetting(
                new NumberSetting("weight_" + slug, "Weight: " + s.label, "Relative multiplier (%) for " + s.label, 100, 0, 200, 10)
            ).visibleWhen(toggle::getValue);
            sigEnabled.put(s, toggle);
            sigWeight.put(s, weight);
        }
    }

    @Override
    protected void onEnable() {
        clearRuntimeState();
        lastWorld = mc != null ? mc.world : null;
    }

    @Override
    protected void onDisable() {
        clearRuntimeState();
    }

    @Override
    public void onWorldCleanup() {
        clearRuntimeState();
    }

    @Override
    public void onChunkUnload(ClientWorld world, WorldChunk chunk) {
        if (chunk != null) {
            long key = chunk.getPos().toLong();
            scannedChunkIdentity.remove(key);
        }
    }

    private void clearRuntimeState() {
        chunks.clear();
        scannedChunkIdentity.clear();
        alertedChunks.clear();
        scanBatch.clear();
        latestClusters = List.of();
        scanCursor = 0;
        waitTicks = 0;
        passStartMs = 0L;
        lastPassDurationMs = -1L;
        tipKey = Long.MIN_VALUE;
        tipOpen = 0.0f;
        tipLastNs = 0L;
        lastWorld = null;
    }

    public void rescanAllChunks() {
        chunks.clear();
        scannedChunkIdentity.clear();
        alertedChunks.clear();
        scanBatch.clear();
        latestClusters = List.of();
        scanCursor = 0;
        waitTicks = 0;
    }

    private int computeSettingsStamp() {
        int h = Boolean.hashCode(ignoreStructures.getValue()) * 31 + Boolean.hashCode(findInWater.getValue());
        for (Sig s : SIGS) {
            h = h * 31 + Boolean.hashCode(sigEnabled.get(s).getValue());
            h = h * 31 + sigWeight.get(s).getIntValue();
        }
        return h;
    }

    @Override
    public void onTick(MinecraftClient client) {
        if (client.world == null || client.player == null) {
            clearRuntimeState();
            return;
        }
        ensureTables();

        if (client.world != lastWorld) {
            clearRuntimeState();
            lastWorld = client.world;
        }

        int stamp = computeSettingsStamp();
        if (stamp != settingsStamp) {
            settingsStamp = stamp;
            for (ChunkInfo info : chunks.values()) {
                rateChunk(info);
            }
            recomputeNeighborSpread();
        }

        spotLivePlayers(client);

        int radius = rangeChunks.getIntValue();
        int pcx = client.player.getChunkPos().x;
        int pcz = client.player.getChunkPos().z;

        // Prune chunks well beyond scan range so memory stays bounded during long Elytra flights
        int keepRange = radius + 6;
        chunks.entrySet().removeIf(e -> {
            ChunkInfo ci = e.getValue();
            boolean tooFar = Math.abs(ci.cx - pcx) > keepRange || Math.abs(ci.cz - pcz) > keepRange;
            if (tooFar) {
                scannedChunkIdentity.remove(e.getKey());
            }
            return tooFar;
        });

        if (scanCursor >= scanBatch.size()) {
            if (waitTicks > 0) {
                waitTicks--;
                rebuildClusters(client);
                return;
            }
            scanBatch.clear();
            boolean skipKnown = skipScanned.getValue();
            for (int dx = -radius; dx <= radius; dx++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    if (dx * dx + dz * dz > radius * radius) continue;
                    int cx = pcx + dx;
                    int cz = pcz + dz;
                    if (!WorldChunkTracker.isChunkCurrentlyLoaded(client.world, cx, cz)) continue;
                    WorldChunk wc = client.world.getChunkManager().getWorldChunk(cx, cz);
                    if (wc == null || wc.isEmpty()) continue;

                    if (skipKnown) {
                        Integer prevId = scannedChunkIdentity.get(ChunkPos.toLong(cx, cz));
                        if (prevId != null && prevId == System.identityHashCode(wc)) {
                            continue;
                        }
                    }
                    scanBatch.add(new long[]{cx, cz, (long) dx * dx + (long) dz * dz});
                }
            }
            scanBatch.sort(Comparator.comparingLong(a -> a[2]));
            scanCursor = 0;
            passStartMs = System.currentTimeMillis();
            if (scanBatch.isEmpty()) {
                waitTicks = Math.max(10, rescanDelay.getIntValue());
                rebuildClusters(client);
                return;
            }
        }

        int speed = scanSpeed.getIntValue();
        long deadlineNs = System.nanoTime() + TICK_SCAN_BUDGET_NS;
        int done = 0;

        while (done < speed && scanCursor < scanBatch.size()) {
            long[] item = scanBatch.get(scanCursor++);
            scanChunk(client, (int) item[0], (int) item[1]);
            done++;
            if (System.nanoTime() >= deadlineNs) {
                break;
            }
        }

        recomputeNeighborSpread();
        rebuildClusters(client);

        if (scanCursor >= scanBatch.size()) {
            lastPassDurationMs = System.currentTimeMillis() - passStartMs;
            waitTicks = rescanDelay.getIntValue();
        }
    }

    private void spotLivePlayers(MinecraftClient client) {
        if (!flagLivePlayers.getValue()) {
            return;
        }
        long holdMs = playerFlagSeconds.getIntValue() * 1000L;
        long now = System.currentTimeMillis();

        for (AbstractClientPlayerEntity other : client.world.getPlayers()) {
            if (other == client.player || other.isSpectator() || !other.isAlive()) {
                continue;
            }
            int cx = other.getBlockX() >> 4;
            int cz = other.getBlockZ() >> 4;
            long key = ChunkPos.toLong(cx, cz);
            ChunkInfo info = chunks.computeIfAbsent(key, k -> new ChunkInfo(cx, cz));
            boolean freshSight = now > info.liveUntilMs;
            info.liveUntilMs = now + holdMs;
            info.liveName = other.getGameProfile().name();
            info.topY = other.getBlockY();

            if (freshSight && alertedChunks.add(key ^ 0x5A5A5A5AL)) {
                String msg = String.format(Locale.ROOT, "Player %s spotted in chunk [%d, %d] (%d, %d)",
                    info.liveName, cx, cz, other.getBlockX(), other.getBlockZ());
                if (chatAlert.getValue()) {
                    client.player.sendMessage(
                        Text.literal("[SusChunk] ").formatted(Formatting.AQUA)
                            .append(Text.literal(msg).formatted(Formatting.WHITE)),
                        false
                    );
                }
                if (soundAlert.getValue()) {
                    client.player.playSound(SoundEvents.BLOCK_NOTE_BLOCK_PLING.value(), 0.85f, 1.45f);
                }
                postDiscordAlert(":eyes: **" + msg + "**");
            }
        }
    }

    private void scanChunk(MinecraftClient client, int cx, int cz) {
        ClientWorld world = client.world;
        if (!WorldChunkTracker.isChunkCurrentlyLoaded(world, cx, cz)) {
            return;
        }
        WorldChunk chunk = world.getChunkManager().getWorldChunk(cx, cz);
        if (chunk == null || chunk.isEmpty()) {
            return;
        }

        long key = ChunkPos.toLong(cx, cz);
        scannedChunkIdentity.put(key, System.identityHashCode(chunk));

        ChunkInfo prev = chunks.get(key);
        boolean wasBigStruct = prev != null && (prev.isMine || prev.isTrial);

        ChunkInfo info = new ChunkInfo(cx, cz);
        if (prev != null) {
            info.liveUntilMs = prev.liveUntilMs;
            info.liveName = prev.liveName;
        }

        int spawners = 0;
        for (BlockEntity be : chunk.getBlockEntities().values()) {
            if (be instanceof MobSpawnerBlockEntity) {
                spawners++;
            } else if (be instanceof ChestBlockEntity || be instanceof TrappedChestBlockEntity) {
                BlockState st = be.getCachedState();
                if (st != null && st.contains(ChestBlock.CHEST_TYPE) && st.get(ChestBlock.CHEST_TYPE) == ChestType.RIGHT) {
                    continue; // Count double chests once
                }
                info.raw[Sig.STORAGE.ordinal()] += 1.0;
            } else if (be instanceof BarrelBlockEntity || be instanceof EnderChestBlockEntity) {
                info.raw[Sig.STORAGE.ordinal()] += 1.0;
            } else if (be instanceof ShulkerBoxBlockEntity) {
                info.raw[Sig.STORAGE.ordinal()] += 2.5;
            }
        }
        if (spawners > 0) {
            info.structRaw = true;
            if (info.raw[Sig.STORAGE.ordinal()] <= 2.0) {
                info.raw[Sig.STORAGE.ordinal()] = 0.0; // Natural dungeon chests
            }
        }

        int cobweb = 0, rail = 0, wood = 0, playerMarkers = 0;
        int trialDef = 0, tuffBrick = 0, copper = 0;
        int hitY = Integer.MIN_VALUE;

        ChunkSection[] sections = chunk.getSectionArray();
        int bottomSec = chunk.getBottomSectionCoord();

        for (int si = 0; si < sections.length; si++) {
            ChunkSection sec = sections[si];
            if (sec == null || sec.isEmpty()) continue;

            // Fast palette pre-filter: skip pure stone/deepslate/dirt/water sections immediately
            if (!sec.hasAny(st -> {
                Block b = st.getBlock();
                return BLOCK_SIG.containsKey(b)
                    || BLOCK_MARK.containsKey(b)
                    || b == Blocks.AMETHYST_CLUSTER
                    || b == Blocks.KELP;
            })) {
                continue;
            }

            int baseY = (bottomSec + si) << 4;
            for (int y = 0; y < 16; y++) {
                int wy = baseY + y;
                for (int z = 0; z < 16; z++) {
                    for (int x = 0; x < 16; x++) {
                        BlockState st = sec.getBlockState(x, y, z);
                        if (st.isAir()) continue;
                        Block b = st.getBlock();

                        Integer mark = BLOCK_MARK.get(b);
                        if (mark != null) {
                            switch (mark) {
                                case M_STRUCT    -> info.structRaw = true;
                                case M_WEB       -> cobweb++;
                                case M_RAIL      -> rail++;
                                case M_WOOD      -> wood++;
                                case M_PLAYER    -> playerMarkers++;
                                case M_TRIAL_DEF -> trialDef++;
                                case M_TUFF_BRK  -> tuffBrick++;
                                case M_COPPER    -> copper++;
                            }
                        }

                        if (b == Blocks.AMETHYST_CLUSTER) {
                            info.raw[Sig.GROWTH.ordinal()] += 1.0;
                            continue;
                        }
                        if (b == Blocks.KELP) {
                            if (st.contains(Properties.AGE_25) && st.get(Properties.AGE_25) == 25) {
                                info.raw[Sig.GROWTH.ordinal()] += 0.35;
                            }
                            continue;
                        }

                        Sig s = BLOCK_SIG.get(b);
                        if (s == null || s == Sig.STORAGE) continue;
                        if (s == Sig.LIGHT && wy >= 55) continue;

                        double add = (s == Sig.FARM && wy < 45) ? 2.0 : 1.0;
                        info.raw[s.ordinal()] += add;
                        if (wy > hitY) {
                            hitY = wy;
                        }
                    }
                }
            }
        }

        if (playerMarkers == 0 && (cobweb >= 2 || rail >= 3 || (spawners > 0 && wood >= 8))) {
            info.isMine = true;
            info.structRaw = true;
        }
        if (trialDef >= 1 || (tuffBrick >= 12 && copper >= 6)) {
            info.isTrial = true;
            info.structRaw = true;
        }

        if (playerMarkers == 0 && wood >= 10 && info.raw[Sig.STORAGE.ordinal()] <= 2.0) {
            double otherSignals = 0.0;
            for (Sig s : SIGS) {
                if (s != Sig.PLACED && s != Sig.DECOR && s != Sig.STORAGE && s != Sig.GROWTH) {
                    otherSignals += info.raw[s.ordinal()];
                }
            }
            if (otherSignals == 0.0 && isWaterOrBeachBiome(world, (cx << 4) + 8, (cz << 4) + 8)) {
                info.shipRaw = true;
            }
        }

        // Entity base clues inside this chunk
        Box chunkBox = new Box(cx << 4, world.getBottomY(), cz << 4, (cx << 4) + 16, world.getTopYInclusive(), (cz << 4) + 16);
        int penned = 0;
        for (Entity e : world.getOtherEntities(client.player, chunkBox)) {
            if (e instanceof ItemFrameEntity || e instanceof ArmorStandEntity || e instanceof PaintingEntity) {
                info.raw[Sig.ENTITY.ordinal()] += 1.5;
            } else if ((e instanceof TameableEntity tm && tm.isTamed())
                || (e instanceof AbstractHorseEntity hr && hr.isTame())
                || (e instanceof Leashable ls && ls.isLeashed())) {
                info.raw[Sig.ENTITY.ordinal()] += 2.0;
            } else if (e.hasCustomName()) {
                info.raw[Sig.ENTITY.ordinal()] += 1.5;
            } else if (e instanceof AnimalEntity || e instanceof VillagerEntity) {
                penned++;
            }
        }
        if (penned >= 6) {
            info.raw[Sig.ENTITY.ordinal()] += (penned - 4) * 0.5;
        }

        int surfaceY = chunk.sampleHeightmap(Heightmap.Type.WORLD_SURFACE, 8, 8);
        info.topY = hitY > Integer.MIN_VALUE ? hitY + 1 : surfaceY + 1;

        chunks.put(key, info);
        rateChunk(info);

        if ((info.isMine || info.isTrial) != wasBigStruct) {
            rerateArea(cx, cz);
        }

        double threshold = alertAtPct.getValue() / 100.0;
        if (info.own >= threshold && alertedChunks.add(key)) {
            String topClues = topReasons(info, 2);
            int pct = (int) Math.round(info.own * 100.0);
            String msg = String.format(Locale.ROOT, "%d%% chunk [%d, %d] (%d, %d) - %s",
                pct, cx, cz, (cx << 4) + 8, (cz << 4) + 8, topClues);
            if (chatAlert.getValue()) {
                client.player.sendMessage(
                    Text.literal("[SusChunk] ").formatted(Formatting.GOLD)
                        .append(Text.literal(msg).formatted(Formatting.WHITE)),
                    false
                );
            }
            if (soundAlert.getValue()) {
                client.player.playSound(SoundEvents.BLOCK_NOTE_BLOCK_PLING.value(), 0.8f, 1.2f);
            }
            postDiscordAlert(":triangular_flag_on_post: **Sus chunk " + msg + "**");
        }
    }

    private static boolean isWaterOrBeachBiome(ClientWorld world, int wx, int wz) {
        try {
            RegistryEntry<Biome> biome = world.getBiome(new BlockPos(wx, 62, wz));
            return biome.isIn(BiomeTags.IS_OCEAN) || biome.isIn(BiomeTags.IS_BEACH);
        } catch (Throwable ignored) {
            return false;
        }
    }

    private void rerateArea(int cx, int cz) {
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                ChunkInfo n = chunks.get(ChunkPos.toLong(cx + dx, cz + dz));
                if (n != null) {
                    rateChunk(n);
                }
            }
        }
    }

    private boolean isNearStructure(int cx, int cz, boolean trial) {
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                ChunkInfo n = chunks.get(ChunkPos.toLong(cx + dx, cz + dz));
                if (n != null && (trial ? n.isTrial : n.isMine)) {
                    return true;
                }
            }
        }
        return false;
    }

    private void rateChunk(ChunkInfo info) {
        boolean discountStruct = ignoreStructures.getValue();
        boolean nearMine = discountStruct && (info.isMine || isNearStructure(info.cx, info.cz, false));
        boolean nearTrial = discountStruct && (info.isTrial || isNearStructure(info.cx, info.cz, true));
        boolean ship = info.shipRaw && !findInWater.getValue();
        boolean naturalStruct = discountStruct && (info.structRaw || nearMine || nearTrial);

        double notBase = 1.0;
        for (Sig s : SIGS) {
            if (!sigEnabled.get(s).getValue()) continue;
            double c = info.raw[s.ordinal()];
            if (c <= 0.0) continue;
            double w = sigWeight.get(s).getValue() / 100.0;
            if (w <= 0.0) continue;

            double mult = 1.0;
            if (ship && (s == Sig.PLACED || s == Sig.DECOR || s == Sig.STORAGE)) {
                mult = 0.0;
            } else if (nearTrial && (s == Sig.STORAGE || s == Sig.PLACED || s == Sig.DECOR
                || s == Sig.LIGHT || s == Sig.MACHINE || s == Sig.REDSTONE)) {
                mult = 0.04;
            } else if (nearMine && (s == Sig.PLACED || s == Sig.LIGHT || s == Sig.STORAGE)) {
                mult = 0.05;
            } else if (naturalStruct) {
                mult = s.structDiscount;
            }

            double p = 1.0 - Math.exp(-c / s.scale);
            notBase *= 1.0 - p * s.reliability * Math.min(2.0, w) * mult;
        }
        info.own = MathHelper.clamp(1.0 - notBase, 0.0, 1.0);
    }

    private void recomputeNeighborSpread() {
        for (ChunkInfo info : chunks.values()) {
            double bestNeighbor = 0.0;
            ChunkInfo n1 = chunks.get(ChunkPos.toLong(info.cx + 1, info.cz));
            ChunkInfo n2 = chunks.get(ChunkPos.toLong(info.cx - 1, info.cz));
            ChunkInfo n3 = chunks.get(ChunkPos.toLong(info.cx, info.cz + 1));
            ChunkInfo n4 = chunks.get(ChunkPos.toLong(info.cx, info.cz - 1));
            if (n1 != null && n1.own > bestNeighbor) bestNeighbor = n1.own;
            if (n2 != null && n2.own > bestNeighbor) bestNeighbor = n2.own;
            if (n3 != null && n3.own > bestNeighbor) bestNeighbor = n3.own;
            if (n4 != null && n4.own > bestNeighbor) bestNeighbor = n4.own;
            info.score = combine(info.own, bestNeighbor, 0.35);
        }
    }

    private static double combine(double base, double signal, double weight) {
        return 1.0 - (1.0 - base) * (1.0 - signal * weight);
    }

    private double displayScore(ChunkInfo info, long nowMs) {
        return nowMs < info.liveUntilMs ? combine(info.score, 1.0, LIVE_RELIABILITY) : info.score;
    }

    private void rebuildClusters(MinecraftClient client) {
        if (chunks.isEmpty() || client.player == null) {
            latestClusters = List.of();
            return;
        }
        long now = System.currentTimeMillis();
        double minScore = minPercent.getValue() / 100.0;

        List<ChunkInfo> hits = new ArrayList<>();
        Map<Long, Integer> idxByKey = new HashMap<>();
        for (ChunkInfo info : chunks.values()) {
            if (displayScore(info, now) < minScore) continue;
            idxByKey.put(ChunkPos.toLong(info.cx, info.cz), hits.size());
            hits.add(info);
        }
        int n = hits.size();
        if (n == 0) {
            latestClusters = List.of();
            return;
        }

        int[] parent = new int[n];
        for (int i = 0; i < n; i++) parent[i] = i;

        if (mergeChunks.getValue()) {
            for (int i = 0; i < n; i++) {
                ChunkInfo a = hits.get(i);
                Integer east = idxByKey.get(ChunkPos.toLong(a.cx + 1, a.cz));
                if (east != null) ufUnion(parent, i, east);
                Integer south = idxByKey.get(ChunkPos.toLong(a.cx, a.cz + 1));
                if (south != null) ufUnion(parent, i, south);
            }
        }

        Map<Integer, Cluster> byRoot = new HashMap<>();
        for (int i = 0; i < n; i++) {
            int root = ufFind(parent, i);
            byRoot.computeIfAbsent(root, k -> new Cluster()).members.add(hits.get(i));
        }

        List<Cluster> built = new ArrayList<>(byRoot.values());
        for (Cluster c : built) {
            double sx = 0.0, sz = 0.0, sy = 0.0;
            for (ChunkInfo m : c.members) {
                sx += (m.cx << 4) + 8.0;
                sz += (m.cz << 4) + 8.0;
                sy += m.topY;
                double ds = displayScore(m, now);
                if (c.bestChunk == null || ds > c.bestScore) {
                    c.bestScore = ds;
                    c.bestChunk = m;
                }
                if (now < m.liveUntilMs) {
                    c.anyLive = true;
                    c.liveName = m.liveName;
                }
            }
            int k = c.members.size();
            c.cx = sx / k;
            c.cz = sz / k;
            c.y = sy / k + 0.12;
        }

        sizeClusters(built, client.player.getX(), client.player.getZ());
        latestClusters = built;
    }

    private void sizeClusters(List<Cluster> clusters, double px, double pz) {
        double grow = farGrowPct.getValue() / 100.0;
        int n = clusters.size();
        if (grow <= 0.0 || n == 0) {
            return;
        }
        double[] rad = new double[n];
        for (int i = 0; i < n; i++) {
            Cluster c = clusters.get(i);
            double r = 8.0;
            for (ChunkInfo m : c.members) {
                r = Math.max(r, Math.max(Math.abs((m.cx << 4) + 8.0 - c.cx), Math.abs((m.cz << 4) + 8.0 - c.cz)) + 8.0);
            }
            rad[i] = r;
            double dist = Math.hypot(c.cx - px, c.cz - pz);
            c.scale = 1.0 + grow * MathHelper.clamp((dist - 40.0) / 220.0, 0.0, 1.0);
        }
        // Prevent expanded distant cluster outlines from overlapping nearby clusters
        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                Cluster a = clusters.get(i);
                Cluster b = clusters.get(j);
                double gap = Math.max(Math.abs(a.cx - b.cx), Math.abs(a.cz - b.cz)) - 2.0;
                double need = rad[i] * a.scale + rad[j] * b.scale;
                if (need > gap && need > 0.0) {
                    double k = Math.max(0.0, gap) / need;
                    a.scale = Math.max(1.0, a.scale * k);
                    b.scale = Math.max(1.0, b.scale * k);
                }
            }
        }
    }

    private static int ufFind(int[] p, int x) {
        while (p[x] != x) {
            p[x] = p[p[x]];
            x = p[x];
        }
        return x;
    }

    private static void ufUnion(int[] p, int a, int b) {
        int ra = ufFind(p, a);
        int rb = ufFind(p, b);
        if (ra != rb) {
            p[ra] = rb;
        }
    }

    // ---------------- 3D World Rendering ----------------

    @Override
    public void onRenderWorld(WorldRenderContext context) {
        List<Cluster> clusters = latestClusters;
        if (clusters.isEmpty() || mc == null || mc.player == null) {
            return;
        }

        float t = thickness.getFloatValue();
        boolean glowOn = glow.getValue();

        for (Cluster c : clusters) {
            int col = c.anyLive ? COL_LIVE : heatColor(c.bestScore);
            int lineCol = NexusTheme.withAlpha(col, 225);
            int haloCol = NexusTheme.withAlpha(col, 55);
            drawClusterOutline(c, lineCol, haloCol, t, glowOn);
            WorldRenderHelper.drawGlowDot(c.cx, c.y, c.cz, NexusTheme.withAlpha(col, 240), true);
        }
    }

    private static void drawClusterOutline(Cluster c, int lineCol, int haloCol, float t, boolean glowOn) {
        Map<Integer, List<int[]>> ns = new HashMap<>();
        Map<Integer, List<int[]>> ew = new HashMap<>();
        Set<Long> memberSet = HashSet.newHashSet(c.members.size() * 2);
        for (ChunkInfo m : c.members) {
            memberSet.add(ChunkPos.toLong(m.cx, m.cz));
        }
        for (ChunkInfo m : c.members) {
            int x0 = m.cx << 4;
            int x1 = x0 + 16;
            int z0 = m.cz << 4;
            int z1 = z0 + 16;
            if (!memberSet.contains(ChunkPos.toLong(m.cx, m.cz - 1))) ns.computeIfAbsent(z0, k -> new ArrayList<>()).add(new int[]{x0, x1});
            if (!memberSet.contains(ChunkPos.toLong(m.cx, m.cz + 1))) ns.computeIfAbsent(z1, k -> new ArrayList<>()).add(new int[]{x0, x1});
            if (!memberSet.contains(ChunkPos.toLong(m.cx - 1, m.cz))) ew.computeIfAbsent(x0, k -> new ArrayList<>()).add(new int[]{z0, z1});
            if (!memberSet.contains(ChunkPos.toLong(m.cx + 1, m.cz))) ew.computeIfAbsent(x1, k -> new ArrayList<>()).add(new int[]{z0, z1});
        }
        emitPerimeterRuns(ns, true, c, lineCol, haloCol, t, glowOn);
        emitPerimeterRuns(ew, false, c, lineCol, haloCol, t, glowOn);
    }

    private static void emitPerimeterRuns(Map<Integer, List<int[]>> map, boolean horizontalX, Cluster c, int lineCol, int haloCol, float t, boolean glowOn) {
        double s = c.scale;
        for (Map.Entry<Integer, List<int[]>> e : map.entrySet()) {
            double fixed = e.getKey();
            List<int[]> segs = e.getValue();
            segs.sort(Comparator.comparingInt(a -> a[0]));
            int a = segs.getFirst()[0];
            int b = segs.getFirst()[1];
            for (int i = 1; i <= segs.size(); i++) {
                int[] cur = i < segs.size() ? segs.get(i) : null;
                if (cur != null && cur[0] == b) {
                    b = cur[1];
                    continue;
                }
                double ax = horizontalX ? c.cx + (a - c.cx) * s : c.cx + (fixed - c.cx) * s;
                double az = horizontalX ? c.cz + (fixed - c.cz) * s : c.cz + (a - c.cz) * s;
                double bx = horizontalX ? c.cx + (b - c.cx) * s : ax;
                double bz = horizontalX ? az : c.cz + (b - c.cz) * s;
                if (glowOn) {
                    WorldRenderHelper.drawFlatLine(ax, az, bx, bz, c.y, haloCol, t * 3.0f, true);
                }
                WorldRenderHelper.drawFlatLine(ax, az, bx, bz, c.y, lineCol, t, true);
                if (cur != null) {
                    a = cur[0];
                    b = cur[1];
                }
            }
        }
    }

    // ---------------- 2D HUD Overlay ----------------

    @Override
    public void onRenderHud(DrawContext ctx, RenderTickCounter tickCounter) {
        if (mc == null || mc.player == null || mc.world == null) {
            return;
        }
        TextRenderer tr = mc.textRenderer;
        List<Cluster> clusters = latestClusters;
        double midX = ctx.getScaledWindowWidth() * 0.5;
        double midY = ctx.getScaledWindowHeight() * 0.5;

        // Find cluster closest to crosshair for hover inspection
        Cluster aimedCluster = null;
        double bestCrosshairDist = 26.0;
        Cluster strongestCluster = null;

        if (WorldProjector.isReady()) {
            for (Cluster c : clusters) {
                if (strongestCluster == null || c.bestScore > strongestCluster.bestScore) {
                    strongestCluster = c;
                }
                if (hoverInfo.getValue() && WorldProjector.project(c.cx, c.y, c.cz, projA)) {
                    double d = Math.hypot(projA[0] - midX, projA[1] - midY);
                    if (d < bestCrosshairDist) {
                        bestCrosshairDist = d;
                        aimedCluster = c;
                    }
                }
            }
        }

        updateTooltipAnimation(aimedCluster);

        // 1. Projected Cluster Chips & Expanded Aim Inspector Card
        if (WorldProjector.isReady() && (labels.getValue() || tipOpen > 0.02f)) {
            Cluster deferredHovered = null;
            double hoveredSx = 0.0, hoveredSy = 0.0;

            for (Cluster c : clusters) {
                if (!WorldProjector.project(c.cx, c.y + 0.6, c.cz, projA)) continue;
                boolean isHovered = (c.key() == tipKey && tipOpen > 0.02f);
                if (isHovered) {
                    deferredHovered = c;
                    hoveredSx = projA[0];
                    hoveredSy = projA[1];
                } else if (labels.getValue()) {
                    drawClusterChip(ctx, tr, c, projA[0], projA[1], 0.0f);
                }
            }
            if (deferredHovered != null) {
                drawClusterChip(ctx, tr, deferredHovered, hoveredSx, hoveredSy, tipOpen);
            }
        }

        // 2. Tracer to Best Cluster
        if (tracerToBest.getValue() && strongestCluster != null && WorldProjector.isReady()) {
            if (WorldProjector.projectOrPoint(strongestCluster.cx, strongestCluster.y, strongestCluster.cz, projB)) {
                int col = strongestCluster.anyLive ? COL_LIVE : heatColor(strongestCluster.bestScore);
                NexusTheme.drawLine2D(ctx, midX, midY, projB[0], projB[1], NexusTheme.withAlpha(col, 195));
            }
        }

        // 3. Top-Left Scan Progress Card (stacked cleanly via HudLayoutHelper)
        if (showProgress.getValue()) {
            drawProgressHud(ctx, tr);
        }

        // 4. Right-Side Top-Down Region Minimap
        if (regionMap.getValue()) {
            drawRegionMap(ctx, tr, System.currentTimeMillis());
        }

        // 5. Bottom-Right Corner Indicator Cards (Live Player & Strongest Base)
        if (cornerIndicator.getValue()) {
            drawCornerIndicators(ctx, tr, clusters, strongestCluster);
        }
    }

    private void updateTooltipAnimation(Cluster aimed) {
        long now = System.nanoTime();
        float dt = tipLastNs == 0L ? 0.016f : Math.min(0.1f, (now - tipLastNs) * 1.0e-9f);
        tipLastNs = now;

        long wantKey = aimed != null ? aimed.key() : Long.MIN_VALUE;
        if (wantKey != Long.MIN_VALUE && wantKey != tipKey) {
            tipKey = wantKey;
            tipOpen = 0.0f;
        }
        float target = wantKey != Long.MIN_VALUE ? 1.0f : 0.0f;
        tipOpen += (target - tipOpen) * Math.min(1.0f, dt * 14.0f);
        if (tipOpen < 0.01f && target == 0.0f) {
            tipOpen = 0.0f;
            tipKey = Long.MIN_VALUE;
        }
    }

    private void drawClusterChip(DrawContext ctx, TextRenderer tr, Cluster c, double sx, double sy, float openAmt) {
        int pct = (int) Math.round(c.bestScore * 100.0);
        int dist = (int) Math.round(Math.hypot(mc.player.getX() - c.cx, mc.player.getZ() - c.cz));
        int accent = c.anyLive ? COL_LIVE : heatColor(c.bestScore);

        String head = c.anyLive
            ? ("LIVE " + c.liveName + "  " + dist + "m")
            : (pct + "%" + (c.members.size() > 1 ? " (" + c.members.size() + "ch)" : "") + "  " + dist + "m");

        if (openAmt <= 0.02f) {
            NexusTheme.drawFloatingTag(ctx, tr, head, (int) Math.round(sx), (int) Math.round(sy) - 8, accent, false);
            return;
        }

        // Smooth ease-out inspector card with clue breakdown bars
        float e = 1.0f - (1.0f - openAmt) * (1.0f - openAmt);
        List<ClueRow> rows = collectMergedClues(c);
        int maxTextW = tr.getWidth(head);
        for (ClueRow r : rows) {
            maxTextW = Math.max(maxTextW, tr.getWidth(r.label() + "  x999") + 30);
        }

        int smallW = tr.getWidth(head) + 12;
        int fullW = maxTextW + 14;
        int fullH = 16 + rows.size() * 11 + (c.bestChunk.structRaw ? 11 : 0) + 4;

        int w = Math.round(smallW + (fullW - smallW) * e);
        int h = Math.round(14 + (fullH - 14) * e);
        int x = MathHelper.clamp((int) Math.round(sx) - w / 2, 4, Math.max(4, ctx.getScaledWindowWidth() - w - 4));
        int y = MathHelper.clamp((int) Math.round(sy) - h - 10, 4, Math.max(4, ctx.getScaledWindowHeight() - h - 4));

        // Stem line from dot to inspector card
        NexusTheme.drawLine2D(ctx, sx, sy, x + w * 0.5, y + h, NexusTheme.withAlpha(accent, 175));
        NexusTheme.drawRoundedPanel(ctx, x, y, w, h, NexusTheme.BG_WINDOW, NexusTheme.withAlpha(accent, 225));
        ctx.fill(x + 1, y + 1, x + w - 1, y + 2, NexusTheme.withAlpha(accent, 235));
        ctx.drawTextWithShadow(tr, head, x + 6, y + 4, NexusTheme.TEXT_PRIMARY);

        if (e < 0.45f) {
            return;
        }
        int rowAlpha = MathHelper.clamp((int) ((e - 0.45f) / 0.55f * 255.0f), 0, 255);
        ctx.enableScissor(x + 1, y + 14, x + w - 1, y + h - 1);

        int ry = y + 16;
        for (ClueRow r : rows) {
            int barX = x + 6;
            int barW = 22;
            ctx.fill(barX, ry + 3, barX + barW, ry + 6, NexusTheme.withAlpha(0xFF282834, rowAlpha));
            int fillW = Math.max(1, (int) Math.round(barW * MathHelper.clamp(r.contribution(), 0.0, 1.0)));
            ctx.fill(barX, ry + 3, barX + fillW, ry + 6, NexusTheme.withAlpha(heatColor(r.contribution()), rowAlpha));

            ctx.drawTextWithShadow(tr, r.label(), barX + barW + 5, ry, NexusTheme.withAlpha(NexusTheme.TEXT_SECONDARY, rowAlpha));
            String cnt = "x" + (int) Math.ceil(r.count());
            ctx.drawTextWithShadow(tr, cnt, x + w - 6 - tr.getWidth(cnt), ry, NexusTheme.withAlpha(NexusTheme.GOLD_SOFT, rowAlpha));
            ry += 11;
        }

        if (c.bestChunk.structRaw) {
            String tag = c.bestChunk.isTrial ? "trial chamber discounted"
                : (c.bestChunk.isMine ? "mineshaft discounted" : "natural structure discounted");
            ctx.drawTextWithShadow(tr, tag, x + 6, ry, NexusTheme.withAlpha(NexusTheme.TEXT_MUTED, rowAlpha));
        }
        ctx.disableScissor();
    }

    private List<ClueRow> collectMergedClues(Cluster c) {
        double[] totals = new double[SIGS.length];
        for (ChunkInfo m : c.members) {
            for (int i = 0; i < SIGS.length; i++) {
                totals[i] += m.raw[i];
            }
        }
        List<ClueRow> rows = new ArrayList<>();
        for (Sig s : SIGS) {
            if (!sigEnabled.get(s).getValue()) continue;
            double count = totals[s.ordinal()];
            if (count <= 0.0) continue;
            double w = sigWeight.get(s).getValue() / 100.0;
            double contrib = (1.0 - Math.exp(-count / s.scale)) * s.reliability * Math.min(2.0, w);
            if (contrib > 0.02) {
                rows.add(new ClueRow(s.label, contrib, count));
            }
        }
        rows.sort((a, b) -> Double.compare(b.contribution(), a.contribution()));
        return rows.size() > 5 ? rows.subList(0, 5) : rows;
    }

    private void drawProgressHud(DrawContext ctx, TextRenderer tr) {
        int total = scanBatch.size();
        int done = Math.min(scanCursor, total);
        String tail = lastPassDurationMs < 0 ? "" : String.format(Locale.ROOT, " | %.1fs", lastPassDurationMs / 1000.0);
        String txt = total == 0 ? ("SUS SCAN IDLE" + tail) : ("SUS SCAN " + done + "/" + total + tail);

        int w = Math.max(108, tr.getWidth(txt) + 14);
        int h = 21;
        int x = 8;
        int y = HudLayoutHelper.claimTopLeftY(h, 5);

        NexusTheme.drawRoundedPanel(ctx, x, y, w, h, NexusTheme.BG_HUD, NexusTheme.BORDER_SUBTLE);
        ctx.drawTextWithShadow(tr, txt, x + 7, y + 4, NexusTheme.GOLD_BRIGHT);

        int barX = x + 6;
        int barY = y + 15;
        int barW = w - 12;
        ctx.fill(barX, barY, barX + barW, barY + 3, NexusTheme.BG_INPUT);
        float frac = total == 0 ? 1.0f : (done / (float) total);
        int fillW = (int) Math.round(barW * MathHelper.clamp(frac, 0.0f, 1.0f));
        if (fillW > 0) {
            ctx.fill(barX, barY, barX + fillW, barY + 3, NexusTheme.GOLD_PRIMARY);
        }
    }

    private void drawRegionMap(DrawContext ctx, TextRenderer tr, long nowMs) {
        int sz = mapSize.getIntValue();
        int rad = rangeChunks.getIntValue();
        int cell = Math.max(2, sz / (rad * 2 + 1));
        int boxSize = cell * (rad * 2 + 1) + 6;
        int x0 = ctx.getScaledWindowWidth() - boxSize - 8;
        int y0 = 10;

        NexusTheme.drawRoundedPanel(ctx, x0, y0, boxSize, boxSize, NexusTheme.BG_HUD, NexusTheme.BORDER_GOLD);

        int pcx = mc.player.getChunkPos().x;
        int pcz = mc.player.getChunkPos().z;
        double minScore = minPercent.getValue() / 100.0;

        for (int dx = -rad; dx <= rad; dx++) {
            for (int dz = -rad; dz <= rad; dz++) {
                ChunkInfo info = chunks.get(ChunkPos.toLong(pcx + dx, pcz + dz));
                if (info == null) continue;
                int px = x0 + 3 + (dx + rad) * cell;
                int py = y0 + 3 + (dz + rad) * cell;
                double ds = displayScore(info, nowMs);
                int col = nowMs < info.liveUntilMs
                    ? COL_LIVE
                    : (ds >= minScore ? heatColor(ds) : 0x35FFFFFF);
                ctx.fill(px, py, px + cell - 1, py + cell - 1, col);
            }
        }

        int mid = x0 + 3 + rad * cell + cell / 2;
        int midY = y0 + 3 + rad * cell + cell / 2;
        ctx.fill(mid - 1, midY - 1, mid + 2, midY + 2, 0xFFFFFFFF);
        ctx.drawTextWithShadow(tr, "N", x0 + boxSize / 2 - 2, y0 + 3, NexusTheme.GOLD_SOFT);
    }

    private void drawCornerIndicators(DrawContext ctx, TextRenderer tr, List<Cluster> clusters, Cluster bestBase) {
        Cluster nearestLive = null;
        double bestLiveDist = Double.MAX_VALUE;
        for (Cluster c : clusters) {
            if (!c.anyLive) continue;
            double d = Math.hypot(c.cx - mc.player.getX(), c.cz - mc.player.getZ());
            if (d < bestLiveDist) {
                bestLiveDist = d;
                nearestLive = c;
            }
        }
        if (nearestLive == null && bestBase == null) {
            return;
        }
        if (iconPlayerHead == null) {
            iconPlayerHead = new ItemStack(Items.PLAYER_HEAD);
        }
        if (iconChest == null) {
            iconChest = new ItemStack(Items.CHEST);
        }

        int y = ctx.getScaledWindowHeight() - 30;
        if (bestBase != null && bestBase != nearestLive) {
            int pct = (int) Math.round(bestBase.bestScore * 100.0);
            y = drawSingleCornerCard(ctx, tr, y, iconChest, heatColor(bestBase.bestScore), "BASE " + pct + "%", bestBase);
        }
        if (nearestLive != null) {
            drawSingleCornerCard(ctx, tr, y, iconPlayerHead, COL_LIVE, nearestLive.liveName, nearestLive);
        }
    }

    private int drawSingleCornerCard(DrawContext ctx, TextRenderer tr, int y, ItemStack icon, int accent, String title, Cluster target) {
        double dx = target.cx - mc.player.getX();
        double dz = target.cz - mc.player.getZ();
        int dist = (int) Math.round(Math.hypot(dx, dz));
        String compass = compassArrow(dx, dz, mc.player.getYaw());
        String sub = compass + " " + dist + "m";

        int textW = Math.max(tr.getWidth(title), tr.getWidth(sub));
        int w = 26 + textW + 8;
        int h = 22;
        int x = ctx.getScaledWindowWidth() - w - 8;

        NexusTheme.drawRoundedPanel(ctx, x, y, w, h, NexusTheme.BG_HUD, NexusTheme.withAlpha(accent, 210));
        ctx.fill(x + 2, y + 3, x + 3, y + h - 3, accent);
        ctx.drawItem(icon, x + 6, y + 3);
        ctx.drawTextWithShadow(tr, title, x + 25, y + 3, NexusTheme.TEXT_PRIMARY);
        ctx.drawTextWithShadow(tr, sub, x + 25, y + 12, accent);
        return y - (h + 4);
    }

    private static String compassArrow(double dx, double dz, float playerYaw) {
        double targetDeg = Math.toDegrees(Math.atan2(-dx, dz));
        double rel = MathHelper.wrapDegrees(targetDeg - playerYaw);
        String[] dirs = {"^", "^>", ">", "v>", "v", "<v", "<", "<^"};
        int idx = ((int) Math.round(rel / 45.0) % 8 + 8) % 8;
        return dirs[idx];
    }

    private static int heatColor(double score) {
        if (score < 0.55) {
            return NexusTheme.lerpColor(COL_LOW, COL_MID, (float) ((score - 0.25) / 0.30));
        }
        return NexusTheme.lerpColor(COL_MID, COL_HIGH, (float) ((score - 0.55) / 0.40));
    }

    private String topReasons(ChunkInfo info, int limit) {
        List<Sig> ranked = new ArrayList<>(Arrays.asList(SIGS));
        ranked.removeIf(s -> !sigEnabled.get(s).getValue() || info.raw[s.ordinal()] <= 0.0);
        ranked.sort((a, b) -> Double.compare(
            (1.0 - Math.exp(-info.raw[b.ordinal()] / b.scale)) * b.reliability,
            (1.0 - Math.exp(-info.raw[a.ordinal()] / a.scale)) * a.reliability
        ));
        if (ranked.isEmpty()) return "neighbour activity";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < Math.min(limit, ranked.size()); i++) {
            if (i > 0) sb.append(", ");
            Sig s = ranked.get(i);
            sb.append(s.label.toLowerCase(Locale.ROOT)).append(" x").append((int) Math.ceil(info.raw[s.ordinal()]));
        }
        return sb.toString();
    }

    // ---------------- Optional Async Discord Webhook ----------------

    private void sendDiscordTest() {
        String url = discordWebhookUrl.getValue().trim();
        if (!isValidDiscordWebhook(url)) {
            if (mc != null && mc.player != null) {
                mc.player.sendMessage(
                    Text.literal("[SusChunk] ").formatted(Formatting.GOLD)
                        .append(Text.literal("Paste a valid https://discord.com/api/webhooks/... URL first.").formatted(Formatting.RED)),
                    false
                );
            }
            return;
        }
        sendWebhookAsync(url, ":white_check_mark: **NEXUS SusChunkFinder** webhook test connected!", true);
    }

    private void postDiscordAlert(String content) {
        if (!discordAlert.getValue()) return;
        String url = discordWebhookUrl.getValue().trim();
        if (!isValidDiscordWebhook(url)) return;
        String serverTag = "singleplayer";
        if (mc != null && mc.getCurrentServerEntry() != null) {
            serverTag = mc.getCurrentServerEntry().address;
        }
        sendWebhookAsync(url, content + "  `(" + serverTag + ")`", false);
    }

    private static boolean isValidDiscordWebhook(String url) {
        return url.startsWith("https://discord.com/api/webhooks/")
            || url.startsWith("https://discordapp.com/api/webhooks/")
            || url.startsWith("https://ptb.discord.com/api/webhooks/")
            || url.startsWith("https://canary.discord.com/api/webhooks/");
    }

    private void sendWebhookAsync(String url, String msg, boolean reportFeedback) {
        try {
            if (httpClient == null) {
                httpClient = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(8)).build();
            }
            String escaped = msg.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n");
            String payload = "{\"content\":\"" + escaped + "\"}";
            HttpRequest req = HttpRequest.newBuilder(URI.create(url))
                .timeout(Duration.ofSeconds(10))
                .header("Content-Type", "application/json")
                .header("User-Agent", "NexusClient-SusChunkFinder/1.0")
                .POST(HttpRequest.BodyPublishers.ofString(payload))
                .build();
            httpClient.sendAsync(req, HttpResponse.BodyHandlers.discarding())
                .whenComplete((resp, err) -> {
                    if (!reportFeedback || mc == null) return;
                    boolean ok = (err == null && resp != null && resp.statusCode() / 100 == 2);
                    String status = ok
                        ? "Discord test sent!"
                        : ("Webhook failed: " + (err != null ? err.getClass().getSimpleName() : "HTTP " + resp.statusCode()));
                    mc.execute(() -> {
                        if (mc.player != null) {
                            mc.player.sendMessage(
                                Text.literal("[SusChunk] ").formatted(Formatting.GOLD)
                                    .append(Text.literal(status).formatted(ok ? Formatting.GREEN : Formatting.RED)),
                                false
                            );
                        }
                    });
                });
        } catch (Throwable ignored) {
        }
    }

    // ---------------- Lazy Block Lookup Table Initialization ----------------

    private static void ensureTables() {
        if (tablesReady) {
            return;
        }
        synchronized (SusChunkFinderModule.class) {
            if (tablesReady) {
                return;
            }
            putSig(Sig.MACHINE,
                "hopper", "dropper", "dispenser", "observer", "piston", "sticky_piston",
                "repeater", "comparator", "tnt", "daylight_detector", "beacon",
                "enchanting_table", "redstone_lamp", "note_block", "jukebox", "crafter");

            putSig(Sig.REDSTONE,
                "redstone_wire", "lever", "tripwire_hook", "target", "slime_block",
                "honey_block", "lightning_rod", "sculk_sensor", "calibrated_sculk_sensor",
                "redstone_torch", "redstone_wall_torch");

            putSig(Sig.STORAGE, "chest", "trapped_chest", "barrel", "ender_chest");

            putSig(Sig.FARM,
                "farmland", "wheat", "carrots", "potatoes", "beetroots",
                "nether_wart", "composter");

            putSig(Sig.PLACED,
                "crafting_table", "furnace", "blast_furnace", "smoker", "smithing_table",
                "fletching_table", "cartography_table", "loom", "stonecutter",
                "anvil", "chipped_anvil", "damaged_anvil", "ladder", "scaffolding",
                "glass", "glass_pane", "tinted_glass", "obsidian",
                "iron_block", "gold_block", "diamond_block", "emerald_block",
                "netherite_block", "lapis_block", "redstone_block");

            putSig(Sig.LIGHT,
                "torch", "wall_torch", "soul_torch", "soul_wall_torch",
                "lantern", "soul_lantern", "glowstone", "shroomlight", "end_rod",
                "campfire", "soul_campfire");

            putSig(Sig.PORTAL, "nether_portal");

            putSig(Sig.DECOR,
                "flower_pot", "bookshelf", "chiseled_bookshelf", "lectern", "brewing_stand",
                "cauldron", "water_cauldron", "lava_cauldron", "powder_snow_cauldron",
                "grindstone", "lodestone", "respawn_anchor", "conduit",
                "bricks", "brick_slab", "brick_stairs", "brick_wall",
                "smooth_stone", "smooth_stone_slab",
                "quartz_block", "quartz_bricks", "quartz_pillar", "chiseled_quartz_block",
                "smooth_quartz", "quartz_stairs", "quartz_slab",
                "polished_granite", "polished_diorite", "polished_andesite",
                "decorated_pot", "beehive", "jack_o_lantern", "carved_pumpkin",
                "cake", "end_crystal");

            putMark(M_STRUCT,
                "end_portal_frame", "bell", "reinforced_deepslate", "sculk_shrieker",
                "nether_brick_fence", "gilded_blackstone", "purpur_block",
                "prismarine_bricks", "chiseled_sandstone", "crying_obsidian");
            putMark(M_WEB, "cobweb");
            putMark(M_RAIL, "rail", "powered_rail", "detector_rail", "activator_rail");
            putMark(M_TRIAL_DEF, "trial_spawner", "vault", "heavy_core");
            putMark(M_PLAYER,
                "hopper", "observer", "piston", "sticky_piston", "repeater", "comparator",
                "beacon", "enchanting_table", "ender_chest", "furnace", "blast_furnace",
                "smoker", "anvil", "chipped_anvil", "damaged_anvil", "nether_portal",
                "farmland", "brewing_stand", "lectern", "respawn_anchor", "conduit",
                "crafter", "lodestone");

            for (Block b : Registries.BLOCK) {
                String path = Registries.BLOCK.getId(b).getPath();

                if (path.contains("tuff_brick") || path.equals("chiseled_tuff") || path.equals("polished_tuff")) {
                    BLOCK_MARK.put(b, M_TUFF_BRK);
                } else if (path.contains("copper_bulb") || path.contains("copper_grate") || path.contains("chiseled_copper")
                    || (path.contains("copper") && (b instanceof DoorBlock || b instanceof TrapdoorBlock))) {
                    BLOCK_MARK.put(b, M_COPPER);
                }

                if (b instanceof ShulkerBoxBlock) {
                    BLOCK_SIG.put(b, Sig.STORAGE);
                    BLOCK_MARK.put(b, M_PLAYER);
                    continue;
                }
                if (b instanceof BedBlock) {
                    BLOCK_SIG.put(b, Sig.PLACED);
                    BLOCK_MARK.put(b, M_PLAYER);
                    continue;
                }
                if (b instanceof AbstractSignBlock) {
                    BLOCK_SIG.put(b, Sig.PLACED);
                    BLOCK_MARK.put(b, M_PLAYER);
                    continue;
                }
                if (b instanceof StainedGlassBlock || b instanceof StainedGlassPaneBlock
                    || b instanceof GlazedTerracottaBlock
                    || path.endsWith("_wool") || path.endsWith("_concrete") || path.endsWith("_concrete_powder")) {
                    BLOCK_SIG.put(b, Sig.PLACED);
                    BLOCK_MARK.put(b, M_PLAYER);
                    continue;
                }

                if (BLOCK_SIG.containsKey(b)) continue;

                if (path.endsWith("_planks")) {
                    BLOCK_SIG.put(b, Sig.PLACED);
                    BLOCK_MARK.putIfAbsent(b, M_WOOD);
                } else if (path.startsWith("stripped_") && (path.endsWith("_log") || path.endsWith("_wood")
                    || path.endsWith("_stem") || path.endsWith("_hyphae"))) {
                    BLOCK_SIG.put(b, Sig.DECOR);
                } else if (b instanceof DoorBlock || b instanceof TrapdoorBlock || b instanceof FenceGateBlock) {
                    BLOCK_SIG.put(b, Sig.PLACED);
                    BLOCK_MARK.putIfAbsent(b, M_WOOD);
                } else if (b instanceof FenceBlock && b != Blocks.NETHER_BRICK_FENCE) {
                    BLOCK_SIG.put(b, Sig.PLACED);
                    BLOCK_MARK.putIfAbsent(b, M_WOOD);
                } else if (b instanceof AbstractBannerBlock) {
                    BLOCK_SIG.put(b, Sig.PLACED);
                } else if (b instanceof ButtonBlock || b instanceof AbstractPressurePlateBlock) {
                    BLOCK_SIG.put(b, Sig.REDSTONE);
                } else if (b instanceof CandleBlock || b instanceof AbstractSkullBlock || path.startsWith("potted_")) {
                    BLOCK_SIG.put(b, Sig.DECOR);
                } else if (b instanceof CarpetBlock && b != Blocks.MOSS_CARPET && b != Blocks.PALE_MOSS_CARPET) {
                    BLOCK_SIG.put(b, Sig.DECOR);
                }
            }
            tablesReady = true;
        }
    }

    private static void putSig(Sig sig, String... names) {
        for (String n : names) {
            Block b = Registries.BLOCK.get(Identifier.ofVanilla(n));
            if (b != Blocks.AIR) {
                BLOCK_SIG.put(b, sig);
            }
        }
    }

    private static void putMark(int mark, String... names) {
        for (String n : names) {
            Block b = Registries.BLOCK.get(Identifier.ofVanilla(n));
            if (b != Blocks.AIR) {
                BLOCK_MARK.put(b, mark);
            }
        }
    }
}
