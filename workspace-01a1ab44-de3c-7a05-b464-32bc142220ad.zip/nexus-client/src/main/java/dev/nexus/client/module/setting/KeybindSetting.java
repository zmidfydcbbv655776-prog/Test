package dev.nexus.client.module.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import dev.nexus.client.util.KeyUtil;

public final class KeybindSetting extends Setting<Integer> {
    public KeybindSetting(String key, String name, String description, int defaultKey) {
        super(key, name, description, defaultKey);
    }

    public boolean isBound() {
        return KeyUtil.isBound(getValue());
    }

    public String getDisplayText() {
        return KeyUtil.getKeyName(getValue());
    }

    public void unbind() {
        setValue(KeyUtil.UNBOUND);
    }

    @Override
    protected Integer validate(Integer candidate) {
        if (candidate == null) {
            return getDefaultValue();
        }
        // Valid codes: UNBOUND (-1), encoded mouse buttons (-108..-100), or GLFW keys (32..348)
        if (candidate == KeyUtil.UNBOUND) {
            return KeyUtil.UNBOUND;
        }
        if (candidate <= -100 && candidate >= -116) {
            return candidate;
        }
        if (candidate >= 32 && candidate <= 400) {
            return candidate;
        }
        return KeyUtil.UNBOUND;
    }

    @Override
    public JsonElement toJson() {
        return new JsonPrimitive(getValue());
    }

    @Override
    public void fromJson(JsonElement element) {
        if (element != null && element.isJsonPrimitive() && element.getAsJsonPrimitive().isNumber()) {
            setValue(element.getAsInt());
        } else {
            reset();
        }
    }
}
