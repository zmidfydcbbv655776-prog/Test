package dev.nexus.client.event;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientChunkManager;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.chunk.ChunkStatus;
import net.minecraft.world.chunk.WorldChunk;

/**
 * Tracks strictly client-loaded chunks and provides helpers to verify live chunk residency.
 * Never retains chunk references across unload or world transitions.
 */
public final class WorldChunkTracker {
    private static final Set<Long> LOADED_CHUNK_KEYS = ConcurrentHashMap.newKeySet();

    private WorldChunkTracker() {
    }

    public static void onChunkLoad(ClientWorld world, WorldChunk chunk) {
        if (world != null && chunk != null && !chunk.isEmpty()) {
            LOADED_CHUNK_KEYS.add(chunk.getPos().toLong());
        }
    }

    public static void onChunkUnload(ClientWorld world, WorldChunk chunk) {
        if (chunk != null) {
            LOADED_CHUNK_KEYS.remove(chunk.getPos().toLong());
        }
    }

    public static void clear() {
        LOADED_CHUNK_KEYS.clear();
    }

    public static boolean isChunkCurrentlyLoaded(ClientWorld world, int chunkX, int chunkZ) {
        if (world == null) {
            return false;
        }
        ClientChunkManager manager = world.getChunkManager();
        if (!manager.isChunkLoaded(chunkX, chunkZ)) {
            LOADED_CHUNK_KEYS.remove(ChunkPos.toLong(chunkX, chunkZ));
            return false;
        }
        WorldChunk chunk = manager.getChunk(chunkX, chunkZ, ChunkStatus.FULL, false);
        if (chunk == null || chunk.isEmpty()) {
            LOADED_CHUNK_KEYS.remove(ChunkPos.toLong(chunkX, chunkZ));
            return false;
        }
        LOADED_CHUNK_KEYS.add(ChunkPos.toLong(chunkX, chunkZ));
        return true;
    }

    public static WorldChunk getLoadedChunk(ClientWorld world, int chunkX, int chunkZ) {
        if (world == null) {
            return null;
        }
        ClientChunkManager manager = world.getChunkManager();
        if (!manager.isChunkLoaded(chunkX, chunkZ)) {
            LOADED_CHUNK_KEYS.remove(ChunkPos.toLong(chunkX, chunkZ));
            return null;
        }
        WorldChunk chunk = manager.getChunk(chunkX, chunkZ, ChunkStatus.FULL, false);
        if (chunk == null || chunk.isEmpty()) {
            LOADED_CHUNK_KEYS.remove(ChunkPos.toLong(chunkX, chunkZ));
            return null;
        }
        LOADED_CHUNK_KEYS.add(ChunkPos.toLong(chunkX, chunkZ));
        return chunk;
    }

    /**
     * Collects currently loaded chunks within maxRadius around the player's chunk,
     * sorted from nearest ring outward so nearby chunks are prioritized.
     */
    public static List<WorldChunk> getLoadedChunksAroundPlayer(MinecraftClient client, int maxRadius) {
        List<WorldChunk> result = new ArrayList<>();
        if (client == null || client.world == null || client.player == null) {
            return result;
        }
        ClientWorld world = client.world;
        int viewDist = Math.min(maxRadius, client.options.getClampedViewDistance());
        ChunkPos center = client.player.getChunkPos();

        for (int r = 0; r <= viewDist; r++) {
            for (int dx = -r; dx <= r; dx++) {
                for (int dz = -r; dz <= r; dz++) {
                    if (Math.max(Math.abs(dx), Math.abs(dz)) != r) {
                        continue;
                    }
                    WorldChunk chunk = getLoadedChunk(world, center.x + dx, center.z + dz);
                    if (chunk != null) {
                        result.add(chunk);
                    }
                }
            }
        }
        return result;
    }
}
