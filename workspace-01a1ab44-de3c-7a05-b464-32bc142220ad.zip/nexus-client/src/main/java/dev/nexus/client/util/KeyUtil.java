package dev.nexus.client.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.util.Window;
import org.lwjgl.glfw.GLFW;

public final class KeyUtil {
    public static final int UNBOUND = GLFW.GLFW_KEY_UNKNOWN;
    private static final int MOUSE_OFFSET = -100;

    private KeyUtil() {
    }

    public static int encodeMouseButton(int button) {
        return MOUSE_OFFSET - button;
    }

    public static boolean isMouseCode(int code) {
        return code <= MOUSE_OFFSET;
    }

    public static int decodeMouseButton(int code) {
        return MOUSE_OFFSET - code;
    }

    public static boolean isBound(int code) {
        return code != UNBOUND;
    }

    public static boolean isPressed(MinecraftClient client, int code) {
        if (code == UNBOUND || client == null) {
            return false;
        }
        Window window = client.getWindow();
        if (window == null || window.getHandle() == 0L) {
            return false;
        }
        try {
            if (isMouseCode(code)) {
                int button = decodeMouseButton(code);
                if (button < 0 || button > GLFW.GLFW_MOUSE_BUTTON_LAST) {
                    return false;
                }
                return GLFW.glfwGetMouseButton(window.getHandle(), button) == GLFW.GLFW_PRESS;
            }
            if (code < 32) {
                return false;
            }
            return InputUtil.isKeyPressed(window, code);
        } catch (Throwable ignored) {
            // Protect against incomplete GLFW bridge implementations on mobile launchers
            return false;
        }
    }

    public static String getKeyName(int code) {
        if (code == UNBOUND) {
            return "NONE";
        }
        if (isMouseCode(code)) {
            int btn = decodeMouseButton(code);
            return switch (btn) {
                case GLFW.GLFW_MOUSE_BUTTON_LEFT -> "M1";
                case GLFW.GLFW_MOUSE_BUTTON_RIGHT -> "M2";
                case GLFW.GLFW_MOUSE_BUTTON_MIDDLE -> "M3";
                default -> "M" + (btn + 1);
            };
        }
        return switch (code) {
            case GLFW.GLFW_KEY_RIGHT_SHIFT -> "RSHIFT";
            case GLFW.GLFW_KEY_LEFT_SHIFT -> "LSHIFT";
            case GLFW.GLFW_KEY_RIGHT_CONTROL -> "RCTRL";
            case GLFW.GLFW_KEY_LEFT_CONTROL -> "LCTRL";
            case GLFW.GLFW_KEY_RIGHT_ALT -> "RALT";
            case GLFW.GLFW_KEY_LEFT_ALT -> "LALT";
            case GLFW.GLFW_KEY_SPACE -> "SPACE";
            case GLFW.GLFW_KEY_TAB -> "TAB";
            case GLFW.GLFW_KEY_ENTER -> "ENTER";
            case GLFW.GLFW_KEY_CAPS_LOCK -> "CAPS";
            case GLFW.GLFW_KEY_UP -> "UP";
            case GLFW.GLFW_KEY_DOWN -> "DOWN";
            case GLFW.GLFW_KEY_LEFT -> "LEFT";
            case GLFW.GLFW_KEY_RIGHT -> "RIGHT";
            case GLFW.GLFW_KEY_INSERT -> "INS";
            case GLFW.GLFW_KEY_DELETE -> "DEL";
            case GLFW.GLFW_KEY_HOME -> "HOME";
            case GLFW.GLFW_KEY_END -> "END";
            case GLFW.GLFW_KEY_PAGE_UP -> "PGUP";
            case GLFW.GLFW_KEY_PAGE_DOWN -> "PGDN";
            default -> {
                if (code >= GLFW.GLFW_KEY_F1 && code <= GLFW.GLFW_KEY_F12) {
                    yield "F" + (code - GLFW.GLFW_KEY_F1 + 1);
                }
                try {
                    InputUtil.Key key = InputUtil.Type.KEYSYM.createFromCode(code);
                    String localized = key.getLocalizedText().getString();
                    if (localized != null && !localized.isBlank()) {
                        yield localized.toUpperCase();
                    }
                } catch (Throwable ignored) {
                }
                yield "KEY_" + code;
            }
        };
    }
}
