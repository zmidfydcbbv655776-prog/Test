package dev.nexus.client.module.impl.render;

import dev.nexus.client.event.WorldChunkTracker;
import dev.nexus.client.module.Category;
import dev.nexus.client.module.Module;
import dev.nexus.client.module.setting.BooleanSetting;
import dev.nexus.client.module.setting.ModeSetting;
import dev.nexus.client.module.setting.NumberSetting;
import dev.nexus.client.render.NexusTheme;
import dev.nexus.client.render.WorldProjector;
import dev.nexus.client.render.WorldRenderHelper;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.block.BlockState;
import net.minecraft.block.ChestBlock;
import net.minecraft.block.entity.BarrelBlockEntity;
import net.minecraft.block.entity.BlastFurnaceBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.EnderChestBlockEntity;
import net.minecraft.block.entity.FurnaceBlockEntity;
import net.minecraft.block.entity.HopperBlockEntity;
import net.minecraft.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.block.entity.SmokerBlockEntity;
import net.minecraft.block.entity.TrappedChestBlockEntity;
import net.minecraft.block.enums.ChestType;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.WorldChunk;

/**
 * Module C: Storage ESP
 * Highlights supported container BlockEntities strictly within currently loaded chunks.
 * Merges double chests cleanly into one unified 2-block box and purges unloaded chunks immediately.
 */
public final class StorageEspModule extends Module {
    public enum ContainerKind {
        CHEST(0xFFE6B83A),
        TRAPPED_CHEST(0xFFE74C3C),
        ENDER_CHEST(0xFF9B59B6),
        BARREL(0xFFC88A4B),
        SHULKER_BOX(0xFFC056F5),
        FURNACE(0xFF95A5A6),
        BLAST_FURNACE(0xFF5DADE2),
        SMOKER(0xFFA3B18A),
        HOPPER(0xFFBFC9CA);

        public final int defaultColor;

        ContainerKind(int defaultColor) {
            this.defaultColor = defaultColor;
        }
    }

    private record ContainerEntry(Box box, Vec3d center, ContainerKind kind) {
    }

    private final ModeSetting renderStyle = addSetting(
        new ModeSetting("style", "Render Style", "How container boxes are drawn", "Box + Fill", "Box + Fill", "Outline Only", "Filled Only")
    );
    private final ModeSetting colorMode = addSetting(
        new ModeSetting("color_mode", "Color Palette", "Color-coded per container type or unified Nexus Gold", "Type Colors", "Type Colors", "Nexus Gold")
    );
    private final NumberSetting maxDistance = addSetting(
        new NumberSetting("max_distance", "Max Distance", "Maximum display distance in blocks", 128, 16, 256, 8)
    );
    private final NumberSetting lineWidth = addSetting(
        new NumberSetting("line_width", "Line Width", "Outline stroke thickness", 1.8, 1.0, 4.5, 0.2)
    );
    private final BooleanSetting glow = addSetting(
        new BooleanSetting("glow", "Outline Glow", "Soft glow halo around container outlines", true)
    );
    private final NumberSetting fillOpacity = addSetting(
        new NumberSetting("fill_alpha", "Fill Opacity", "Box fill transparency (10-160)", 45, 10, 160, 5)
    );
    private final BooleanSetting tracers = addSetting(
        new BooleanSetting("tracers", "Tracers", "Draw HUD tracer lines to visible containers", false)
    );

    // Individual container toggles
    private final BooleanSetting showChests = addSetting(new BooleanSetting("chests", "Chests", "Highlight normal Chests", true));
    private final BooleanSetting showTrappedChests = addSetting(new BooleanSetting("trapped_chests", "Trapped Chests", "Highlight Trapped Chests", true));
    private final BooleanSetting showEnderChests = addSetting(new BooleanSetting("ender_chests", "Ender Chests", "Highlight Ender Chests", true));
    private final BooleanSetting showBarrels = addSetting(new BooleanSetting("barrels", "Barrels", "Highlight Barrels", true));
    private final BooleanSetting showShulkers = addSetting(new BooleanSetting("shulkers", "Shulker Boxes", "Highlight Shulker Boxes", true));
    private final BooleanSetting showFurnaces = addSetting(new BooleanSetting("furnaces", "Furnaces", "Highlight Furnaces", true));
    private final BooleanSetting showBlastFurnaces = addSetting(new BooleanSetting("blast_furnaces", "Blast Furnaces", "Highlight Blast Furnaces", true));
    private final BooleanSetting showSmokers = addSetting(new BooleanSetting("smokers", "Smokers", "Highlight Smokers", true));
    private final BooleanSetting showHoppers = addSetting(new BooleanSetting("hoppers", "Hoppers", "Highlight Hoppers", true));

    private final Map<Long, List<ContainerEntry>> chunkContainers = new ConcurrentHashMap<>();
    private volatile List<ContainerEntry> lastVisibleSnapshot = List.of();
    private ClientWorld lastWorld = null;
    private int refreshTimer = 0;
    private final double[] projTmp = new double[2];

    public StorageEspModule() {
        super("storage_esp", "Storage ESP", "Highlights loaded container blocks with color-coded categories.", Category.RENDER);
    }

    @Override
    protected void onEnable() {
        chunkContainers.clear();
        lastVisibleSnapshot = List.of();
        lastWorld = mc != null ? mc.world : null;
        refreshTimer = 0;
        syncAllLoadedChunks();
    }

    @Override
    protected void onDisable() {
        chunkContainers.clear();
        lastVisibleSnapshot = List.of();
        lastWorld = null;
    }

    @Override
    public void onWorldCleanup() {
        chunkContainers.clear();
        lastVisibleSnapshot = List.of();
        lastWorld = null;
        refreshTimer = 0;
    }

    @Override
    public void onChunkLoad(ClientWorld world, WorldChunk chunk) {
        if (chunk != null) {
            extractChunkContainers(chunk);
        }
    }

    @Override
    public void onChunkUnload(ClientWorld world, WorldChunk chunk) {
        if (chunk != null) {
            chunkContainers.remove(chunk.getPos().toLong());
        }
    }

    @Override
    public void onTick(MinecraftClient client) {
        if (client.world == null || client.player == null) {
            onWorldCleanup();
            return;
        }
        if (client.world != lastWorld) {
            chunkContainers.clear();
            lastVisibleSnapshot = List.of();
            lastWorld = client.world;
            refreshTimer = 10;
        }

        chunkContainers.keySet().removeIf(chunkKey -> {
            int cx = ChunkPos.getPackedX(chunkKey);
            int cz = ChunkPos.getPackedZ(chunkKey);
            return !WorldChunkTracker.isChunkCurrentlyLoaded(client.world, cx, cz);
        });

        refreshTimer++;
        if (refreshTimer >= 10) {
            refreshTimer = 0;
            syncAllLoadedChunks();
        }
    }

    private void syncAllLoadedChunks() {
        if (mc == null || mc.world == null || mc.player == null) {
            return;
        }
        int chunkRadius = Math.max(2, (int) Math.ceil(maxDistance.getValue() / 16.0));
        List<WorldChunk> loaded = WorldChunkTracker.getLoadedChunksAroundPlayer(mc, chunkRadius);
        for (WorldChunk chunk : loaded) {
            extractChunkContainers(chunk);
        }
    }

    private void extractChunkContainers(WorldChunk chunk) {
        long key = chunk.getPos().toLong();
        Map<BlockPos, BlockEntity> blockEntities = chunk.getBlockEntities();
        if (blockEntities.isEmpty()) {
            chunkContainers.remove(key);
            return;
        }
        List<ContainerEntry> found = null;
        for (Map.Entry<BlockPos, BlockEntity> entry : blockEntities.entrySet()) {
            BlockEntity be = entry.getValue();
            ContainerKind kind = classify(be);
            if (kind == null) {
                continue;
            }
            BlockPos pos = entry.getKey();
            Box box;

            // Merge double chests into one clean 2-block container box
            if (be instanceof ChestBlockEntity) {
                BlockState state = be.getCachedState();
                if (state != null && state.contains(ChestBlock.CHEST_TYPE)) {
                    ChestType type = state.get(ChestBlock.CHEST_TYPE);
                    if (type == ChestType.RIGHT) {
                        continue; // Rendered once from the LEFT half
                    }
                    if (type == ChestType.LEFT) {
                        Direction otherDir = ChestBlock.getFacing(state);
                        BlockPos otherPos = pos.offset(otherDir);
                        double minX = Math.min(pos.getX(), otherPos.getX()) + 0.02;
                        double minY = pos.getY() + 0.015;
                        double minZ = Math.min(pos.getZ(), otherPos.getZ()) + 0.02;
                        double maxX = Math.max(pos.getX(), otherPos.getX()) + 0.98;
                        double maxY = pos.getY() + 0.94;
                        double maxZ = Math.max(pos.getZ(), otherPos.getZ()) + 0.98;
                        box = new Box(minX, minY, minZ, maxX, maxY, maxZ);
                    } else {
                        box = new Box(
                            pos.getX() + 0.04, pos.getY() + 0.015, pos.getZ() + 0.04,
                            pos.getX() + 0.96, pos.getY() + 0.94, pos.getZ() + 0.96
                        );
                    }
                } else {
                    box = singleBlockBox(pos);
                }
            } else if (be instanceof EnderChestBlockEntity) {
                box = new Box(
                    pos.getX() + 0.04, pos.getY() + 0.015, pos.getZ() + 0.04,
                    pos.getX() + 0.96, pos.getY() + 0.94, pos.getZ() + 0.96
                );
            } else {
                box = singleBlockBox(pos);
            }

            if (found == null) {
                found = new ArrayList<>(4);
            }
            found.add(new ContainerEntry(box, box.getCenter(), kind));
        }

        if (found == null || found.isEmpty()) {
            chunkContainers.remove(key);
        } else {
            chunkContainers.put(key, found);
        }
    }

    private static Box singleBlockBox(BlockPos pos) {
        return new Box(
            pos.getX() + 0.015, pos.getY() + 0.015, pos.getZ() + 0.015,
            pos.getX() + 0.985, pos.getY() + 0.985, pos.getZ() + 0.985
        );
    }

    private static ContainerKind classify(BlockEntity be) {
        if (be instanceof TrappedChestBlockEntity) return ContainerKind.TRAPPED_CHEST;
        if (be instanceof ChestBlockEntity) return ContainerKind.CHEST;
        if (be instanceof EnderChestBlockEntity) return ContainerKind.ENDER_CHEST;
        if (be instanceof BarrelBlockEntity) return ContainerKind.BARREL;
        if (be instanceof ShulkerBoxBlockEntity) return ContainerKind.SHULKER_BOX;
        if (be instanceof BlastFurnaceBlockEntity) return ContainerKind.BLAST_FURNACE;
        if (be instanceof SmokerBlockEntity) return ContainerKind.SMOKER;
        if (be instanceof FurnaceBlockEntity) return ContainerKind.FURNACE;
        if (be instanceof HopperBlockEntity) return ContainerKind.HOPPER;
        return null;
    }

    private boolean isKindEnabled(ContainerKind kind) {
        return switch (kind) {
            case CHEST -> showChests.getValue();
            case TRAPPED_CHEST -> showTrappedChests.getValue();
            case ENDER_CHEST -> showEnderChests.getValue();
            case BARREL -> showBarrels.getValue();
            case SHULKER_BOX -> showShulkers.getValue();
            case FURNACE -> showFurnaces.getValue();
            case BLAST_FURNACE -> showBlastFurnaces.getValue();
            case SMOKER -> showSmokers.getValue();
            case HOPPER -> showHoppers.getValue();
        };
    }

    @Override
    public void onRenderWorld(WorldRenderContext context) {
        if (mc == null || mc.world == null || chunkContainers.isEmpty()) {
            lastVisibleSnapshot = List.of();
            return;
        }
        ClientWorld world = mc.world;
        Vec3d camPos = WorldProjector.camPos;
        double maxDist = maxDistance.getValue();
        double maxDistSq = maxDist * maxDist;

        List<ContainerEntry> visible = new ArrayList<>();
        for (Map.Entry<Long, List<ContainerEntry>> entry : chunkContainers.entrySet()) {
            long key = entry.getKey();
            int cx = ChunkPos.getPackedX(key);
            int cz = ChunkPos.getPackedZ(key);
            if (!WorldChunkTracker.isChunkCurrentlyLoaded(world, cx, cz)) {
                continue;
            }
            for (ContainerEntry container : entry.getValue()) {
                if (!isKindEnabled(container.kind())) {
                    continue;
                }
                if (camPos.squaredDistanceTo(container.center()) <= maxDistSq) {
                    visible.add(container);
                }
            }
        }

        if (visible.isEmpty()) {
            lastVisibleSnapshot = List.of();
            return;
        }

        // Cap rendered boxes on heavy storage bases to preserve mobile/PojavLauncher FPS
        final int maxRenderCount = 260;
        if (visible.size() > maxRenderCount) {
            visible.sort(Comparator.comparingDouble(c -> camPos.squaredDistanceTo(c.center())));
            visible = new ArrayList<>(visible.subList(0, maxRenderCount));
        }
        lastVisibleSnapshot = visible;

        boolean goldOnly = colorMode.isMode("Nexus Gold");
        boolean drawOutline = !renderStyle.isMode("Filled Only");
        boolean drawFill = !renderStyle.isMode("Outline Only");
        boolean glowOn = glow.getValue();
        float strokeW = lineWidth.getFloatValue();
        int fillAlpha = fillOpacity.getIntValue();

        for (ContainerEntry c : visible) {
            int baseRgb = goldOnly ? NexusTheme.GOLD_BRIGHT : c.kind().defaultColor;
            int strokeArgb = drawOutline ? NexusTheme.withAlpha(baseRgb, 235) : 0;
            int fillArgb = drawFill ? NexusTheme.withAlpha(baseRgb, fillAlpha) : 0;
            WorldRenderHelper.drawBoxGlow(c.box(), strokeArgb, strokeW, fillArgb, glowOn, true);
        }
    }

    @Override
    public void onRenderHud(DrawContext drawContext, RenderTickCounter tickCounter) {
        if (!tracers.getValue() || !WorldProjector.isReady()) {
            return;
        }
        List<ContainerEntry> visible = lastVisibleSnapshot;
        if (visible.isEmpty()) {
            return;
        }
        boolean goldOnly = colorMode.isMode("Nexus Gold");
        double cx = drawContext.getScaledWindowWidth() * 0.5;
        double cy = drawContext.getScaledWindowHeight() * 0.5;

        int cap = Math.min(80, visible.size());
        for (int i = 0; i < cap; i++) {
            ContainerEntry c = visible.get(i);
            Vec3d ctr = c.center();
            if (WorldProjector.projectOrPoint(ctr.x, ctr.y, ctr.z, projTmp)) {
                int baseRgb = goldOnly ? NexusTheme.GOLD_BRIGHT : c.kind().defaultColor;
                NexusTheme.drawLine2D(drawContext, cx, cy, projTmp[0], projTmp[1], NexusTheme.withAlpha(baseRgb, 140));
            }
        }
    }
}
