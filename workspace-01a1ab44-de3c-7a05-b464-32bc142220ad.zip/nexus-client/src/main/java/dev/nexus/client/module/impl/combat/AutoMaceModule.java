package dev.nexus.client.module.impl.combat;

import dev.nexus.client.module.Category;
import dev.nexus.client.module.Module;
import dev.nexus.client.module.impl.render.FreecamModule;
import dev.nexus.client.module.setting.BooleanSetting;
import dev.nexus.client.module.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.MaceItem;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;

/**
 * Module B: Auto Mace
 * Built on Minecraft 1.21.11's real MaceItem smash mechanics (MaceItem.shouldDealAdditionalDamage).
 * Verifies fall distance, gliding state, hotbar Mace availability, target validity, and anti-spam cooldowns.
 */
public final class AutoMaceModule extends Module {
    private final NumberSetting targetRange = addSetting(
        new NumberSetting("target_range", "Target Range", "Attack reach in blocks for Mace smash", 3.6, 2.0, 6.0, 0.1)
    );
    private final NumberSetting minFallDistance = addSetting(
        new NumberSetting("min_fall", "Min Fall Distance", "Minimum fall blocks before engaging (vanilla smash starts > 1.5)", 2.0, 1.5, 12.0, 0.5)
    );
    private final BooleanSetting autoSwitchHotbar = addSetting(
        new BooleanSetting("auto_switch", "Auto Switch Hotbar", "Automatically select Mace from hotbar right before smash", true)
    );
    private final BooleanSetting restoreSlot = (BooleanSetting) addSetting(
        new BooleanSetting("restore_slot", "Restore Previous Slot", "Switch back to previous hotbar item after strike/landing", true)
    ).visibleWhen(autoSwitchHotbar::getValue);

    private final BooleanSetting autoStrike = addSetting(
        new BooleanSetting("auto_strike", "Auto Attack", "Execute Mace strike automatically when target enters smash range", true)
    );
    private final BooleanSetting requireCooldown = addSetting(
        new BooleanSetting("require_cooldown", "Check Attack Cooldown", "Wait for weapon attack cooldown readiness", true)
    );
    private final NumberSetting strikeDelayTicks = addSetting(
        new NumberSetting("strike_delay", "Min Delay (Ticks)", "Minimum ticks between consecutive Auto Mace actions", 6, 2, 20, 1)
    );
    private final BooleanSetting lineOfSight = addSetting(
        new BooleanSetting("line_of_sight", "Line of Sight", "Require clear visibility to target", true)
    );
    private final BooleanSetting targetPlayers = addSetting(
        new BooleanSetting("target_players", "Target Players", "Allow Mace smash on players", true)
    );
    private final BooleanSetting targetMobs = addSetting(
        new BooleanSetting("target_mobs", "Target Mobs", "Allow Mace smash on mobs", true)
    );

    private int savedSlot = -1;
    private int restoreCountdownTicks = 0;
    private int cooldownTicks = 0;

    public AutoMaceModule() {
        super("auto_mace", "Auto Mace", "Assists with timing & hotbar switching for 1.21.11 Mace smash attacks.", Category.COMBAT);
    }

    @Override
    protected void onDisable() {
        restoreSavedSlotIfNeeded();
        cooldownTicks = 0;
    }

    @Override
    public void onWorldCleanup() {
        savedSlot = -1;
        restoreCountdownTicks = 0;
        cooldownTicks = 0;
    }

    @Override
    public void onTick(MinecraftClient client) {
        if (client.player == null || client.world == null || client.interactionManager == null) {
            onWorldCleanup();
            return;
        }
        if (cooldownTicks > 0) {
            cooldownTicks--;
        }

        ClientPlayerEntity player = client.player;
        if (restoreCountdownTicks > 0) {
            restoreCountdownTicks--;
            if (restoreCountdownTicks == 0 || player.isOnGround()) {
                restoreSavedSlotIfNeeded();
            }
        } else if (savedSlot != -1 && player.isOnGround()) {
            restoreSavedSlotIfNeeded();
        }

        if (client.currentScreen != null || FreecamModule.isFreecamActive() || player.isSpectator()) {
            return;
        }
        if (cooldownTicks > 0) {
            return;
        }

        // Verify real 1.21.11 Mace smash eligibility (fallDistance > 1.5 && !isGliding) plus user threshold
        double requiredFall = Math.max(1.51, minFallDistance.getValue());
        if (player.fallDistance < requiredFall || !MaceItem.shouldDealAdditionalDamage(player)) {
            return;
        }
        // Ensure downward velocity so we don't trigger while still ascending from Wind Charge
        if (player.getVelocity().y >= -0.05) {
            return;
        }

        int maceSlot = findMaceInHotbar(player.getInventory());
        boolean holdingMace = player.getMainHandStack().isOf(Items.MACE);
        if (!holdingMace && (!autoSwitchHotbar.getValue() || maceSlot == -1)) {
            return;
        }

        LivingEntity target = findClosestValidTarget(client.world, player);
        if (target == null) {
            return;
        }

        PlayerInventory inv = player.getInventory();
        if (!holdingMace && maceSlot >= 0 && maceSlot < 9) {
            if (restoreSlot.getValue() && savedSlot == -1) {
                savedSlot = inv.getSelectedSlot();
            }
            inv.setSelectedSlot(maceSlot);
            holdingMace = player.getMainHandStack().isOf(Items.MACE);
        }

        if (!holdingMace) {
            return;
        }

        if (autoStrike.getValue()) {
            if (requireCooldown.getValue() && player.getAttackCooldownProgress(0.5f) < 0.85f) {
                return;
            }
            client.interactionManager.attackEntity(player, target);
            player.swingHand(Hand.MAIN_HAND);
            cooldownTicks = strikeDelayTicks.getIntValue();
            if (restoreSlot.getValue() && savedSlot != -1) {
                restoreCountdownTicks = 2;
            }
        }
    }

    private void restoreSavedSlotIfNeeded() {
        if (savedSlot >= 0 && savedSlot < 9 && mc != null && mc.player != null) {
            mc.player.getInventory().setSelectedSlot(savedSlot);
        }
        savedSlot = -1;
        restoreCountdownTicks = 0;
    }

    private static int findMaceInHotbar(PlayerInventory inventory) {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = inventory.getStack(i);
            if (!stack.isEmpty() && stack.isOf(Items.MACE)) {
                return i;
            }
        }
        return -1;
    }

    private LivingEntity findClosestValidTarget(ClientWorld world, ClientPlayerEntity player) {
        double maxDist = targetRange.getValue();
        double maxDistSq = maxDist * maxDist;
        Box box = player.getBoundingBox().expand(maxDist + 1.0);

        LivingEntity closestPlayer = null;
        double closestPlayerSq = maxDistSq;
        LivingEntity closestMob = null;
        double closestMobSq = maxDistSq;

        for (Entity entity : world.getOtherEntities(player, box)) {
            if (!(entity instanceof LivingEntity living) || entity instanceof ArmorStandEntity) {
                continue;
            }
            if (living == player || living.isRemoved() || !living.isAlive() || living.getHealth() <= 0.0f || living.isSpectator()) {
                continue;
            }
            boolean isPlayerTarget = (living instanceof PlayerEntity);
            if (isPlayerTarget) {
                if (!targetPlayers.getValue()) continue;
            } else if (living instanceof Monster || living.isAttackable()) {
                if (!targetMobs.getValue()) continue;
            } else {
                continue;
            }

            if (lineOfSight.getValue() && !player.canSee(living)) {
                continue;
            }

            double dSq = player.squaredDistanceTo(living);
            if (isPlayerTarget) {
                if (dSq <= closestPlayerSq) {
                    closestPlayerSq = dSq;
                    closestPlayer = living;
                }
            } else if (dSq <= closestMobSq) {
                closestMobSq = dSq;
                closestMob = living;
            }
        }
        return closestPlayer != null ? closestPlayer : closestMob;
    }
}
