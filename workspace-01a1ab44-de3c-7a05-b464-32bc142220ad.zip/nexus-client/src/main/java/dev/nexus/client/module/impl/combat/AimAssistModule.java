package dev.nexus.client.module.impl.combat;

import dev.nexus.client.module.Category;
import dev.nexus.client.module.Module;
import dev.nexus.client.module.impl.render.FreecamModule;
import dev.nexus.client.module.setting.BooleanSetting;
import dev.nexus.client.module.setting.KeybindSetting;
import dev.nexus.client.module.setting.ModeSetting;
import dev.nexus.client.module.setting.NumberSetting;
import dev.nexus.client.util.KeyUtil;
import dev.nexus.client.util.RotationUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.MaceItem;
import net.minecraft.item.TridentItem;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/**
 * Module A: Aim Assist
 * Smooth, frame-rate-independent camera assistance toward valid entities within range & FOV.
 * Never snaps abruptly and performs zero camera changes when no valid target exists.
 */
public final class AimAssistModule extends Module {
    private final NumberSetting range = addSetting(
        new NumberSetting("range", "Range", "Maximum target distance in blocks", 4.5, 2.0, 8.0, 0.1)
    );
    private final NumberSetting smoothSpeed = addSetting(
        new NumberSetting("smooth_speed", "Smooth Speed", "Camera interpolation responsiveness", 8.0, 1.0, 25.0, 0.5)
    );
    private final NumberSetting fov = addSetting(
        new NumberSetting("fov", "Max FOV", "Maximum angular cone in degrees", 75.0, 15.0, 180.0, 5.0)
    );
    private final ModeSetting aimPoint = addSetting(
        new ModeSetting("aim_point", "Aim Point", "Part of target hitbox to aim toward", "Chest", "Chest", "Eyes", "Adaptive")
    );
    private final BooleanSetting holdKeyOnly = addSetting(
        new BooleanSetting("hold_key_only", "Hold Key Only", "Only assist while holding the Aim Key below", false)
    );
    private final KeybindSetting holdKey = (KeybindSetting) addSetting(
        new KeybindSetting("hold_key", "Aim Hold Key", "Key or mouse button required when Hold Key Only is active", KeyUtil.UNBOUND)
    ).visibleWhen(holdKeyOnly::getValue);

    private final BooleanSetting requireAttackHold = addSetting(
        new BooleanSetting("require_attack", "While Attacking Only", "Only assist while attack button is held", false)
    );
    private final BooleanSetting requireWeapon = addSetting(
        new BooleanSetting("require_weapon", "Weapon Only", "Only assist while holding a Sword, Axe, Mace, or Trident", false)
    );
    private final BooleanSetting lineOfSight = addSetting(
        new BooleanSetting("line_of_sight", "Line of Sight", "Require unobstructed visibility to target", true)
    );
    private final BooleanSetting ignoreInvisible = addSetting(
        new BooleanSetting("ignore_invisible", "Ignore Invisible", "Skip invisible entities", true)
    );
    private final BooleanSetting targetPlayers = addSetting(
        new BooleanSetting("target_players", "Target Players", "Allow targeting other players", true)
    );
    private final BooleanSetting targetHostiles = addSetting(
        new BooleanSetting("target_hostiles", "Target Hostiles", "Allow targeting hostile monsters", true)
    );
    private final BooleanSetting targetPassives = addSetting(
        new BooleanSetting("target_passives", "Target Passives", "Allow targeting passive/animal mobs", false)
    );
    private final BooleanSetting adjustPitch = addSetting(
        new BooleanSetting("adjust_pitch", "Vertical Assist", "Smoothly adjust vertical pitch as well as yaw", true)
    );

    public AimAssistModule() {
        super("aim_assist", "Aim Assist", "Smoothly guides camera aim toward valid nearby targets.", Category.COMBAT);
    }

    @Override
    public void onRenderFrame(MinecraftClient client, float frameDeltaSeconds) {
        if (client.player == null || client.world == null || client.currentScreen != null) {
            return;
        }
        if (FreecamModule.isFreecamActive() || client.player.isSpectator()) {
            return;
        }
        if (holdKeyOnly.getValue() && (!holdKey.isBound() || !KeyUtil.isPressed(client, holdKey.getValue()))) {
            return;
        }
        if (requireAttackHold.getValue() && !client.options.attackKey.isPressed()) {
            return;
        }
        if (requireWeapon.getValue() && !isHoldingWeapon(client.player.getMainHandStack())) {
            return;
        }

        LivingEntity bestTarget = findBestTarget(client.world, client.player);
        if (bestTarget == null) {
            // Strictly no camera movement when no valid target exists
            return;
        }

        Vec3d targetVec = RotationUtil.getAimPoint(client.player, bestTarget, aimPoint.getValue());
        float[] desired = RotationUtil.getRotationsTo(client.player.getEyePos(), targetVec);

        float dt = MathHelper.clamp(frameDeltaSeconds, 0.001f, 0.1f);
        float alpha = 1.0f - (float) Math.exp(-smoothSpeed.getFloatValue() * dt);
        // Cap single-frame step to guarantee zero sudden camera snapping
        alpha = MathHelper.clamp(alpha, 0.0f, 0.38f);

        float currentYaw = client.player.getYaw();
        float currentPitch = client.player.getPitch();

        float yawDiff = MathHelper.wrapDegrees(desired[0] - currentYaw);
        if (Math.abs(yawDiff) > 0.08f) {
            float newYaw = currentYaw + yawDiff * alpha;
            client.player.setYaw(newYaw);
        }

        if (adjustPitch.getValue()) {
            float pitchDiff = desired[1] - currentPitch;
            if (Math.abs(pitchDiff) > 0.08f) {
                float newPitch = MathHelper.clamp(currentPitch + pitchDiff * (alpha * 0.85f), -90.0f, 90.0f);
                client.player.setPitch(newPitch);
            }
        }
    }

    private LivingEntity findBestTarget(ClientWorld world, ClientPlayerEntity player) {
        double maxDist = range.getValue();
        double maxDistSq = maxDist * maxDist;
        double maxFov = fov.getValue();

        Box searchBox = player.getBoundingBox().expand(maxDist + 1.0);
        LivingEntity best = null;
        double bestScore = Double.MAX_VALUE;

        for (Entity entity : world.getOtherEntities(player, searchBox)) {
            if (!(entity instanceof LivingEntity living) || entity instanceof ArmorStandEntity) {
                continue;
            }
            if (!isValidTarget(player, living, maxDistSq)) {
                continue;
            }

            Vec3d aimVec = RotationUtil.getAimPoint(player, living, aimPoint.getValue());
            float[] rots = RotationUtil.getRotationsTo(player.getEyePos(), aimVec);
            double angle = RotationUtil.getAngleDifference(player.getYaw(), player.getPitch(), rots[0], rots[1]);
            if (angle > maxFov) {
                continue;
            }

            double dist = Math.sqrt(player.getEyePos().squaredDistanceTo(aimVec));
            double score = angle * 1.4 + dist * 4.0;
            if (score < bestScore) {
                bestScore = score;
                best = living;
            }
        }
        return best;
    }

    private boolean isValidTarget(ClientPlayerEntity player, LivingEntity candidate, double maxDistSq) {
        if (candidate == player || candidate.isRemoved() || !candidate.isAlive() || candidate.getHealth() <= 0.0f) {
            return false;
        }
        if (candidate.isSpectator()) {
            return false;
        }
        if (ignoreInvisible.getValue() && candidate.isInvisible()) {
            return false;
        }
        if (player.squaredDistanceTo(candidate) > maxDistSq) {
            return false;
        }
        if (lineOfSight.getValue() && !player.canSee(candidate)) {
            return false;
        }

        if (candidate instanceof PlayerEntity) {
            return targetPlayers.getValue();
        }
        if (candidate instanceof Monster) {
            return targetHostiles.getValue();
        }
        if (candidate instanceof PassiveEntity) {
            return targetPassives.getValue();
        }
        // Neutral/ambient living entities fall under hostiles only if explicitly targeting mobs
        return targetHostiles.getValue() && candidate.isAttackable();
    }

    private static boolean isHoldingWeapon(ItemStack stack) {
        if (stack == null || stack.isEmpty()) {
            return false;
        }
        return stack.isIn(ItemTags.SWORDS)
            || stack.isIn(ItemTags.AXES)
            || stack.getItem() instanceof MaceItem
            || stack.getItem() instanceof TridentItem;
    }
}
