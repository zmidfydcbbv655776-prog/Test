package dev.nexus.client.module;

import dev.nexus.client.module.setting.KeybindSetting;
import dev.nexus.client.module.setting.Setting;
import dev.nexus.client.util.KeyUtil;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.world.chunk.WorldChunk;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class Module {
    private static final Logger LOGGER = LoggerFactory.getLogger("NexusClient");
    private static final int MAX_CONSECUTIVE_ERRORS = 10;

    protected final MinecraftClient mc;
    private final String id;
    private final String name;
    private final String description;
    private final Category category;
    private final List<Setting<?>> settings = new ArrayList<>();
    private final KeybindSetting toggleKeybind;

    private boolean enabled;
    private float toggleAnimProgress;
    private int consecutiveErrors;
    private String lastError;

    protected Module(String id, String name, String description, Category category) {
        this(id, name, description, category, KeyUtil.UNBOUND);
    }

    protected Module(String id, String name, String description, Category category, int defaultKeyCode) {
        this.mc = getClientSafe();
        this.id = id;
        this.name = name;
        this.description = description;
        this.category = category;
        this.toggleKeybind = new KeybindSetting("toggle_key", "Toggle Key", "Keybind to toggle " + name, defaultKeyCode);
        this.settings.add(this.toggleKeybind);
    }

    protected final <S extends Setting<?>> S addSetting(S setting) {
        this.settings.add(setting);
        return setting;
    }

    public final String getId() {
        return id;
    }

    public final String getName() {
        return name;
    }

    public final String getDescription() {
        return description;
    }

    public final Category getCategory() {
        return category;
    }

    public final List<Setting<?>> getSettings() {
        return Collections.unmodifiableList(settings);
    }

    public final KeybindSetting getToggleKeybind() {
        return toggleKeybind;
    }

    public final boolean isEnabled() {
        return enabled;
    }

    public final float getToggleAnimProgress() {
        return toggleAnimProgress;
    }

    public final void setToggleAnimProgress(float progress) {
        this.toggleAnimProgress = progress;
    }

    public final String getLastError() {
        return lastError;
    }

    public final void clearError() {
        this.consecutiveErrors = 0;
        this.lastError = null;
    }

    public final void resetErrorCounter() {
        this.consecutiveErrors = 0;
    }

    public final void handleModuleError(String stage, Throwable t) {
        this.consecutiveErrors++;
        this.lastError = stage + ": " + t.getClass().getSimpleName();
        LOGGER.error("[NEXUS] Module '{}' error in {} ({}/{}): {}",
            name, stage, consecutiveErrors, MAX_CONSECUTIVE_ERRORS, t.toString());
        if (this.consecutiveErrors >= MAX_CONSECUTIVE_ERRORS && this.enabled) {
            LOGGER.warn("[NEXUS] Auto-disabling module '{}' after {} consecutive errors to protect game stability.",
                name, consecutiveErrors);
            setEnabled(false);
        }
    }

    public final void toggle() {
        setEnabled(!this.enabled);
    }

    public final void setEnabled(boolean targetState) {
        if (this.enabled == targetState) {
            return;
        }
        this.enabled = targetState;
        this.consecutiveErrors = 0;
        try {
            if (targetState) {
                clearError();
                onEnable();
            } else {
                onDisable();
            }
        } catch (Throwable t) {
            this.lastError = t.getClass().getSimpleName();
            LOGGER.error("[NEXUS] Module '{}' lifecycle error during {}: {}",
                name, targetState ? "onEnable" : "onDisable", t.toString());
            if (targetState) {
                this.enabled = false;
                try {
                    onDisable();
                } catch (Throwable ignored) {
                }
            }
        }
    }

    protected static MinecraftClient getClientSafe() {
        try {
            return MinecraftClient.getInstance();
        } catch (Throwable t) {
            return null;
        }
    }

    protected void onEnable() {
    }

    protected void onDisable() {
    }

    public void onTick(MinecraftClient client) {
    }

    public void onRenderFrame(MinecraftClient client, float frameDeltaSeconds) {
    }

    public void onRenderWorld(WorldRenderContext context) {
    }

    public void onRenderHud(DrawContext drawContext, RenderTickCounter tickCounter) {
    }

    public void onChunkLoad(ClientWorld world, WorldChunk chunk) {
    }

    public void onChunkUnload(ClientWorld world, WorldChunk chunk) {
    }

    public void onWorldCleanup() {
    }
}
