package dev.nexus.client.mixin;

import dev.nexus.client.module.impl.render.FreecamModule;
import net.minecraft.client.input.Input;
import net.minecraft.client.input.KeyboardInput;
import net.minecraft.util.PlayerInput;
import net.minecraft.util.math.Vec2f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(KeyboardInput.class)
public abstract class KeyboardInputMixin extends Input {
    @Inject(method = "tick", at = @At("TAIL"))
    private void nexus$interceptInputForFreecam(CallbackInfo ci) {
        if (!FreecamModule.isFreecamActive()) {
            return;
        }
        FreecamModule freecam = FreecamModule.getInstance();
        if (freecam != null) {
            freecam.captureMovementInput(this.playerInput, this.movementVector);
            this.playerInput = PlayerInput.DEFAULT;
            this.movementVector = Vec2f.ZERO;
        }
    }
}
