package dev.nexus.client.module.impl.render;

import dev.nexus.client.module.Category;
import dev.nexus.client.module.Module;
import dev.nexus.client.module.setting.BooleanSetting;
import dev.nexus.client.module.setting.NumberSetting;
import dev.nexus.client.render.NexusTheme;
import java.util.Locale;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.PlayerInput;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.Vec3d;

/**
 * Module E: Freecam
 * Independent client-side free camera to inspect loaded chunks without modifying
 * the real player's server position or sending fake movement/rotation packets.
 * Fully controllable on both Desktop (WASD + Mouse) and Android/PojavLauncher (Joystick + Touch Look).
 */
public final class FreecamModule extends Module {
    private static FreecamModule instance;

    private final NumberSetting horizontalSpeed = addSetting(
        new NumberSetting("horizontal_speed", "Horizontal Speed", "Horizontal flight speed in blocks/tick", 0.9, 0.1, 4.0, 0.1)
    );
    private final NumberSetting verticalSpeed = addSetting(
        new NumberSetting("vertical_speed", "Vertical Speed", "Vertical ascent/descent speed", 0.7, 0.1, 4.0, 0.1)
    );
    private final NumberSetting sprintMultiplier = addSetting(
        new NumberSetting("sprint_mult", "Sprint Multiplier", "Speed boost while sprinting", 1.8, 1.1, 3.5, 0.1)
    );
    private final BooleanSetting blockActions = addSetting(
        new BooleanSetting("block_actions", "Block Player Actions", "Prevent accidental block breaking/attacks while in Freecam", true)
    );
    private final BooleanSetting showCoordsHud = addSetting(
        new BooleanSetting("show_hud", "Show Camera Coords", "Display Freecam position & distance from player", true)
    );

    private double camX, camY, camZ;
    private double prevCamX, prevCamY, prevCamZ;
    private float camYaw, camPitch;
    private float prevCamYaw, prevCamPitch;

    private PlayerInput capturedInput = PlayerInput.DEFAULT;
    private Vec2f capturedMoveVec = Vec2f.ZERO;
    private boolean initialized;

    public FreecamModule() {
        super("freecam", "Freecam", "Client-side free camera without moving your server player.", Category.RENDER);
        instance = this;
    }

    public static FreecamModule getInstance() {
        return instance;
    }

    public static boolean isFreecamActive() {
        return instance != null && instance.isEnabled() && instance.initialized
            && MinecraftClient.getInstance().player != null
            && MinecraftClient.getInstance().world != null;
    }

    public boolean shouldBlockPlayerActions() {
        return isFreecamActive() && blockActions.getValue();
    }

    @Override
    protected void onEnable() {
        if (mc == null || mc.player == null || mc.world == null) {
            this.initialized = false;
            return;
        }
        Camera camera = mc.gameRenderer.getCamera();
        Vec3d startPos = camera.isReady() ? camera.getCameraPos() : mc.player.getEyePos();
        this.camX = this.prevCamX = startPos.x;
        this.camY = this.prevCamY = startPos.y;
        this.camZ = this.prevCamZ = startPos.z;
        this.camYaw = this.prevCamYaw = mc.player.getYaw();
        this.camPitch = this.prevCamPitch = mc.player.getPitch();
        this.capturedInput = PlayerInput.DEFAULT;
        this.capturedMoveVec = Vec2f.ZERO;
        this.initialized = true;
    }

    @Override
    protected void onDisable() {
        resetCameraState();
        if (mc != null && mc.worldRenderer != null && mc.worldRenderer.getChunkRenderingDataPreparer() != null) {
            mc.worldRenderer.getChunkRenderingDataPreparer().scheduleTerrainUpdate();
        }
    }

    @Override
    public void onWorldCleanup() {
        if (isEnabled()) {
            setEnabled(false);
        } else {
            resetCameraState();
        }
    }

    private void resetCameraState() {
        this.initialized = false;
        this.capturedInput = PlayerInput.DEFAULT;
        this.capturedMoveVec = Vec2f.ZERO;
    }

    public void captureMovementInput(PlayerInput input, Vec2f moveVec) {
        this.capturedInput = input != null ? input : PlayerInput.DEFAULT;
        this.capturedMoveVec = moveVec != null ? moveVec : Vec2f.ZERO;
    }

    public void onLookDelta(double cursorDeltaX, double cursorDeltaY) {
        if (!initialized) {
            return;
        }
        // Vanilla Entity.changeLookDirection applies 0.15f degrees per cursor unit
        float deltaYaw = (float) cursorDeltaX * 0.15f;
        float deltaPitch = (float) cursorDeltaY * 0.15f;
        this.camYaw += deltaYaw;
        this.camPitch = MathHelper.clamp(this.camPitch + deltaPitch, -90.0f, 90.0f);
        this.prevCamYaw += deltaYaw;
        this.prevCamPitch = MathHelper.clamp(this.prevCamPitch + deltaPitch, -90.0f, 90.0f);
    }

    @Override
    public void onTick(MinecraftClient client) {
        if (client.player == null || client.world == null) {
            setEnabled(false);
            return;
        }
        if (!initialized) {
            onEnable();
            if (!initialized) {
                return;
            }
        }

        this.prevCamX = this.camX;
        this.prevCamY = this.camY;
        this.prevCamZ = this.camZ;
        this.prevCamYaw = this.camYaw;
        this.prevCamPitch = this.camPitch;

        if (client.currentScreen != null) {
            this.capturedInput = PlayerInput.DEFAULT;
            this.capturedMoveVec = Vec2f.ZERO;
            return;
        }

        double forward = capturedMoveVec.y;
        double strafe = capturedMoveVec.x;

        // Fallback to raw PlayerInput booleans if analog vector wasn't populated
        if (Math.abs(forward) < 1e-4 && Math.abs(strafe) < 1e-4) {
            if (capturedInput.forward()) forward += 1.0;
            if (capturedInput.backward()) forward -= 1.0;
            if (capturedInput.left()) strafe += 1.0;
            if (capturedInput.right()) strafe -= 1.0;
        }

        double vertical = 0.0;
        if (capturedInput.jump()) vertical += 1.0;
        if (capturedInput.sneak()) vertical -= 1.0;

        double mult = capturedInput.sprint() ? sprintMultiplier.getValue() : 1.0;
        double hSpeed = horizontalSpeed.getValue() * mult;
        double vSpeed = verticalSpeed.getValue() * mult;

        double lenSq = forward * forward + strafe * strafe;
        if (lenSq > 1.0) {
            double invLen = 1.0 / Math.sqrt(lenSq);
            forward *= invLen;
            strafe *= invLen;
        }

        double yawRad = Math.toRadians(this.camYaw);
        double sinYaw = Math.sin(yawRad);
        double cosYaw = Math.cos(yawRad);

        double dx = (strafe * cosYaw - forward * sinYaw) * hSpeed;
        double dz = (forward * cosYaw + strafe * sinYaw) * hSpeed;
        double dy = vertical * vSpeed;

        this.camX += dx;
        this.camY += dy;
        this.camZ += dz;
    }

    public Vec3d getInterpolatedPos(float tickProgress) {
        return new Vec3d(
            MathHelper.lerp(tickProgress, prevCamX, camX),
            MathHelper.lerp(tickProgress, prevCamY, camY),
            MathHelper.lerp(tickProgress, prevCamZ, camZ)
        );
    }

    public float getInterpolatedYaw(float tickProgress) {
        return MathHelper.lerp(tickProgress, prevCamYaw, camYaw);
    }

    public float getInterpolatedPitch(float tickProgress) {
        return MathHelper.lerp(tickProgress, prevCamPitch, camPitch);
    }

    @Override
    public void onRenderHud(DrawContext context, RenderTickCounter tickCounter) {
        if (!showCoordsHud.getValue() || !isFreecamActive() || mc.player == null) {
            return;
        }
        double dist = Math.sqrt(mc.player.squaredDistanceTo(camX, camY, camZ));
        String label = String.format(Locale.ROOT, "FREECAM  %.1f, %.1f, %.1f  (%.1fm)", camX, camY, camZ, dist);
        int textW = mc.textRenderer.getWidth(label);
        int boxW = textW + 14;
        int boxH = 16;
        int x = (context.getScaledWindowWidth() - boxW) / 2;
        int y = 8;

        NexusTheme.drawRoundedPanel(context, x, y, boxW, boxH, NexusTheme.BG_HUD, NexusTheme.BORDER_GOLD);
        context.drawTextWithShadow(mc.textRenderer, label, x + 7, y + 4, NexusTheme.GOLD_BRIGHT);
    }
}
