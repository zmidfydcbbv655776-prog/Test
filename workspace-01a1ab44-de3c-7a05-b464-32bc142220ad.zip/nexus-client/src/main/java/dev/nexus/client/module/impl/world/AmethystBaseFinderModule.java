package dev.nexus.client.module.impl.world;

import dev.nexus.client.event.WorldChunkTracker;
import dev.nexus.client.module.Category;
import dev.nexus.client.module.Module;
import dev.nexus.client.module.setting.ActionSetting;
import dev.nexus.client.module.setting.BooleanSetting;
import dev.nexus.client.module.setting.ModeSetting;
import dev.nexus.client.module.setting.NumberSetting;
import dev.nexus.client.render.HudLayoutHelper;
import dev.nexus.client.render.NexusTheme;
import dev.nexus.client.render.WorldProjector;
import dev.nexus.client.render.WorldRenderHelper;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;

/**
 * Module F: Amethyst Base Finder
 * Inspects real 1.21.11 Amethyst blocks & crystal growth stages in loaded chunks:
 *  - small_amethyst_bud, medium_amethyst_bud, large_amethyst_bud, amethyst_cluster, budding_amethyst, amethyst_block
 *
 * Crash-hardened architecture:
 *  - Thread-safe ConcurrentLinkedQueue + ConcurrentHashMap across chunk load/unload & tick threads
 *  - Strictly intra-section or verified-loaded-chunk neighbor reads (never touches unloaded chunks)
 *  - Single-batch QUADS 3D rendering via WorldRenderHelper (zero GizmoDrawing / clearDepthTexture crashes)
 */
public final class AmethystBaseFinderModule extends Module {
    private static final int COLOR_AMETHYST = 0xFFB565F7;
    private static final int COLOR_MATURE   = 0xFFE066FF;
    private static final int COLOR_FARMED   = 0xFF2ECC71;
    private static final Direction[] ALL_DIRECTIONS = Direction.values();

    public record CrystalEntry(BlockPos pos, int stage) {
        // stage: 0 = budding, 1 = small, 2 = medium, 3 = large, 4 = full mature cluster
    }

    public record GeodeChunkData(
        int chunkX,
        int chunkZ,
        int buddingCount,
        int matureCount,
        int growingBudCount,
        int amethystBlockCount,
        int openBuddingFaces,
        int minX, int minY, int minZ,
        int maxX, int maxY, int maxZ,
        double confidence,
        Vec3d centroid,
        List<CrystalEntry> crystals
    ) {
    }

    public record GeodeSite(
        long siteKey,
        int x1, int y1, int z1,
        int x2, int y2, int z2,
        Vec3d center,
        int buddingCount,
        int matureCount,
        int growingCount,
        double confidence,
        List<CrystalEntry> crystals
    ) {
    }

    private final NumberSetting chunkRange = addSetting(
        new NumberSetting("chunk_range", "Scan Radius (Chunks)", "Chunk scan radius around player", 8, 2, 20, 1)
    );
    private final NumberSetting chunksPerTick = addSetting(
        new NumberSetting("chunks_per_tick", "Chunks / Tick", "Incremental scan budget per client tick", 3, 1, 8, 1)
    );
    private final NumberSetting minConfidence = addSetting(
        new NumberSetting("min_confidence", "Min Confidence %", "Minimum score before reporting a geode site", 20, 5, 90, 5)
    );
    private final BooleanSetting onlyGrown = addSetting(
        new BooleanSetting("only_grown", "Only With Mature Clusters", "Only show geodes that have at least 1 mature amethyst cluster", false)
    );
    private final ModeSetting boxMode = addSetting(
        new ModeSetting("box_mode", "Highlight Style", "Whole geode box, individual crystals, or both",
            "Geode + Crystals", "Geode + Crystals", "Whole Geode Box", "Crystals Only")
    );
    private final NumberSetting maxBoxes = addSetting(
        new NumberSetting("max_boxes", "Max Crystal Boxes", "Cap rendered crystal outlines in dense caves", 120, 25, 400, 25)
    );
    private final NumberSetting lineWidth = addSetting(
        new NumberSetting("line_width", "Line Thickness", "3D outline stroke width", 1.8, 1.0, 4.0, 0.2)
    );
    private final BooleanSetting glow = addSetting(
        new BooleanSetting("glow", "Outline Glow", "Soft glow halo around geode/crystal boxes", true)
    );
    private final BooleanSetting fillBoxes = addSetting(
        new BooleanSetting("fill_boxes", "Fill Boxes", "Draw translucent fill inside boxes", true)
    );
    private final BooleanSetting renderDirectionArrow = addSetting(
        new BooleanSetting("direction_arrow", "3D Direction Arrow", "Draw 3D guide arrow toward highest-confidence geode", true)
    );
    private final BooleanSetting renderLabels = addSetting(
        new BooleanSetting("labels", "2D Geode Labels", "Project floating distance & crystal count tags", true)
    );
    private final BooleanSetting renderHudIndicator = addSetting(
        new BooleanSetting("hud_indicator", "HUD Confidence Card", "Show top-left compass & confidence indicator", true)
    );
    private final BooleanSetting chatAlert = addSetting(
        new BooleanSetting("chat_alert", "Chat Alert", "Announce newly discovered geodes in client chat", false)
    );
    private final BooleanSetting soundAlert = addSetting(
        new BooleanSetting("sound_alert", "Sound Alert", "Play subtle chime when a high-confidence geode is found", false)
    );
    @SuppressWarnings("unused")
    private final ActionSetting rescanButton = addSetting(
        new ActionSetting("rescan_geodes", "Rescan Loaded Chunks", "Clear cached geode data and rescan all loaded chunks", this::triggerFullRescan)
    );

    private final Map<Long, GeodeChunkData> geodeChunks = new ConcurrentHashMap<>();
    private final Queue<Long> scanQueue = new ConcurrentLinkedQueue<>();
    private final Set<Long> queuedSet = ConcurrentHashMap.newKeySet();
    private final Set<Long> reportedSites = ConcurrentHashMap.newKeySet();

    private volatile List<GeodeSite> activeSites = List.of();
    private volatile GeodeSite bestTarget = null;
    private ClientWorld lastWorld = null;
    private int periodicRefreshTicks = 0;
    private final double[] projTmp = new double[2];

    public AmethystBaseFinderModule() {
        super("amethyst_base_finder", "Amethyst Base Finder", "Analyzes 1.21.11 amethyst geodes & crystal growth with crash-safe ESP.", Category.WORLD);
    }

    @Override
    protected void onEnable() {
        resetState();
        lastWorld = mc != null ? mc.world : null;
        enqueueLoadedChunks();
    }

    @Override
    protected void onDisable() {
        resetState();
    }

    @Override
    public void onWorldCleanup() {
        resetState();
    }

    private void resetState() {
        geodeChunks.clear();
        scanQueue.clear();
        queuedSet.clear();
        reportedSites.clear();
        activeSites = List.of();
        bestTarget = null;
        lastWorld = null;
        periodicRefreshTicks = 0;
    }

    public void triggerFullRescan() {
        geodeChunks.clear();
        scanQueue.clear();
        queuedSet.clear();
        reportedSites.clear();
        activeSites = List.of();
        bestTarget = null;
        enqueueLoadedChunks();
    }

    @Override
    public void onChunkLoad(ClientWorld world, WorldChunk chunk) {
        if (chunk != null) {
            enqueueChunk(chunk.getPos().toLong());
        }
    }

    @Override
    public void onChunkUnload(ClientWorld world, WorldChunk chunk) {
        if (chunk != null) {
            long key = chunk.getPos().toLong();
            geodeChunks.remove(key);
            queuedSet.remove(key);
        }
    }

    private void enqueueChunk(long key) {
        if (queuedSet.add(key)) {
            scanQueue.offer(key);
        }
    }

    private void enqueueLoadedChunks() {
        if (mc == null || mc.world == null || mc.player == null) {
            return;
        }
        int radius = chunkRange.getIntValue();
        for (WorldChunk chunk : WorldChunkTracker.getLoadedChunksAroundPlayer(mc, radius)) {
            enqueueChunk(chunk.getPos().toLong());
        }
    }

    @Override
    public void onTick(MinecraftClient client) {
        if (client.world == null || client.player == null) {
            resetState();
            return;
        }
        if (client.world != lastWorld) {
            resetState();
            lastWorld = client.world;
            enqueueLoadedChunks();
        }

        // Purge unloaded chunks immediately
        geodeChunks.keySet().removeIf(key -> {
            int cx = ChunkPos.getPackedX(key);
            int cz = ChunkPos.getPackedZ(key);
            return !WorldChunkTracker.isChunkCurrentlyLoaded(client.world, cx, cz);
        });

        periodicRefreshTicks++;
        if (periodicRefreshTicks >= 80) {
            periodicRefreshTicks = 0;
            enqueueLoadedChunks();
        }

        // Budgeted incremental chunk scan (caps work per tick + 6ms wall-clock safety limit)
        int budget = chunksPerTick.getIntValue();
        int processed = 0;
        long deadlineNs = System.nanoTime() + 6_000_000L;

        while (processed < budget && !scanQueue.isEmpty()) {
            Long keyObj = scanQueue.poll();
            if (keyObj == null) {
                break;
            }
            long key = keyObj;
            queuedSet.remove(key);

            int cx = ChunkPos.getPackedX(key);
            int cz = ChunkPos.getPackedZ(key);
            if (!WorldChunkTracker.isChunkCurrentlyLoaded(client.world, cx, cz)) {
                geodeChunks.remove(key);
                continue;
            }
            WorldChunk chunk = client.world.getChunkManager().getWorldChunk(cx, cz);
            if (chunk != null && !chunk.isEmpty()) {
                scanSingleChunk(client.world, chunk);
                processed++;
            }
            if (System.nanoTime() >= deadlineNs) {
                break;
            }
        }

        rebuildGeodeSites(client);
    }

    private void scanSingleChunk(ClientWorld world, WorldChunk chunk) {
        long key = chunk.getPos().toLong();
        int cx = chunk.getPos().x;
        int cz = chunk.getPos().z;
        int chunkBaseX = cx << 4;
        int chunkBaseZ = cz << 4;

        int buddingCount = 0;
        int matureCount = 0;
        int growingBudCount = 0;
        int amethystBlockCount = 0;
        int openBuddingFaces = 0;

        int minX = Integer.MAX_VALUE, minY = Integer.MAX_VALUE, minZ = Integer.MAX_VALUE;
        int maxX = Integer.MIN_VALUE, maxY = Integer.MIN_VALUE, maxZ = Integer.MIN_VALUE;
        double sumX = 0.0, sumY = 0.0, sumZ = 0.0;
        int sampleCount = 0;

        List<CrystalEntry> crystals = new ArrayList<>();
        ChunkSection[] sections = chunk.getSectionArray();
        int bottomSectionCoord = chunk.getBottomSectionCoord();

        for (int secIdx = 0; secIdx < sections.length; secIdx++) {
            ChunkSection section = sections[secIdx];
            if (section == null || section.isEmpty()) {
                continue;
            }
            // Fast palette pre-check: skip 4096-block loop completely if section contains zero amethyst blocks!
            if (!section.hasAny(state -> {
                Block b = state.getBlock();
                return b == Blocks.BUDDING_AMETHYST
                    || b == Blocks.AMETHYST_CLUSTER
                    || b == Blocks.LARGE_AMETHYST_BUD
                    || b == Blocks.MEDIUM_AMETHYST_BUD
                    || b == Blocks.SMALL_AMETHYST_BUD
                    || b == Blocks.AMETHYST_BLOCK;
            })) {
                continue;
            }

            int sectionBaseY = (bottomSectionCoord + secIdx) << 4;

            for (int ly = 0; ly < 16; ly++) {
                int wy = sectionBaseY + ly;
                for (int lz = 0; lz < 16; lz++) {
                    int wz = chunkBaseZ + lz;
                    for (int lx = 0; lx < 16; lx++) {
                        BlockState state = section.getBlockState(lx, ly, lz);
                        Block block = state.getBlock();

                        int stage = -1;
                        if (block == Blocks.BUDDING_AMETHYST) {
                            buddingCount++;
                            stage = 0;
                            openBuddingFaces += countOpenGrowthFacesSafe(world, chunk, section, lx, ly, lz, chunkBaseX + lx, wy, wz);
                        } else if (block == Blocks.SMALL_AMETHYST_BUD) {
                            growingBudCount++;
                            stage = 1;
                        } else if (block == Blocks.MEDIUM_AMETHYST_BUD) {
                            growingBudCount++;
                            stage = 2;
                        } else if (block == Blocks.LARGE_AMETHYST_BUD) {
                            growingBudCount++;
                            stage = 3;
                        } else if (block == Blocks.AMETHYST_CLUSTER) {
                            matureCount++;
                            stage = 4;
                        } else if (block == Blocks.AMETHYST_BLOCK) {
                            amethystBlockCount++;
                        } else {
                            continue;
                        }

                        int wx = chunkBaseX + lx;
                        if (wx < minX) minX = wx;
                        if (wy < minY) minY = wy;
                        if (wz < minZ) minZ = wz;
                        if (wx > maxX) maxX = wx;
                        if (wy > maxY) maxY = wy;
                        if (wz > maxZ) maxZ = wz;

                        sumX += wx + 0.5;
                        sumY += wy + 0.5;
                        sumZ += wz + 0.5;
                        sampleCount++;

                        if (stage >= 0 && crystals.size() < 96) {
                            crystals.add(new CrystalEntry(new BlockPos(wx, wy, wz), stage));
                        }
                    }
                }
            }
        }

        if (buddingCount == 0 && matureCount == 0 && growingBudCount == 0) {
            geodeChunks.remove(key);
            return;
        }

        int totalGrowthNodes = matureCount + growingBudCount;
        double maturityRatio = totalGrowthNodes > 0 ? (double) matureCount / totalGrowthNodes : 0.0;
        double clearedRatio = buddingCount > 0 ? (double) openBuddingFaces / (buddingCount * 6.0) : 0.0;

        double confidence = 18.0;
        confidence += Math.min(28.0, buddingCount * 2.2);
        confidence += maturityRatio * 28.0;
        if (buddingCount >= 3 && clearedRatio > 0.52) {
            // High open-face ratio around budding amethyst suggests player-cleared amethyst farm
            confidence += Math.min(26.0, (clearedRatio - 0.45) * 60.0);
        }
        if (matureCount >= 4) {
            confidence += Math.min(14.0, matureCount * 1.4);
        }
        confidence = MathHelper.clamp(confidence, 5.0, 99.0);

        Vec3d centroid = sampleCount > 0
            ? new Vec3d(sumX / sampleCount, sumY / sampleCount, sumZ / sampleCount)
            : new Vec3d(chunkBaseX + 8.0, 0.0, chunkBaseZ + 8.0);

        geodeChunks.put(key, new GeodeChunkData(
            cx, cz,
            buddingCount, matureCount, growingBudCount, amethystBlockCount, openBuddingFaces,
            minX, minY, minZ, maxX, maxY, maxZ,
            confidence, centroid, List.copyOf(crystals)
        ));
    }

    /**
     * Safely counts open/crystal faces around a Budding Amethyst block without ever querying unloaded chunks.
     */
    private static int countOpenGrowthFacesSafe(
        ClientWorld world,
        WorldChunk chunk,
        ChunkSection currentSection,
        int lx, int ly, int lz,
        int wx, int wy, int wz
    ) {
        int bottomY = world.getBottomY();
        int topY = world.getTopYInclusive();
        int openFaces = 0;

        for (Direction dir : ALL_DIRECTIONS) {
            int nlx = lx + dir.getOffsetX();
            int nly = ly + dir.getOffsetY();
            int nlz = lz + dir.getOffsetZ();
            int nwy = wy + dir.getOffsetY();
            if (nwy < bottomY || nwy > topY) {
                continue;
            }

            BlockState neighbor;
            if (nlx >= 0 && nlx < 16 && nly >= 0 && nly < 16 && nlz >= 0 && nlz < 16) {
                // Fast path: inside the exact same 16x16x16 ChunkSection!
                neighbor = currentSection.getBlockState(nlx, nly, nlz);
            } else if (nlx >= 0 && nlx < 16 && nlz >= 0 && nlz < 16) {
                // Same chunk, adjacent vertical section
                neighbor = chunk.getBlockState(new BlockPos(wx, nwy, wz));
            } else {
                // Neighboring chunk — ONLY read if that chunk is confirmed loaded!
                int nwx = wx + dir.getOffsetX();
                int nwz = wz + dir.getOffsetZ();
                int ncx = nwx >> 4;
                int ncz = nwz >> 4;
                if (!WorldChunkTracker.isChunkCurrentlyLoaded(world, ncx, ncz)) {
                    continue;
                }
                WorldChunk neighborChunk = world.getChunkManager().getWorldChunk(ncx, ncz);
                if (neighborChunk == null || neighborChunk.isEmpty()) {
                    continue;
                }
                neighbor = neighborChunk.getBlockState(new BlockPos(nwx, nwy, nwz));
            }

            Block nb = neighbor.getBlock();
            if (neighbor.isAir()
                || nb == Blocks.WATER
                || nb == Blocks.SMALL_AMETHYST_BUD
                || nb == Blocks.MEDIUM_AMETHYST_BUD
                || nb == Blocks.LARGE_AMETHYST_BUD
                || nb == Blocks.AMETHYST_CLUSTER) {
                openFaces++;
            }
        }
        return openFaces;
    }

    private void rebuildGeodeSites(MinecraftClient client) {
        if (geodeChunks.isEmpty() || client.player == null) {
            activeSites = List.of();
            bestTarget = null;
            return;
        }

        List<GeodeChunkData> chunks = new ArrayList<>(geodeChunks.values());
        int n = chunks.size();
        boolean[] used = new boolean[n];
        List<GeodeSite> built = new ArrayList<>();

        double threshold = minConfidence.getValue();
        boolean requireMature = onlyGrown.getValue();
        int maxDistBlocks = (chunkRange.getIntValue() + 2) * 16;
        double maxDistSq = (double) maxDistBlocks * maxDistBlocks;
        Vec3d playerPos = client.player.getEyePos();

        for (int i = 0; i < n; i++) {
            if (used[i]) continue;
            GeodeChunkData seed = chunks.get(i);
            used[i] = true;

            int x1 = seed.minX(), y1 = seed.minY(), z1 = seed.minZ();
            int x2 = seed.maxX(), y2 = seed.maxY(), z2 = seed.maxZ();
            int budding = seed.buddingCount();
            int mature = seed.matureCount();
            int growing = seed.growingBudCount();
            double bestConf = seed.confidence();
            List<CrystalEntry> mergedCrystals = new ArrayList<>(seed.crystals());

            // Merge adjacent chunks that belong to the same geode split across a chunk border
            boolean added;
            do {
                added = false;
                for (int j = 0; j < n; j++) {
                    if (used[j]) continue;
                    GeodeChunkData cand = chunks.get(j);
                    if (cand.minX() <= x2 + 6 && cand.maxX() >= x1 - 6
                        && cand.minY() <= y2 + 6 && cand.maxY() >= y1 - 6
                        && cand.minZ() <= z2 + 6 && cand.maxZ() >= z1 - 6) {
                        used[j] = true;
                        added = true;
                        x1 = Math.min(x1, cand.minX());
                        y1 = Math.min(y1, cand.minY());
                        z1 = Math.min(z1, cand.minZ());
                        x2 = Math.max(x2, cand.maxX());
                        y2 = Math.max(y2, cand.maxY());
                        z2 = Math.max(z2, cand.maxZ());
                        budding += cand.buddingCount();
                        mature += cand.matureCount();
                        growing += cand.growingBudCount();
                        bestConf = Math.max(bestConf, cand.confidence());
                        if (mergedCrystals.size() < 160) {
                            int room = 160 - mergedCrystals.size();
                            mergedCrystals.addAll(cand.crystals().subList(0, Math.min(room, cand.crystals().size())));
                        }
                    }
                }
            } while (added);

            if (bestConf < threshold) continue;
            if (requireMature && mature == 0) continue;

            Vec3d center = new Vec3d((x1 + x2 + 1) * 0.5, (y1 + y2 + 1) * 0.5, (z1 + z2 + 1) * 0.5);
            if (playerPos.squaredDistanceTo(center) > maxDistSq) {
                continue;
            }

            long siteKey = BlockPos.asLong((x1 + x2) >> 1, (y1 + y2) >> 1, (z1 + z2) >> 1);
            GeodeSite site = new GeodeSite(
                siteKey, x1, y1, z1, x2, y2, z2,
                center, budding, mature, growing, bestConf, mergedCrystals
            );
            built.add(site);

            if (reportedSites.add(siteKey)) {
                if (chatAlert.getValue()) {
                    String msg = String.format(
                        Locale.ROOT,
                        "Geode @ %d, %d, %d (%d mature, %d budding, %.0f%% conf)",
                        (int) Math.round(center.x), (int) Math.round(center.y), (int) Math.round(center.z),
                        mature, budding, bestConf
                    );
                    client.player.sendMessage(
                        Text.literal("[Amethyst] ").formatted(Formatting.LIGHT_PURPLE)
                            .append(Text.literal(msg).formatted(Formatting.WHITE)),
                        false
                    );
                }
                if (soundAlert.getValue() && bestConf >= 55.0) {
                    client.player.playSound(SoundEvents.BLOCK_NOTE_BLOCK_PLING.value(), 0.7f, 1.35f);
                }
            }
        }

        built.sort(Comparator.comparingDouble(s -> playerPos.squaredDistanceTo(s.center())));
        activeSites = built;

        GeodeSite highest = null;
        double bestScore = -1.0;
        for (GeodeSite s : built) {
            double dist = Math.sqrt(playerPos.squaredDistanceTo(s.center()));
            double score = s.confidence() - dist * 0.08;
            if (score > bestScore) {
                bestScore = score;
                highest = s;
            }
        }
        bestTarget = highest;
    }

    @Override
    public void onRenderWorld(WorldRenderContext context) {
        List<GeodeSite> sites = activeSites;
        if (sites.isEmpty() || mc == null || mc.player == null) {
            return;
        }

        boolean drawWholeGeode = !boxMode.isMode("Crystals Only");
        boolean drawCrystals = !boxMode.isMode("Whole Geode Box");
        boolean glowOn = glow.getValue();
        boolean fillOn = fillBoxes.getValue();
        float width = lineWidth.getFloatValue();
        int crystalBudget = maxBoxes.getIntValue();
        int crystalsDrawn = 0;

        for (GeodeSite site : sites) {
            int siteColor = site.confidence() >= 68.0 ? COLOR_FARMED
                : (site.matureCount() > 0 ? COLOR_MATURE : COLOR_AMETHYST);

            if (drawWholeGeode) {
                Box geodeBox = new Box(
                    site.x1(), site.y1(), site.z1(),
                    site.x2() + 1.0, site.y2() + 1.0, site.z2() + 1.0
                );
                int stroke = NexusTheme.withAlpha(siteColor, 225);
                int fill = fillOn ? NexusTheme.withAlpha(siteColor, 26) : 0;
                WorldRenderHelper.drawBoxGlow(geodeBox, stroke, width, fill, glowOn, true);
            }

            if (drawCrystals && crystalsDrawn < crystalBudget) {
                for (CrystalEntry crystal : site.crystals()) {
                    if (crystalsDrawn >= crystalBudget) {
                        break;
                    }
                    // Highlight mature clusters & budding blocks most prominently
                    if (crystal.stage() == 0 || crystal.stage() >= 3 || site.crystals().size() <= 24) {
                        int cColor = switch (crystal.stage()) {
                            case 4 -> COLOR_MATURE;
                            case 0 -> NexusTheme.GOLD_BRIGHT;
                            default -> COLOR_AMETHYST;
                        };
                        int cStroke = NexusTheme.withAlpha(cColor, crystal.stage() == 4 ? 235 : 175);
                        int cFill = fillOn ? NexusTheme.withAlpha(cColor, crystal.stage() == 4 ? 48 : 24) : 0;
                        WorldRenderHelper.drawBlockBoxGlow(crystal.pos(), cStroke, Math.max(1.0f, width * 0.85f), cFill, glowOn && crystal.stage() == 4, true);
                        crystalsDrawn++;
                    }
                }
            }
        }

        GeodeSite target = bestTarget;
        if (renderDirectionArrow.getValue() && target != null && mc.gameRenderer != null) {
            var cam = mc.gameRenderer.getCamera();
            if (cam != null && cam.isReady()) {
                Vec3d camPos = cam.getCameraPos();
                var fwd = cam.getHorizontalPlane();
                Vec3d origin = camPos.add(fwd.x() * 1.35, -0.32, fwd.z() * 1.35);
                Vec3d delta = target.center().subtract(origin);
                double len = delta.length();
                if (len > 2.5 && Double.isFinite(len)) {
                    Vec3d tip = origin.add(delta.normalize().multiply(Math.min(1.6, len * 0.45)));
                    int arrowColor = target.confidence() >= 68.0 ? COLOR_FARMED : NexusTheme.GOLD_BRIGHT;
                    WorldRenderHelper.drawArrow(origin, tip, NexusTheme.withAlpha(arrowColor, 235), 2.2f, true);
                }
            }
        }
    }

    @Override
    public void onRenderHud(DrawContext context, RenderTickCounter tickCounter) {
        if (mc == null || mc.player == null || mc.world == null) {
            return;
        }
        List<GeodeSite> sites = activeSites;

        if (renderLabels.getValue() && WorldProjector.isReady() && !sites.isEmpty()) {
            Vec3d camPos = WorldProjector.camPos;
            int shown = 0;
            Set<Long> occupiedCells = new HashSet<>();
            for (GeodeSite site : sites) {
                if (shown >= 8) {
                    break;
                }
                Vec3d c = site.center();
                if (!WorldProjector.project(c.x, site.y2() + 1.35, c.z, projTmp)) {
                    continue;
                }
                int sx = (int) Math.round(projTmp[0]);
                int sy = (int) Math.round(projTmp[1]);
                long cell = (((long) (sx / 64)) << 32) ^ ((sy / 18) & 0xFFFFFFFFL);
                if (!occupiedCells.add(cell)) {
                    continue;
                }
                int dist = (int) Math.round(Math.sqrt(camPos.squaredDistanceTo(c)));
                String tag = site.matureCount() > 0
                    ? String.format(Locale.ROOT, "GEODE  %dm  (%d grown | %.0f%%)", dist, site.matureCount(), site.confidence())
                    : String.format(Locale.ROOT, "GEODE  %dm  (%d budding | %.0f%%)", dist, site.buddingCount(), site.confidence());
                int accent = site.confidence() >= 68.0 ? COLOR_FARMED : COLOR_AMETHYST;
                NexusTheme.drawFloatingTag(context, mc.textRenderer, tag, sx, sy, accent, false);
                shown++;
            }
        }

        GeodeSite target = bestTarget;
        if (!renderHudIndicator.getValue() || target == null) {
            return;
        }

        Vec3d playerPos = mc.player.getEyePos();
        double dx = target.center().x - playerPos.x;
        double dz = target.center().z - playerPos.z;
        double dist = Math.sqrt(playerPos.squaredDistanceTo(target.center()));

        float targetYaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float relAngle = MathHelper.wrapDegrees(targetYaw - mc.player.getYaw());
        String dirArrow = getDirectionGlyph(relAngle);

        String line1 = String.format(Locale.ROOT, "AMETHYST %s %.0fm  (%.0f%%)", dirArrow, dist, target.confidence());
        String line2 = String.format(Locale.ROOT, "Budding: %d | Mature: %d | Growing: %d",
            target.buddingCount(), target.matureCount(), target.growingCount());

        int w = Math.max(mc.textRenderer.getWidth(line1), mc.textRenderer.getWidth(line2)) + 14;
        int h = 28;
        int x = 8;
        int y = HudLayoutHelper.claimTopLeftY(h, 5);

        int borderCol = target.confidence() >= 68.0 ? COLOR_FARMED : NexusTheme.BORDER_GOLD;
        NexusTheme.drawRoundedPanel(context, x, y, w, h, NexusTheme.BG_HUD, borderCol);
        context.drawTextWithShadow(mc.textRenderer, line1, x + 7, y + 5, NexusTheme.GOLD_BRIGHT);
        context.drawTextWithShadow(mc.textRenderer, line2, x + 7, y + 16, NexusTheme.TEXT_SECONDARY);
    }

    private static String getDirectionGlyph(float relAngle) {
        if (relAngle >= -22.5f && relAngle <= 22.5f) return "^";
        if (relAngle > 22.5f && relAngle <= 67.5f) return "^>";
        if (relAngle > 67.5f && relAngle <= 112.5f) return ">";
        if (relAngle > 112.5f && relAngle <= 157.5f) return "v>";
        if (relAngle < -22.5f && relAngle >= -67.5f) return "<^";
        if (relAngle < -67.5f && relAngle >= -112.5f) return "<";
        if (relAngle < -112.5f && relAngle >= -157.5f) return "<v";
        return "v";
    }
}
