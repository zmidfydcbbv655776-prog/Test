# پرامپت جامع ساخت کامل کلاینت NEXUS CLIENT (نسخه نهایی و بدون باگ برای Minecraft 1.21.11)

یک ماد کلاینت واقعی، قابل کامپایل و قابل نصب برای **Minecraft Java Edition `1.21.11`** با نام **`NEXUS CLIENT`** تحت **Fabric** و به زبان **Java 21** بساز که هم روی **Desktop (Windows / Linux / macOS)** و هم روی **Android / PojavLauncher** بدون کرش و با فریم‌ریت بالا کار کند.

---

## ۱. قوانین بنیادین و محدودیت‌های سخت‌گیرانه
1. **فقط خروجی واقعی و قابل نصب:** خروجی نهایی باید یک پروژه کامل Gradle/Fabric Loom به همراه فایل `.jar` کامپایل و Remap شده در `build/libs/` و `releases/` باشد. هیچ کد نمایشی، HTML، متد فرضی، کلاس خیالی یا `TODO` ناتمام مجاز نیست.
2. **تطابق دقیق با نسخه `1.21.11`:**
   - `Minecraft`: `1.21.11`
   - `Yarn Mappings`: `1.21.11+build.6`
   - `Fabric Loader`: `0.20.1` (در `fabric.mod.json` قید `"fabricloader": ">=0.18.0"` قرار گیرد تا روی نسخه‌های مختلف PojavLauncher هم اجرا شود)
   - `Fabric API`: `0.141.6+1.21.11`
   - `Gradle`: `9.8.2` و پلاگین `net.fabricmc.fabric-loom-remap` نسخه `1.17.21` (سازگار با JDK 21)
   - بدون هیچ وابستگی Native اضافی که روی پردازنده‌های `ARM64/ARM32` اندروید مشکل ایجاد کند.
3. **صفر داده جعلی:** هیچ ماژولی نباید چانک‌های Unloaded یا اطلاعات ارسال‌نشده از سمت سرور را جعل یا حدس بزند و در `Freecam` هیچ پکت حرکت یا چرخش جعلی به سرور ارسال نشود.
4. **صرفاً ۹ ماژول مشخص‌شده:** معماری `ModuleManager` باید ظرفیت مدیریت ۱۵+ ماژول را بدون تغییر هسته داشته باشد، اما دقیقاً همین **۹ ماژول خواسته‌شده** پیاده‌سازی شوند و هیچ ماژول اضافی اختراع نشود.
5. **مقداردهی تنبل (Lazy Init) برای سازگاری با تست واحد:** هیچ کلاسی نباید در سازنده (`Constructor`) یا بلوک `static` قبل از اجرای بازی به `Registries.BLOCK`، `Items.*` یا کلاس‌های OpenGL دسترسی پیدا کند تا تست‌های Headless در JUnit 5 بدون خطای `Bootstrap` اجرا شوند.

---

## ۲. معماری هسته، رویدادها و مدیریت خطا
- **`Module` و `ModuleManager`:**
  - هر ماژول دارای `id`، `name`، `description`، `Category` (`COMBAT`, `RENDER`, `WORLD`, `UTILITY`)، کلید میان‌بر مستقل (`KeybindSetting` با پشتیبانی از صفحه‌کلید و دکمه‌های ماوس `M3/M4/M5` و تشخیص تداخل کلیدها) و فهرست تنظیمات مستقل است.
  - تمام فراخوانی‌های `onTick`، `onRenderFrame`، `onRenderWorld`، `onRenderHud`، `onChunkLoad`، `onChunkUnload` و `onWorldCleanup` باید داخل `try/catch` مجزا محافظت شوند؛ در صورت بروز ۱۰ خطای پیاپی در یک ماژول، فقط همان ماژول به‌صورت خودکار خاموش شود تا کل بازی هرگز کرش نکند.
- **`WorldChunkTracker` و پاک‌سازی وضعیت دنیا:**
  - ردیابی دقیق چانک‌های واقعاً Loaded از طریق `ClientChunkEvents.CHUNK_LOAD` و `CHUNK_UNLOAD` به علاوه بررسی `world.getChunkManager().isChunkLoaded(cx, cz)`.
  - تمام ماژول‌های چانک‌محور باید مرجع `ClientWorld` (`lastWorld`) را در هر تیک بررسی کنند تا هنگام تغییر بُعد (`Overworld <-> Nether <-> End`)، خروج از سرور یا Unload شدن چانک، بلافاصله تمام کش‌ها پاک شوند.
- **`ConfigManager` (ذخیره‌سازی اتمیک JSON):**
  - ذخیره وضعیت ماژول‌ها، کلیدها و تنظیمات در `FabricLoader.getInstance().getConfigDir().resolve("nexus-client/nexus_config.json")` با نوشتن در فایل موقت `.tmp` و جابه‌جایی اتمیک (`ATOMIC_MOVE`).
  - ماژول `Freecam` نباید هنگام ورود مجدد به بازی به‌صورت خودکار روشن بماند.
  - در صورت خراب بودن فایل JSON، نسخه پشتیبان `.corrupt.bak` تهیه شده و مقادیر پیش‌فرض ایمن بدون کرش بازیابی شوند.

---

## ۳. موتور رندر سه‌بعدی ضدکرش و نگاشت دوبعدی (بسیار مهم در `1.21.11`)
- **ممنوعیت استفاده از `GizmoDrawing`:** در نسخه `1.21.11` استفاده از `GizmoDrawing` با `.ignoreOcclusion()` باعث اجرای `WorldRenderer.renderLateDebug`، خطای `clearDepthTexture` روی موبایل/GL4ES/Sodium و کرش حافظه بومی در `BuiltBuffer.sortQuads` روی بافر مشترک `DEBUG_QUADS` می‌شود؛ بنابراین در کل پروژه **صفر ارجاع به `GizmoDrawing`** وجود داشته باشد.
- **`WorldRenderHelper` (موتور Single-Batch مبتنی بر `RenderPipeline` و `RenderPass`):**
  - اتصال به رویداد `WorldRenderEvents.END_MAIN`.
  - ثبت تنبل (Lazy) دو پایپ‌لاین با `RenderPipelines.register`، شیدرهای `core/position_color`، یونیفرم‌های `DynamicTransforms` و `Projection`، فرمت `VertexFormats.POSITION_COLOR` با حالت `VertexFormat.DrawMode.QUADS`، ترکیب رنگ `BlendFunction.TRANSLUCENT`، `withCull(false)`، `withDepthWrite(false)` و دو حالت `NO_DEPTH_TEST` (برای ESP پشت دیوار) و `LEQUAL_DEPTH_TEST`.
  - تخصیص `BufferAllocator` اختصاصی (`512 KB`) کاملاً جدا از بافرهای وانیلا.
  - خواندن موقعیت دقیق دوربین از `context.worldState().cameraRenderState.pos` و بردارهای `CAM_RIGHT` و `CAM_UP` از `RenderSystem.getModelViewMatrix()`.
  - پشتیبانی از `RenderSystem.outputColorTextureOverride` و `outputDepthTextureOverride` (سازگاری با حالت Fabulous!، Sodium و Iris) و ارسال کل هندسه فریم در یک `pass.drawIndexed(...)` درون `try / catch / finally` (همراه با `built.close()`).
  - پیاده‌سازی خطوط سه‌بعدی، یال‌های باکس، خطوط افقی خوشه‌ها، فلش جهت‌نما و نقاط درخشان (`Billboard Glow Dot`) با نوارهای چهارضلعی متقاطع (`Crossed Quad Ribbons`) تا ضخامت خطوط در دسکتاپ و OpenGL ES موبایل یکسان و شفاف باشد.
- **`WorldProjector` و `HudLayoutHelper`:**
  - کلاس `WorldProjector` برای تبدیل مختصات سه‌بعدی به مختصات دوبعدی صفحه (`project`, `projectOrPoint`, `segment`) با برش صفحه نزدیک (`Near Clip`) و محافظت در برابر `NaN` و پنجره Minimize شده.
  - کلاس `HudLayoutHelper` برای چیدمان عمودی خودکار پنل‌های گوشه بالا-چپ تا هنگام روشن بودن هم‌زمان چند ماژول، کارت‌های HUD هرگز روی هم نیفتند.

---

## ۴. رابط کاربری ClickGUI با تم مشکی و طلایی (`NexusClickGuiScreen`)
- باز و بسته شدن با کلید پیش‌فرض `Right Shift` (قابل تغییر در Controls بازی) + دکمه لمسی `[X]` در هدر.
- **رفع باگ باز شدن مجدد منو:** هنگام بستن منو با `Right Shift`، متد `suppressGuiOpen()` رویدادهای صف‌شده `wasPressed()` را تخلیه کرده و تا ۳ تیک مانع باز شدن ناخواسته مجدد شود.
- طراحی مینیمال **Obsidian / Charcoal & Gold** بدون شیدرهای سنگین Blur برای حفظ FPS در PojavLauncher.
- پشتیبانی از رزولوشن‌های پایین و اسکرول لمسی (`Touch Drag`) در ستون ماژول‌ها و پنل تنظیمات.
- نوار کناری ۴ دسته‌بندی (`Combat`, `Render`, `World`, `Utility`)، کادر جست‌وجوی سراسری در هدر، سوئیچ‌های انیمیشنی نرم و پشتیبانی کامل از ۶ نوع کنترل تنظیمات:
  1. `BooleanSetting` (سوئیچ روشن/خاموش)
  2. `NumberSetting` (اسلایدر دقیق با گام مشخص و Clamping)
  3. `ModeSetting` (منوی کشویی چندحالته)
  4. `KeybindSetting` (ثبت کلید کیبورد/ماوس + دکمه پاک‌سازی `x` برای صفحه‌لمسی)
  5. `TextSetting` (کادر متن با پشتیبانی از `Ctrl+V` و `Cmd+V`، حذف `\r/\n` و رعایت سقف کاراکتر)
  6. `ActionSetting` (دکمه کلیکی عملیاتی با افکت فیدبک طلایی برای اجرای فوری دستوراتی مثل Rescan و تست Webhook)
- تطابق با امضاهای ورودی جدید `Screen` در `1.21.11` (`Click`, `KeyInput`, `CharInput`).

---

## ۵. مشخصات دقیق ۹ ماژول کلاینت

### دسته Combat
1. **`Aim Assist` (`aim_assist`)**
   - چرخش نرم و مستقل از نرخ فریم (درون‌یابی نمایی با سقف تغییر زاویه در هر فریم؛ بدون پرش ناگهانی و بدون هیچ حرکت دوربین در نبودِ هدف معتبر).
   - تنظیمات: `Range`، `Smooth Speed`، `Max FOV`، `Aim Point` (`Chest`, `Eyes`, `Adaptive`)، `Hold Key Only` + `Aim Hold Key`، `While Attacking Only`، `Weapon Only` (`ItemTags.SWORDS`, `ItemTags.AXES`, `MaceItem`, `TridentItem`)، `Line of Sight`، `Ignore Invisible`، `Target Players`، `Target Hostiles`، `Target Passives` و `Vertical Assist`.
   - **الزام مهم:** حذف صریح `ArmorStandEntity` از اهداف (چون در ماینکرفت فرزند `LivingEntity` است).

2. **`Auto Mace` (`auto_mace`)**
   - مبتنی بر مکانیک واقعی `MaceItem.shouldDealAdditionalDamage` در `1.21.11`، بررسی حداقل ارتفاع سقوط (`Min Fall Distance`)، عدم پرواز با الایترا و سرعت عمودی رو به پایین (`velocity.y < -0.05`).
   - قابلیت `Auto Switch Hotbar` به `Items.MACE` قبل از ضربه، `Restore Previous Slot` پس از ضربه یا فرود، بررسی Cooldown حمله و `Min Delay (Ticks)`.
   - حذف صریح `ArmorStandEntity` و دادن اولویت هدف‌گیری به `PlayerEntity` نسبت به ماب‌ها در صورت حضور هم‌زمان در برد ضربه.

### دسته Render
3. **`Storage ESP` (`storage_esp`)**
   - هایلایت ظروف ذخیره‌سازی فقط در چانک‌های Loaded: `Chest`، `Trapped Chest`، `Ender Chest`، `Barrel`، `Shulker Box`، `Furnace`، `Blast Furnace`، `Smoker` و `Hopper` با کلید مجزا برای هرکدام.
   - **ادغام صندوق‌های دوتایی:** بررسی `ChestBlock.CHEST_TYPE` و `ChestBlock.getFacing` تا صندوق دوتایی به‌شکل یک باکس دو‌بلاکی یکپارچه رسم شود (رد کردن `ChestType.RIGHT`).
   - پشتیبانی از رنگ‌بندی تفکیکی یا طلایی یکپارچه، `Glow`، شفافیت Fill، سقف تعداد باکس رندرشده بر اساس نزدیک‌ترین فاصله، و خطوط `Tracers` دوبعدی.

4. **`Player ESP` (`player_esp`)**
   - نمایش بازیکنان حاضر در `ClientWorld` (با درون‌یابی نرم موقعیت فریم) با باکس سه‌بعدی، `Outline Glow`، پیش‌فرض‌های رنگی + `Custom RGB`، خط `Tracers` و تگ شناور دوبعدی بالای سر شامل نام، سلامتی (`HP`) و فاصله (`m`).

5. **`Freecam` (`freecam`)**
   - دوربین آزاد کلاینت‌ساید با Mixinهای ایمن (`CameraMixin`, `KeyboardInputMixin`, `EntityMixin`, `GameRendererMixin`, `MinecraftClientMixin`, `WorldRendererMixin`) بدون حرکت دادن بازیکن روی سرور.
   - سازگار با کیبورد/ماوس دسکتاپ و جوی‌استیک/لمس در PojavLauncher، گزینه `Block Player Actions`، نمایش مختصات بالای صفحه، و صفر کردن بردار حرکت هنگام باز بودن هر `Screen`.
   - در `WorldRendererMixin` استفاده از `require = 0` روی `updateCamera` (برای سازگاری کامل با Sodium) و تزریق به `isRenderingReady` برای نمایش کامل بلاک‌انتیتی‌های چانک‌های دور در حالت Freecam.

### دسته World
6. **`Amethyst Base Finder` (`amethyst_base_finder`)**
   - اسکن تدریجی و Thread-Safe (`ConcurrentLinkedQueue` + `ConcurrentHashMap`) چانک‌های Loaded با پیش‌فیلتر سریع پالت `ChunkSection.hasAny(...)`.
   - شمارش دقیق `BUDDING_AMETHYST`، `AMETHYST_CLUSTER` و جوانه‌های کوچک/متوسط/بزرگ.
   - **ایمنی مرز چانک:** هنگام بررسی وجوه باز اطراف `BUDDING_AMETHYST`، ابتدا داخل همان سکشن خوانده شود و چانک همسایه **فقط در صورت تأیید Loaded بودن** بررسی شود.
   - ادغام ژئودهای چندچانکی، محاسبه درصد اطمینان، حالت‌های `Geode + Crystals` / `Whole Geode Box` / `Crystals Only`، فلش راهنمای سه‌بعدی، تگ‌های دوبعدی، کارت اطمینان HUD، هشدار چت/صدا و دکمه `Rescan Loaded Chunks`.

7. **`SusChunkFinder` (`sus_chunk_finder`)**
   - اسکنر هیوریستیک فعالیت بازیکن و پایگاه‌ها با ترکیب احتمالی **Noisy-OR** روی **۱۰ سیگنال مستقل**:
     1. `Machines` (قیف، دراپر، دیسپنسر، آبزرور، پیستون، ریپیتر، کامپراتور، بیکن، میز افسون، کرفتر و...)
     2. `Storage` (صندوق یک‌بارشمارش‌شده، بشکه، اندرچست، شالکر باکس؛ نادیده گرفتن ۱–۲ صندوق طبیعی کنار اسپاونر)
     3. `Crops` (مزرعه، گندم، هویج، سیب‌زمینی، چغندر، ندر وارت، کمپوستر؛ امتیاز دوبرابر در `Y < 45`)
     4. `Player blocks` (میز کار، کوره‌ها، سندان، نردبان، داربست، شیشه/شیشه رنگی، ابسیدین، بلاک‌های فشرده سنگ‌معدن، تخت، پشم، بتن، در/ترپ‌دور/تابلو/پرچم/نرده چوبی)
     5. `Deep light` (مشعل، فانوس، گلوستون، شروم‌لایت، اندراد، کمپ‌فایر — فقط زیر ارتفاع `Y < 55`)
     6. `Base entities` (قاب آیتم، استند زره، تابلو نقاشی، حیوانات اهلی یا بسته‌شده با طناب، موجودات نام‌گذاری‌شده و تجمع دام/ویلیجر)
     7. `Old growth` (`AMETHYST_CLUSTER` و `KELP` با `Properties.AGE_25 == 25`)
     8. `Redstone` (ردستون، اهرم، قلاب تله، تارگت، اسلایم/عسل، برق‌گیر، اسکالک سنسور، دکمه و صفحه فشاری)
     9. `Portal` (`NETHER_PORTAL`)
     10. `Decor / stations` (کتابخانه، لکترن، معجون‌سازی، دیگ، سنگ سمباده، لودستون، ریسپاون انکر، آجر، کوارتز، سنگ صیقلی، کندو، شمع، سرها، فرش و چوب پوست‌کنده)
   - هر ۱۰ سیگنال دارای سوئیچ روشن/خاموش و اسلایدر وزن (`0%` تا `200%`) باشند و با تغییر هر تنظیم، امتیاز چانک‌های کش‌شده فوراً بازمحاسبه شود.
   - **تضعیف سازه‌های طبیعی (`Ignore structures` + `Find in water`):** تشخیص خودکار `Mineshaft`، `Trial Chambers` (`trial_spawner`, `vault`, `heavy_core` یا ترکیب آجر توف و مس)، دانجن‌ها و کشتی‌های غرق‌شده در بیوم‌های اقیانوس/ساحل همراه با انتشار اثر در شعاع `±2` چانک و بازامتیازدهی همسایه‌ها.
   - سرریز امتیاز به ۴ چانک مجاور (`0.35`)، پرچم‌گذاری زنده چانک حضور بازیکنان غیر Spectator (`Flag live players` با رنگ فیروزه‌ای `LIVE`)، سقف زمانی `10ms` در هر تیک و کش شناسه شیء چانک (`Skip scanned chunks`).
   - ادغام چانک‌های مشکوک همسایه با الگوریتم **Union-Find** (`Merge nearby chunks`) و رسم فقط خطوط محیط بیرونی خوشه + نقطه درخشان مرکز + بزرگ‌نمایی بدون هم‌پوشانی در فواصل دور (`Bigger when far %`).
   - نمایش کارت بازرسی انیمیشنی جزئیات سرنخ‌ها هنگام قرار گرفتن نشانه‌گیر روی خوشه (`Hover info`)، نوار پیشرفت اسکن (`Scan progress`)، نقشه راداری بالا به پایین (`Region map`)، کارت‌های راهنمای گوشه پایین-راست با آیکون آیتم (`Corner indicator`)، `Tracer to best`، هشدار چت/صدا، پشتیبانی غیرمسدودکننده از **Discord Webhook** و دکمه‌های `Rescan all chunks` و `Send Discord test`.

8. **`Stash Finder` (`stash_finder`)**
   - اسکن چانک‌های Loaded در شعاع `Range (chunks)` برای یافتن خوشه‌های متراکم ظروف ذخیره‌سازی (`>= Min chests` در شعاع `Radius` بلاک با خوشه‌بندی BFS).
   - شمارش یک‌باره صندوق‌های دوتایی، گزینه‌های `Barrels / shulkers` و `Ender chests` (با سقف ایمنی ۳۰۰۰ ظرف در هر گذر اسکن).
   - گزینه `Ignore dungeons` برای حذف خوشه‌های نزدیک به `MobSpawnerBlockEntity`، `TrialSpawnerBlockEntity` و `VaultBlockEntity`.
   - اعلام استش‌های جدید در چت کلاینت با شمارش و مختصات (تا ۱۰ مورد اول + تعداد باقی‌مانده)، مرتب‌سازی بر اساس نزدیک‌ترین استش، هایلایت سه‌بعدی با گزینه‌های `Max boxes`، `Highlight range`، `One box per stash` (پوشش کامل `(x1, y1, z1)` تا `(x2 + 1, y2 + 1, z2 + 1)`)، `Glow`، `Fill`، تگ‌های شناور `STASH xN  Dm`، خطوط `Tracers` و دکمه `Clear & rescan stashes`.

### دسته Utility
9. **`Auto Text` (`auto_text`)**
   - تنظیم متن پیام یا دستور `/command` (پاک‌سازی کاراکترهای غیرمجاز، سقف ۲۵۶ کاراکتر)، کلید اختصاصی `Send Keybind`، حالت `Instant Send` (ارسال آنی از طریق `ClientPlayNetworkHandler` یا باز کردن `new ChatScreen(text, false)` با متن آماده)، `Cooldown (ms)` و جلوگیری مطلق از اجرا هنگام باز بودن هرگونه منو یا کادر تایپ.

---

## ۶. تست خودکار، مستندسازی و تحویل نهایی
1. نوشتن تست‌های واحد **JUnit 5** برای بررسی ثبت دقیق هر ۹ ماژول، روشن/خاموش شدن و `onWorldCleanup`، ذخیره و بازیابی `ConfigManager`، مقاومت در برابر JSON خراب، `ActionSetting`، چیدمان `HudLayoutHelper`، اعتبارسنجی اسلایدرها/کلیدها و ریاضیات زاویه.
2. اجرای کامل `./gradlew clean test build`، بررسی نگاشت `intermediary` تمام Mixinها در بایت‌کد فایل `.jar` نهایی و اطمینان از صفر بودن ارجاعات به `GizmoDrawing`.
3. ارائه فایل‌های مستندات `README.md` (راهنمای نصب دسکتاپ و PojavLauncher + شرح ماژول‌ها) و `QA_REPORT.md` با بیان کاملاً صادقانه تست‌های انجام‌شده.
