# NEXUS CLIENT (`1.0.0+mc1.21.11`)

**Minecraft Java Edition `1.21.11` | Fabric | Java 21 | Desktop & Android (PojavLauncher)**

یک کلاینت ماژولار، سبک و مدرن با تم اختصاصی **مشکی و طلایی (Black & Gold)** برای **Minecraft Java Edition 1.21.11** تحت **Fabric** که از پایه با APIهای واقعی نسخه `1.21.11` و رندرر سه‌بعدی Single-Batch اختصاصی (بدون نیاز به کتابخانه بومی اضافی و کاملاً سازگار با **Desktop** و **Android / PojavLauncher**) پیاده‌سازی شده است.

---

## ۱. مشخصات فنی و نسخه‌های تطبیق‌یافته

| مؤلفه | نسخه دقیق استفاده‌شده |
|---|---|
| **Minecraft** | `1.21.11` |
| **Mappings** | `net.fabricmc:yarn:1.21.11+build.6:v2` |
| **Fabric Loader** | کامپایل با `0.20.1` (سازگار با `>=0.18.0` در `fabric.mod.json`) |
| **Fabric API** | `0.141.6+1.21.11` |
| **Fabric Loom (Remap)** | `1.17.21` (`net.fabricmc.fabric-loom-remap`) |
| **Gradle** | `9.8.2` |
| **Java Target** | `Java 21` (`--release 21`) |
| **فایل خروجی JAR** | `build/libs/nexus-client-1.0.0+mc1.21.11.jar` و `releases/nexus-client-1.0.0+mc1.21.11.jar` |

---

## ۲. معماری و فهرست ماژول‌ها (۹ ماژول فعال از ظرفیت معماری ۱۵ ماژول)

هسته `ModuleManager` برای مدیریت تا **۱۵ ماژول** (و بیشتر بدون نیاز به تغییر هسته) طراحی شده و دقیقاً **۹ ماژول درخواستی** به‌صورت واقعی و کامل پیاده‌سازی شده‌اند:

### Combat
1. **Aim Assist (`aim_assist`)**
   - چرخش نرم و وابسته به Delta-Time فریم (بدون پرش ناگهانی دوربین).
   - تنظیمات کامل: `Range`، `Smooth Speed`، `Max FOV`، `Aim Point` (`Chest` / `Eyes` / `Adaptive`)، `Hold Key Only` + `Aim Hold Key`، `Weapon Only`، `Line of Sight` و فیلتر `Players` / `Hostiles` / `Passives` (با حذف خودکار `ArmorStand` از اهداف جنگی).

2. **Auto Mace (`auto_mace`)**
   - پیاده‌سازی‌شده با مکانیک واقعی کلاس `MaceItem` در نسخه `1.21.11` (`MaceItem.shouldDealAdditionalDamage`، بررسی `fallDistance`، عدم پرواز با Elytra و بررسی سرعت سقوط).
   - سوییچ خودکار به `Items.MACE` در Hotbar، اولویت‌دهی هوشمند به بازیکنان نسبت به ماب‌ها در برد ضربه، بازگشت به اسلات قبلی (`Restore Previous Slot`) و محافظ ضداسپم.

### Render
3. **Storage ESP (`storage_esp`)**
   - نمایش Containerهای داخل **Chunkهای Loaded**: `Chest`، `Trapped Chest`، `Ender Chest`، `Barrel`، `Shulker Box`، `Furnace`، `Blast Furnace`، `Smoker` و `Hopper`.
   - ادغام تمیز **Double Chest** به شکل یک جعبه دو‌بلاکی واحد، Glow اختیاری، خط Tracer دوبعدی و پاک‌سازی فوری هنگام `Chunk Unload` یا تغییر بُعد (`Overworld / Nether / End`).

4. **Player ESP (`player_esp`)**
   - نمایش بازیکنان حاضر در محدوده Loaded کلاینت با Bounding Box سه‌بعدی (همراه با Glow)، خط Tracer و تگ دوبعدی دقیق بالای بازیکن شامل نام، سلامتی (`HP`) و فاصله (`m`).

5. **Freecam (`freecam`)**
   - دوربین آزاد کلاینت‌ساید بدون تغییر موقعیت سروری بازیکن و بدون ارسال پکت حرکت یا چرخش جعلی به سرور.
   - سازگار با دسکتاپ و **Android / PojavLauncher**، نمایش کامل بلاک‌انتیتی‌ها در چانک‌های دور (`isRenderingReady`) و سازگاری ایمن با Sodium (`require = 0`).

### World
6. **Amethyst Base Finder (`amethyst_base_finder`)** *(بازطراحی ضدکرش)*
   - اسکن ایمن و Thread-Safe ژئودهای آمتیست (`budding_amethyst`، `amethyst_cluster` و جوانه‌ها) بدون خواندن چانک‌های Unloaded همسایه و بدون استفاده از `GizmoDrawing` باگ‌دار ۱.۲۱.۱۱.
   - خوشه‌بندی هوشمند ژئودهای چندچانکی، انتخاب حالت نمایش (`Geode + Crystals` / `Whole Geode Box` / `Crystals Only`)، فلش راهنمای سه‌بعدی، تگ‌های فاصله و کارت اطمینان HUD با چیدمان بدون تداخل.

7. **SusChunkFinder (`sus_chunk_finder`)** *(بازطراحی کامل بر اساس مخزن مرجع)*
   - سیستم امتیازدهی Noisy-OR با **۱۰ سیگنال مستقل** قابل تنظیم (`Machines`، `Storage`، `Crops`، `Player blocks`، `Deep light < Y55`، `Base entities`، `Old growth`، `Redstone`، `Portal`، `Decor / stations`) به همراه کلید روشن/خاموش و ضریب وزن (`0%–200%`) برای هر سیگنال.
   - تشخیص و تضعیف خودکار سازه‌های طبیعی (`Ignore structures`: معادن رهاشده `Mineshaft`، `Trial Chambers`، دانجن‌ها با ۱ تا ۲ صندوق و کشتی‌های غرق‌شده در اقیانوس/ساحل وقتی `Find in water` خاموش است) با بازامتیازدهی همسایه‌ها در شعاع `±2` چانک.
   - پرچم‌گذاری زنده چانک حضور بازیکنان غیر Spectator (`Flag live players`)، سرریز امتیاز به چانک‌های مجاور، ادغام چانک‌های مشکوک متصل (`Merge nearby chunks`) و بزرگ‌نمایی هوشمند بدون هم‌پوشانی در فواصل دور (`Bigger when far %`).
   - کارت بازرسی انیمیشنی هنگام نشانه‌گیری روی خوشه‌ها (`Hover info`)، نوار پیشرفت اسکن (`Scan progress`)، نقشه راداری بالا به پایین (`Region map`)، کارت‌های راهنمای گوشه پایین-راست (`Corner indicator`)، هشدار چت/صدا و پشتیبانی اختیاری از **Discord Webhook** غیرمسدودکننده (`Async`) همراه با دکمه‌های `Rescan all chunks` و `Send Discord test` در ClickGUI.

8. **Stash Finder (`stash_finder`)** *(ماژول جدید)*
   - طراحی‌شده بر پایه `StashFinder.java`: شناسایی انبارها و استش‌های متراکم بازیکنان در چانک‌های لودشده (`Min chests` در شعاع `Radius` بلاک).
   - شمارش یک‌باره صندوق‌های دوتایی، پشتیبانی از `Barrels / shulkers` و `Ender chests`، و فیلتر هوشمند اتاق‌های اسپاونر (`Ignore dungeons`: نادیده گرفتن گروه‌های نزدیک `MobSpawner`، `TrialSpawner` و `Vault`).
   - اعلام مختصات استش‌های کشف‌شده در چت کلاینت، هایلایت سه‌بعدی (`One box per stash` یا تک‌به‌تک تا سقف `Max boxes` به ترتیب نزدیک‌ترین)، برچسب‌های شناور `STASH xN  Dm`، خطوط `Tracers` و دکمه `Clear & rescan stashes`.

### Utility
9. **Auto Text (`auto_text`)**
   - ارسال فوری پیام/دستور سفارشی یا قرار دادن آن در کادر چت با Keybind اختصاصی، سقف ۲۵۶ کاراکتر و محافظ ضداسپم.

---

## ۳. روش نصب (دسکتاپ و Android / PojavLauncher)

1. اطمینان حاصل کنید **Minecraft Java Edition `1.21.11`**، **Fabric Loader (`>=0.18.0`، پیشنهادی `0.20.1`)**، **Fabric API (`0.141.6+1.21.11`)** و **Java 21** نصب هستند.
2. فایل `nexus-client-1.0.0+mc1.21.11.jar` (موجود در `releases/` یا `build/libs/`) را به همراه `fabric-api-0.141.6+1.21.11.jar` در پوشه `.minecraft/mods/` قرار دهید.
3. داخل بازی با فشردن **`Right Shift`** (یا دکمه سفارشی معادل در PojavLauncher / تنظیمات `Controls -> NEXUS CLIENT`) منوی **NEXUS ClickGUI** را باز و بسته کنید.

---

## ۴. روش Build از سورس

```bash
cd nexus-client
./gradlew clean test build
```

فایل تنظیمات کاربر هنگام اجرا به‌صورت اتمیک در مسیر استاندارد Fabric ذخیره می‌شود:
`config/nexus-client/nexus_config.json`
