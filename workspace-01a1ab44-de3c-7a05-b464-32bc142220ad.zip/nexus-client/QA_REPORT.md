# NEXUS CLIENT — گزارش ممیزی باگ‌ها، رفع کرش و کنترل کیفیت (QA Report)

**پروژه:** `NEXUS CLIENT`  
**نسخه خروجی:** `1.0.0+mc1.21.11`  
**فایل نهایی JAR:** `build/libs/nexus-client-1.0.0+mc1.21.11.jar` و `releases/nexus-client-1.0.0+mc1.21.11.jar`

---

## ۱. ریشه‌یابی دقیق کرش `Amethyst Base Finder` در غار و نحوه رفع قطعی آن

در بررسی کامل بایت‌کد `WorldRenderer` و `GizmoDrawerImpl` در **Minecraft 1.21.11** مشخص شد کرش هنگام ورود به غار و برخورد با ژئود آمتیست ناشی از سه عامل هم‌زمان بوده است:

1. **باگ 파이پ‌لاین بومی `GizmoDrawing` با `.ignoreOcclusion()` در ۱.۲۱.۱۱ (عامل اصلی کرش بومی/گرافیکی):**
   - فراخوانی `GizmoDrawing.box(...).ignoreOcclusion()` پرچم `hasNoOcclusionGizmos` را فعال کرده و در پایان فریم (خارج از بلوک `try/catch` ماد!) متد `WorldRenderer.renderLateDebug` را اجرا می‌کرد.
   - این متد ابتدا `CommandEncoder.clearDepthTexture(...)` را صدا می‌زند که روی برخی درایورها، رندررهای موبایل/GL4ES، Sodium/Iris یا بافت‌های Depth-Stencil فشرده خطای GPU/GL ایجاد می‌کند، و سپس در `Immediate.draw(DEBUG_QUADS)` هنگام بزرگ شدن بافر (~۱۶۰ باکس ژئود)، متد `BuiltBuffer.sortQuads` و بافر رأس‌ها به یک `BufferAllocator` مشترک اشاره کرده و `realloc` باعث خطای حافظه Native (`SIGSEGV` / `BufferOverflow`) می‌شد.
   - **راه‌حل اعمال‌شده:** حذف کامل `GizmoDrawing` از کل کلاینت و پیاده‌سازی موتور رندر اختصاصی `WorldRenderHelper` بر پایه `RenderPipeline` و `RenderPass` رسمی ۱.۲۱.۱۱ (`core/position_color` با `VertexFormat.DrawMode.QUADS` و `BufferAllocator` اختصاصی `512KB`) همراه با `WorldProjector` برای تگ‌های دوبعدی؛ تمام رسم‌های سه‌بعدی در یک فراخوانی `drawIndexed` داخل بلوک ایمن `try / catch / finally` انجام می‌شوند.

2. **تداخل هم‌زمانی (Concurrency) در صف اسکن چانک‌ها:**
   - مجموعه‌های غیرهمگام `ArrayDeque` و `HashSet` با ساختارهای کاملاً Thread-Safe (`ConcurrentLinkedQueue` و `ConcurrentHashMap.newKeySet()`) جایگزین شدند.

3. **خواندن بلاک همسایه در مرز چانک‌های Unloaded:**
   - بررسی وجوه باز اطراف `BUDDING_AMETHYST` اکنون ابتدا داخل همان `ChunkSection` انجام شده و تنها در صورتی چانک مجاور را می‌خواند که لود بودن آن در `WorldChunkTracker` تأیید شده باشد.

---

## ۲. سایر باگ‌های کشف و برطرف‌شده در ممیزی کامل کل کلاینت (Client-Wide Audit)

| ردیف | بخش / ماژول | مشکل شناسایی‌شده | اصلاح انجام‌شده |
|---|---|---|---|
| ۱ | `WorldRenderHelper` | بردارهای دوربین برای نقاط درخشان (`Billboard Glow Dot`) و تطابق موقعیت زیرفریم دوربین | خواندن مستقیم محورهای دوربین از `RenderSystem.getModelViewMatrix()` و استفاده از `worldState().cameraRenderState.pos` برای حذف کامل لرزش در حرکت سریع |
| ۲ | `NexusClickGuiScreen` / `NexusEventBus` | باز شدن مجدد ناخواسته منو در تیک بعدی هنگام بستن ClickGUI با کلید `Right Shift` | تخلیه رویدادهای صف‌شده `openGuiKeyBinding.wasPressed()` و افزودن پنجره محافظ ۳ تیکی در `suppressGuiOpen()` |
| ۳ | `NexusClickGuiScreen` | پشتیبانی از دکمه‌های عملیاتی (`ActionSetting`) و کلید ترکیبی `Cmd+V` علاوه بر `Ctrl+V` | افزودن کلاس `ActionSetting` برای دکمه‌های `Rescan` / `Discord Test` / `Clear Stashes` و پشتیبانی کامل کلیپ‌بورد |
| ۴ | `AimAssist` و `AutoMace` | هدف گرفتن ناخواسته `ArmorStandEntity` (چون در ماینکرفت فرزند `LivingEntity` است) | حذف صریح `ArmorStandEntity` از اهداف هر دو ماژول و اولویت‌دهی `PlayerEntity` در `AutoMace` |
| ۵ | `WorldRendererMixin` | احتمال تداخل اجباری Mixin با مادهایی مثل Sodium و عدم رندر بلاک‌انتیتی‌های دور در `Freecam` | افزودن `require = 0` و تزریق ایمن به `isRenderingReady` هنگام فعال بودن `Freecam` |
| ۶ | `FreecamModule` | باقی ماندن آخرین بردار حرکت هنگام باز شدن منو/چت در میانه پرواز | صفر کردن فوری `capturedInput` و `capturedMoveVec` به‌محض باز شدن هر `Screen` |
| ۷ | `StorageEspModule` | رسم دو باکس هم‌پوشان روی صندوق‌های دوتایی (`Double Chest`) | ادغام نیمه چپ و راست صندوق دوتایی در یک `Box` دو‌بلاکی یکپارچه + افزودن `Ender Chest` |
| ۸ | `HudLayoutHelper` | هم‌پوشانی کارت‌های HUD گوشه بالا-چپ هنگام روشن بودن هم‌زمان چند ماژول | افزودن چیدمان عمودی خودکار (`HudLayoutHelper.claimTopLeftY`) بین `SusChunkFinder` و `AmethystBaseFinder` |
| ۹ | تمام ماژول‌های چانک‌محور | باقی ماندن کش چانک‌ها هنگام تغییر بُعد (`Overworld <-> Nether <-> End`) بدون خروج از سرور | پایش مرجع `ClientWorld` (`lastWorld`) در هر تیک و پاک‌سازی آنی کش هنگام تغییر دنیا |
| ۱۰ | `StashFinderModule` | رفع باگ مرجع در حالت `One box per stash` (`x1+1, y1+1` به‌جای `x2+1, y2+1`) | محاسبه صحیح باکس کامل پوشاننده کل استش `(x1, y1, z1) -> (x2 + 1, y2 + 1, z2 + 1)` |

---

## ۳. خلاصه تست‌های انجام‌شده

| آزمون | وضعیت | جزئیات |
|---|---|---|
| کامپایل کامل Java 21 (`./gradlew compileJava`) | **موفق** | کامپایل بدون خطا در برابر `minecraft-merged-1.21.11` و `fabric-api-0.141.6+1.21.11`. |
| نگاشت Mixinها و عدم وجود `GizmoDrawing` در بایت‌کد | **موفق** | بررسی با `javap -v` و `javap -c`: تمام ۶ کلاس Mixin به شناسه‌های `intermediary` نگاشت شده و صفر ارجاع به `GizmoDrawing` در JAR نهایی وجود دارد. |
| تست‌های واحد خودکار JUnit 5 (`NexusCoreTest`) | **موفق (۹ از ۹ تست)** | ثبت و چرخه حیات هر ۹ ماژول، ذخیره و بازیابی JSON در `ConfigManager`، مقاومت در برابر JSON خراب، اعتبارسنجی تنظیمات، `ActionSetting`، چیدمان `HudLayoutHelper` و محاسبات زاویه. |
| تست گرافیکی زنده داخل پنجره Minecraft / دستگاه Android | **انجام‌نشده در محیط Build** | محیط ساخت فعلی یک کانتینر لینوکس بدون نمایشگر (`Headless`) است؛ کامپایل، نگاشت بایت‌کد و تست‌های واحد به‌طور کامل انجام شده‌اند و تست بصری در محیط واقعی بازی توسط کاربر انجام می‌شود. |
